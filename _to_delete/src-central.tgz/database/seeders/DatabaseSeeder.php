<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        $this->call([
            RoleSeeder::class,
            SatkerSeeder::class,
            IndikatorSeeder::class,
            PertanyaanSeeder::class,
            PeriodSeeder::class,
            PembobotanSeeder::class,
            UserSeeder::class,
            TransactionSeeder::class,
            MigrateJsonToRelationalSeeder::class,
        ]);
    }
}
