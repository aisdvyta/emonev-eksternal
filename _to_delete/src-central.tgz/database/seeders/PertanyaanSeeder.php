<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class PertanyaanSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        \Illuminate\Support\Facades\Cache::forget('master_questions_count');
        \Illuminate\Support\Facades\Cache::forget('master_questions_max_scores');

        $questions = [

            // ══════════════════════════════════════════════════════════════
            // INDIKATOR 1: KUALITAS INFORMASI
            // ══════════════════════════════════════════════════════════════
            [
                'order_no' => 1, 'id_indicators' => 1, 'id_sub_indicators' => 1, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdr mengumumkan informasi terkait alamat Badan Publik ?',
                'ques_description' => 'Terpublikasi di kantor, website, media sosial dan media online lainya. Yang dimaksud  terdiri atas : 1. nama jalan, 2. nomor, 3. kota/kab, 4. provinsi, 5. kode pos, 6. no.tlp/fax, 7. alamat email/webmail',
                'link_drive' => 'https://drive.google.com/drive/folders/1SxZqJnnY2qC8kqxVnGF2faF-dB9ofohv?usp=drive_link',
                'link_ppid' => 'https://ppid.bps.go.id/app/konten/3500/Profil-BPS.html#pills-7',
            ],
            [
                'order_no' => 2, 'id_indicators' => 1, 'id_sub_indicators' => 1, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdr mengumumkan informasi terkait visi-misi Badan Publik ?',
                'ques_description' => 'Terpublikasi di kantor, website, media sosial dan media online lainya. Yang dimaksud  terdiri atas : Visi Misi sesuai dengan rencana dan target kinerja Badan Publik',
                'link_drive' => 'https://drive.google.com/drive/folders/1A6Y6I7c4Js-CsItrnKpa-Fb61vLwA64J?usp=drive_link',
                'link_ppid' => 'https://ppid.bps.go.id/app/konten/3500/Profil-BPS.html#pills-1',
            ],
            [
                'order_no' => 3, 'id_indicators' => 1, 'id_sub_indicators' => 1, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdr mengumumkan informasi terkait tugas dan fungsi Badan Publik ?',
                'ques_description' => 'Terpublikasi di kantor, website, media sosial dan media online lainya. Yang dimaksud  terdiri dari adanya 1. tugas dan 2. fungsi Badan Publik',
                'link_drive' => 'https://drive.google.com/drive/folders/16P1pcSPPCTF7OerIOq5DdpgPisrs_0fB?usp=drive_link',
                'link_ppid' => 'https://ppid.bps.go.id/app/konten/3500/Profil-BPS.html#pills-3',
            ],
            [
                'order_no' => 4, 'id_indicators' => 1, 'id_sub_indicators' => 1, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdr mengumumkan informasi terkait struktur organisasi Badan Publik ?',
                'ques_description' => 'Terpublikasi di kantor, website, media sosial dan media online lainya. Yang dimaksud  memuat : struktur dari pimpinan tertinggi Badan Publik sampai dengan 3 level ke bawah (levelnya dihitung dari pimpinan tertinggi)',
                'link_drive' => 'https://drive.google.com/drive/folders/1p-Zvr-_lb15aT6EZZgjLyQy0QUuhBZCS?usp=drive_link',
                'link_ppid' => 'https://ppid.bps.go.id/app/konten/3500/Profil-BPS.html#pills-2',
            ],
            [
                'order_no' => 5, 'id_indicators' => 1, 'id_sub_indicators' => 1, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdr mengumumkan informasi terkait profil singkat pimpinan dan/atau pejabat struktural Badan Publik ?',
                'ques_description' => 'Terpublikasi di kantor, website, media sosial dan media online lainya. Yang dimaksud  memuat : 1. nama, 2. jabatan, 3. nomor telepon unit kerja, 4. alamat unit/satker pejabat, 5. latar belakang pendidikan, dan 6. penghargaan yang pernah diterima.',
                'link_drive' => 'https://drive.google.com/drive/folders/1cRICmbAEAai57g9KOv2ZZxc8BrnRzFHG?usp=drive_link',
                'link_ppid' => 'https://ppid.bps.go.id/app/konten/3500/Profil-BPS.html#pills-8',
            ],
            [
                'order_no' => 6, 'id_indicators' => 1, 'id_sub_indicators' => 1, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdr mengumumkan LHKPN/LHKASN Pejabat Negara yang telah diperiksa, diverifikasi, dan telah dikirimkan secara resmi oleh Komisi Pemberantasan Korupsi (KPK) ?',
                'ques_description' => 'Yang dimaksud memuat : pada website mencantumkan link file (LHKPN/LHKASN) pimpinan, eselon 3, dan pejabat lain pada badan publik saudara yang resmi dari KPK (bukan website KPK)',
                'link_drive' => 'https://drive.google.com/drive/folders/1OwHVV1b7LyRnjfV3khKnBkYYVHxcQxK2?usp=drive_link',
                'link_ppid' => 'https://ppid.bps.go.id/app/konten/3500/Profil-BPS.html#pills-8',
            ],
            [
                'order_no' => 7, 'id_indicators' => 1, 'id_sub_indicators' => 1, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdr mengumumkan informasi tentang program/kegiatan yang sedang dijalankan badan Publik di Tahun 2026?',
                'ques_description' => 'Terpublikasi di kantor, website, media sosial dan media online lainya. Yang dimaksud adalah rangkuman program/kegiatan, dapat berupa infografis/timeline/dsb yang terdiri dari : 1. nama program/kegiatan, 2. penanggung jawab/ pelaksana program, 3. jadwal kegiatan/program, 4. target capaian, dan 5. anggaran.',
                'link_drive' => 'https://drive.google.com/drive/folders/1fTu3jY_IYcTCiMmIodoD8MMG7P1LqV8Q?usp=drive_link',
                'link_ppid' => 'https://ppid.bps.go.id/app/konten/3500/Program-Kerja.html#pills-1',
            ],
            [
                'order_no' => 8, 'id_indicators' => 1, 'id_sub_indicators' => 1, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdr mengumumkan informasi tentang agenda pelaksanaan tugas Badan Publik Tahun 2025-2026?',
                'ques_description' => 'Terpublikasi di kantor, website, media sosial dan media online lainya. Yang dimaksud  adalah mengumumkan program-program atau kegiatan yang telah dilaksanakan Tahun 2025 serta agenda kegiatan yang telah, sedang, atau akan dilaksanakan dalam kurun waktu 3 bulan ke belakang sampai dengan 3 bulan kedepan di tahun 2026. Sekurang-kurangnya memuat nama program/kegiatan, realisasi anggaran, pencapaian kegiatan.',
                'link_drive' => 'https://drive.google.com/drive/folders/1vM2DoLsc40QTa8QmDcHreC0FSlPG_ztk?usp=drive_link',
                'link_ppid' => 'https://ppid.bps.go.id/app/konten/3500/Program-Kerja.html#pills-4',
            ],
            [
                'order_no' => 9, 'id_indicators' => 1, 'id_sub_indicators' => 1, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdr mengumumkan informasi terkait Laporan Akuntabilitas Kinerja Tahun 2025?',
                'ques_description' => 'Terpublikasi di kantor, website, media sosial dan media online lainya. Yang dimaksud  memuat : berupa link/file pdf/screenshoot Laporan Kinerja Instansi Pemerintah (LKjIP)/LAKIP atau Kementerian/Lembaga',
                'link_drive' => 'https://drive.google.com/drive/folders/1f67CrJrfMHh7NOpXW01dPq9jAZVbxCkV?usp=drive_link',
                'link_ppid' => 'https://ppid.bps.go.id/app/konten/3500/Laporan-Kinerja.html',
            ],
            [
                'order_no' => 10, 'id_indicators' => 1, 'id_sub_indicators' => 1, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdr mengumumkan informasi laporan keuangan Badan Publik Tahun 2025 yang sudah diaudit ?',
                'ques_description' => 'Terpublikasi di kantor, website, media sosial dan media online lainya. Yang dimaksud  memuat : 1. laporan realisasi anggaran Tahun 2025, 2. neraca keuangan Badan Publik tahun 2025, 3. laporan arus kas dan catatan laporan keuangan Tahun 2025, dan 4. daftar aset dan investasi Tahun 2025.',
                'link_drive' => 'https://drive.google.com/drive/folders/1SfAjy9oCnbpBBXCY6PkxxJN1DQD97Tyg?usp=drive_link',
                'link_ppid' => 'https://ppid.bps.go.id/app/konten/3500/Informasi-Tentang-Kepegawaian-dan-Keuangan.html',
            ],
            [
                'order_no' => 11, 'id_indicators' => 1, 'id_sub_indicators' => 1, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdr mengumumkan informasi Rencana Kerja dan Anggaran 2026 ?',
                'ques_description' => 'Terpublikasi di kantor, website, media sosial dan media online lainya. Yang dimaksud  memuat : 1. DPA Tahun 2026, 2. RKA Tahun 2026 dan 3. DIPA Tahun 2026',
                'link_drive' => 'https://drive.google.com/drive/folders/15-Q7C3IM-a_ELmHI2vlEsqCKrNQzaVKG?usp=drive_link',
                'link_ppid' => 'https://ppid.bps.go.id/app/konten/3500/Informasi-Tentang-Kepegawaian-dan-Keuangan.html',
            ],
            [
                'order_no' => 12, 'id_indicators' => 1, 'id_sub_indicators' => 1, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Sdr mengumumkan dalam kanal informasi Badan Publik informasi realisasi atau penyerapan penggunaan keuangan Tahun 2026 ?',
                'ques_description' => 'Yang dimaksud adalah kanal informasi seperti : website, media sosial, digital screen, roll banner, poster, spanduk, papan pengumuman dll.',
                'link_drive' => 'https://drive.google.com/drive/folders/1N00ZyElsvVKcbWGzzM62zpjZRmioHITV?usp=sharing',
                'link_ppid' => 'https://ppid.bps.go.id/app/konten/3500/Informasi-Tentang-Kepegawaian-dan-Keuangan.html',
            ],
            [
                'order_no' => 13, 'id_indicators' => 1, 'id_sub_indicators' => 1, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan publik Sdr mengumumkan informasi rencana umum pengadaan program atau kegiatan sesuai tugas dan fungsi Badan Publik sebagaimana tercantum dalam SIRUP ?',
                'ques_description' => 'Terpublikasi di kantor, website, media sosial dan media online lainya. Yang dimaksud  terdiri dari : informasi mengenai sebagaimana tercantum dalam SIRUP yang telah selesai serah terima maupun yang masih berjalan dan belum serah terima',
                'link_drive' => 'https://drive.google.com/drive/folders/1OwYc4xBV6p66YqAHjDb0QLQ6-_qA77Ez?usp=drive_link',
                'link_ppid' => 'https://ppid.bps.go.id/app/konten/3500/Pengadaan.html',
            ],
            [
                'order_no' => 14, 'id_indicators' => 1, 'id_sub_indicators' => 1, 'scores' => 2.5,
                'ques_text' => 'Sebutkan pengumuman 5 paket pengadaan barang dan jasa Tahun 2025 yang tercantum dalam LPSE atau SIRUP yang telah selesai serah terima',
                'ques_description' => 'Terpublikasi di kantor, website, media sosial dan media online lainya. Badan Publik menyebutkan 5 paket pengadaan barang dan jasa Tahun 2025 yang tercantum dalam LPSE atau SIRUP yang telah selesai serah terima',
                'link_drive' => 'https://drive.google.com/drive/folders/1cJatcgcOou3xdSiiRNYqdbxq3yuIJyDf?usp=drive_link',
                'link_ppid' => 'https://ppid.bps.go.id/app/konten/3500/Pengadaan.html',
            ],
            [
                'order_no' => 15, 'id_indicators' => 1, 'id_sub_indicators' => 1, 'scores' => 2.5,
                'ques_text' => 'Sebutkan pengumuman 5 paket pengadaan barang dan jasa Tahun 2026 yang tercantum dalam LPSE atau SIRUP yang masih berjalan dan belum serah terima',
                'ques_description' => 'Terpublikasi di kantor, website, media sosial dan media online lainya. Badan Publik menyebutkan 5 paket pengadaan barang dan jasa Tahun 2026 yang tercantum dalam LPSE atau SIRUP yang masih berjalan dan belum serah terima',
                'link_drive' => 'https://drive.google.com/file/d/1LSssSGlVvl1O9XIXlPJnK677zjhRwYoj/view?usp=drive_link',
                'link_ppid' => 'https://ppid.bps.go.id/app/konten/3500/Pengadaan.html',
            ],
            [
                'order_no' => 16, 'id_indicators' => 1, 'id_sub_indicators' => 2, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdr memliki Surat Keputusan Penetapan Daftar Informasi Publik (DIP) Tahun 2025 ?',
                'ques_description' => 'Yang dimaksud lengkap adalah  informasi yang dikuasasi Tahun 2025 dalam Daftar Informasi Publik (DIP) sesuai Perki 1 Tahun 2021 tentang Standar Layanan Informasi Publik (SLIP)',
                'link_drive' => 'https://drive.google.com/drive/folders/1nzW2IHljF_DhjJ0LyM4A5azRkvBjtGhN?usp=drive_link',
                'link_ppid' => 'https://ppid.bps.go.id/app/konten/3500/Daftar-Informasi-Publik.html',
            ],
            [
                'order_no' => 17, 'id_indicators' => 1, 'id_sub_indicators' => 3, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdr memliki Surat Keputusan Penetapan Daftar Informasi Dikecualikan (DIK) ?',
                'ques_description' => 'Yang dimaksud lengkap adalah berupa Surat Keputusan (SK) Penetapan DIK dengan melampirkan hasil uji konsekuensi beserta berita acara. Jika Tidak Ada dapat melampirkan Surat keterangan Bahwa tidak ada Data tsb dan ditandatangani oleh Atasan PPID/Kepala Desa',
                'link_drive' => 'https://drive.google.com/drive/folders/1mZuZ3Pizz22Vue1bEptawtPHk8O2z10x?usp=drive_link',
                'link_ppid' => 'https://ppid.bps.go.id/app/dikecualikan',
            ],

            // ══════════════════════════════════════════════════════════════
            // INDIKATOR 2: JENIS INFORMASI
            // ══════════════════════════════════════════════════════════════
            [
                'order_no' => 18, 'id_indicators' => 2, 'id_sub_indicators' => 4, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdr menyediakan Dokumen program-program atau kegiatan Tahun 2025 Badan Publik sesuai dengan tugas dan fungsi  yang sekurang-kurangnya memuat nama program/kegiatan, sumber anggaran, besaran anggaran ?',
                'ques_description' => 'Dokumen tersedia dalam bentuk fisik/file di ruang layanan informasi/PPID dan atau website/online',
                'link_drive' => 'https://drive.google.com/drive/folders/1Qan40FsG6HtexrR3-dOh0z0yIoka3msa?usp=sharing',
                'link_ppid' => 'https://ppid.bps.go.id/app/konten/3500/Program-Kerja.html#pills-5',
            ],
            [
                'order_no' => 19, 'id_indicators' => 2, 'id_sub_indicators' => 4, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdr menyediakan Dokumen  program-program atau kegiatan Badan Publik yang  sedang dilaksanakan Tahun 2026 yang sekurang-kurangnya memuat nama program/kegiatan, realisasi anggaran, pencapaian kegiatan ?',
                'ques_description' => 'Dokumen tersedia dalam bentuk fisik/file di ruang layanan informasi/PPID dan atau website/online',
                'link_drive' => 'https://drive.google.com/drive/folders/1gM7Qg-Nx6gj_GO9Q76MmkLtmrcrNoi-B?usp=sharing',
                'link_ppid' => 'https://ppid.bps.go.id/app/konten/3500/Program-Kerja.html#pills-5',
            ],
            [
                'order_no' => 20, 'id_indicators' => 2, 'id_sub_indicators' => 4, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdr menyediakan Dokumen   program-program atau kegiatan Badan Publik yang  telah  dilaksanakan Tahun 2025 yang sekurang-kurangnya memuat nama program/kegiatan, realisasi anggaran, pencapaian kegiatan ?',
                'ques_description' => 'Laporan Realisasi Anggaran dan Dokumen keuangan dalam bentuk DIPA Tahun 2025. Dokumen tersedia dalam bentuk fisik/file di ruang layanan informasi/PPID dan atau website/online',
                'link_drive' => 'https://drive.google.com/drive/folders/1rKvmlS_3N0zf4LF1a6XegD2RmTbVPRjh?usp=sharing',
                'link_ppid' => 'https://ppid.bps.go.id/app/konten/3500/Informasi-Tentang-Kepegawaian-dan-Keuangan.html',
            ],
            [
                'order_no' => 21, 'id_indicators' => 2, 'id_sub_indicators' => 4, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdr menyediakan dokumen pengadaan barang dan jasa  yang telah diumumkan dan telah serah terima pekerjaan Tahun 2025?',
                'ques_description' => 'Dokumen tersedia dalam bentuk fisik/file di ruang layanan informasi/PPID dan/atau website. Badan Publik memilih salah satu dari 5 paket yang telah serah terima pekerjaan Tahun 2025 (yang telah disebutkan di indikator kualitas informasi nomor 17) untuk diuraikan rinciannya sebagaimana Pasal 15 Ayat (9) PERKI No. 1 Tahun 2021 tentang Standar Layanan Informasi Publik',
                'link_drive' => 'https://drive.google.com/drive/folders/1QffcQO_fBouM9DNG2UXLmnK_JdIL4RG2?usp=drive_link',
                'link_ppid' => 'https://ppid.bps.go.id/app/konten/3500/Pengadaan.html',
            ],
            [
                'order_no' => 22, 'id_indicators' => 2, 'id_sub_indicators' => 4, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdr menyediakan dokumen peraturan, keputusan, dan/atau kebijakan yang telah ditetapkan oleh Badan Publik Sdr terkait Keterbukaan Informasi Publik?',
                'ques_description' => 'Yang dimaksud adalah menyediakan dokumen peraturan, keputusan dan/atau kebijakan yang telah ditetapkan/disahkan',
                'link_drive' => 'https://drive.google.com/drive/folders/1jPViLLNsEXUHWHZAAw5_q3ezXr1nASBW?usp=sharing',
                'link_ppid' => 'https://ppid.bps.go.id/app/konten/3500/Profil-PPID.html#pills-2',
            ],
            [
                'order_no' => 23, 'id_indicators' => 2, 'id_sub_indicators' => 4, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdr menyediakan dokumen Surat Menyurat pimpinan atau pejabat Badan Publik dalam rangka pelaksanaan tugas pokok dan fungsinya ?',
                'ques_description' => 'Yang dimaksud adalah tersedianya dokumen surat menyurat pimpinan Badan Publik selama tahun 2025.',
                'link_drive' => 'https://drive.google.com/drive/folders/1pkKj1DKBoDiMI9GSa5wwkbeygJJu1wrr?usp=sharing',
                'link_ppid' => 'https://ppid.bps.go.id/app/konten/3500/Daftar-Informasi-Publik.html',
            ],
            [
                'order_no' => 24, 'id_indicators' => 2, 'id_sub_indicators' => 4, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdr menyediakan laporan tentang data aset / Barang Milik Negara ?',
                'ques_description' => 'Yang dimaksud adalah tersedianya dokumen data aset Badan Publik Sdr dalam rentang waktu tahun 2025.',
                'link_drive' => 'https://drive.google.com/drive/folders/166fa7UMIQWk-uV1SimjLouW60D096M-t?usp=sharing',
                'link_ppid' => 'https://ppid.bps.go.id/app/konten/3500/Informasi-Tentang-Kepegawaian-dan-Keuangan.html#pills-2',
            ],
            [
                'order_no' => 25, 'id_indicators' => 2, 'id_sub_indicators' => 4, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdr menyediakan dokumen rencana strategis dan rencana kerja Badan Publik Tahun 2025-2026 ?',
                'ques_description' => 'Yang dimaksud adalah tersedianya: 1. rencana strategis Badan Publik yang masih berlaku, 2. rencana kerja Badan Publik tahun 2025-2026',
                'link_drive' => 'https://drive.google.com/drive/folders/1Z3Mnje7kJ5J0x226ym7SJiu2CVZPD4mi?usp=sharing',
                'link_ppid' => 'https://ppid.bps.go.id/app/konten/3500/Program-Kerja.html#pills-3',
            ],
            [
                'order_no' => 26, 'id_indicators' => 2, 'id_sub_indicators' => 5, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdr mengumumkan dan menyediakan berapa Jumlah Permintaan/Permohonan Informasi Publik yang diterima ?',
                'ques_description' => 'Yang dimaksud adalah berupa Rekap yang menunjukkan Jumlah Permintaan/Permohonan Informasi Publik baik secara Online maupun Offline, atau Jika Tidak Ada dapat melampirkan Surat keterangan Bahwa tidak ada Data tsb dan ditandatangani oleh Atasan PPID/Kepala Badan Publik',
                'link_drive' => 'https://docs.google.com/spreadsheets/d/1ahhdkAUNuIZEWjxl69SliudUKgsWq1VG/edit?gid=558355032#gid=558355032',
                'link_ppid' => 'https://ppid.bps.go.id/app/konten/3500/Ringkasan-Laporan-Layanan-Informasi.html#pills-0',
            ],
            [
                'order_no' => 27, 'id_indicators' => 2, 'id_sub_indicators' => 5, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdr mengumumkan dan menyediakan berapa Jumlah Waktu yang diperlukan dalam memenuhi setiap Permintaan/Permohonan Informasi Publik ?',
                'ques_description' => 'Yang dimaksud adalah berupa Rekapan Jumlah Permintaan/Permohonan Informasi Publik baik secara Online maupun Offline, atau Jika Tidak Ada dapat melampirkan Surat keterangan Bahwa tidak ada Data tsb dan ditandatangani oleh Atasan PPID/Kepala Badan Publik',
                'link_drive' => 'https://docs.google.com/spreadsheets/d/1ahhdkAUNuIZEWjxl69SliudUKgsWq1VG/edit?gid=558355032#gid=558355032',
                'link_ppid' => 'https://ppid.bps.go.id/app/konten/0000/Ringkasan-Laporan-Layanan-Informasi.html',
            ],
            [
                'order_no' => 28, 'id_indicators' => 2, 'id_sub_indicators' => 5, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdr mengumumkan dan menyediakan berapa  Jumlah Permintaan Informasi Publik yang dikabulkan baik sebagian atau seluruhnya dan Permintaan Informasi Publik yang ditolak ?',
                'ques_description' => 'Menyampaikan Jumlah permohonan informasi publik yang dikabulkan sebagian atau seluruhnya dan Menyampaikan  Alasan penolakan permohonan informasi publik, atau Jika Tidak Ada dapat melampirkan Surat keterangan Bahwa tidak ada Data tsb dan ditandatangani oleh Atasan PPID/Kepala Badan Publik.',
                'link_drive' => 'https://docs.google.com/spreadsheets/d/1ahhdkAUNuIZEWjxl69SliudUKgsWq1VG/edit?gid=558355032#gid=558355032',
                'link_ppid' => 'https://ppid.bps.go.id/app/konten/3500/Ringkasan-Laporan-Layanan-Informasi.html#pills-5',
            ],
            [
                'order_no' => 29, 'id_indicators' => 2, 'id_sub_indicators' => 5, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdr menyampaikan salinan laporan tahunan layanan Informasi Publik/PPID tahun 2025 ke Komisi Informasi Provinsi Jawa Timur ?',
                'ques_description' => 'Yang dimaksud lengkap adalah laporan sekurang-kurangnya berisi/memuat tentang sarana dan prasrana, sumber daya pengelola, anggaran dan penggunaanya,  rekap daftar pelayanan informasi,  dan jenis informasi publik yang diajukan oleh pemohon informasi.',
                'link_drive' => 'https://drive.google.com/drive/folders/1hlxqsVJBOSU5RI4gr-I90yx_U-E6zo7S?usp=sharing',
                'link_ppid' => 'https://ppid.bps.go.id/app/konten/3500/Laporan-PPID.html',
            ],
            [
                'order_no' => 30, 'id_indicators' => 2, 'id_sub_indicators' => 5, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdr mengumumkan informasi yang dapat membahayakan Hajat Hidup Orang Banyak dan ketertiban Umum ?',
                'ques_description' => 'Yang dimaksud misalnya memuat:',
                'link_drive' => 'https://drive.google.com/drive/folders/1DLt7EmER6-XKTWnWf9_XbscyOMZdGw3G?usp=drive_link',
                'link_ppid' => 'https://ppid.bps.go.id/app/3500/serta_merta',
            ],

            // ══════════════════════════════════════════════════════════════
            // INDIKATOR 3: PELAYANAN INFORMASI
            // ══════════════════════════════════════════════════════════════
            [
                'order_no' => 31, 'id_indicators' => 3, 'id_sub_indicators' => 6, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdr menyediakan dan mengumumkan Tata Cara memperoleh Informasi Publik disertai informasi waktu dan syarat Permintaan/Permohonan ?',
                'ques_description' => 'Tata Cara Pelayanan Permintaan/Permohonan Informasi dan Dokumentasi Publik.  Tata Cara yang dimaksud berupa infografis/konten yang diumumkan pada kanal informasi (online/offline) milik Badan Publik.',
                'link_drive' => 'https://drive.google.com/drive/folders/1hzak73zS0wPbqdxE3DPh4iV-2CHeiedi?usp=drive_link',
                'link_ppid' => 'https://ppid.bps.go.id/app/konten/3500/Standar-Layanan-Informasi-Publik.html#pills-6',
            ],
            [
                'order_no' => 32, 'id_indicators' => 3, 'id_sub_indicators' => 6, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdr menyediakan dan mengumumkan  Tata Cara pengajuan keberatan dan proses penyelesaian sengketa Informasi Publik berikut pihak-pihak yang bertanggungjawab yang dapat dihubungi ?',
                'ques_description' => 'Tata Cara Pelayanan Permohonan Keberatan Informasi dan Dokumentasi Publik serta Proses Penyelesaian Sengketa Informasi Publik.  Tata Cara yang dimaksud berupa infografis/konten yang diumumkan pada kanal informasi (online/offline) milik Badan Publik.',
                'link_drive' => 'https://drive.google.com/drive/folders/1ZPy-sux9iJ1FGCp0njnB6rdgKyV3QOQ3',
                'link_ppid' => 'https://ppid.bps.go.id/app/konten/3500/Standar-Layanan-Informasi-Publik.html',
            ],
            [
                'order_no' => 33, 'id_indicators' => 3, 'id_sub_indicators' => 6, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdr menyediakan dan mengumumkan Tata cara pengaduan penyalahgunaan wewenang atau pelanggaran oleh pejabat Badan Publik ?',
                'ques_description' => 'Yang dimaksud adalah tata cara pengaduan yang terdapat ditingkat provinsi melalui kanal pengaduan yang ada (online/offline)',
                'link_drive' => 'https://drive.google.com/drive/folders/1AVWYrjPxLmfoPvnbzdd9Cof-xOBzLIME',
                'link_ppid' => 'https://ppid.bps.go.id/app/konten/3500/Tata-Cara-Pengaduan.html',
            ],
            [
                'order_no' => 34, 'id_indicators' => 3, 'id_sub_indicators' => 6, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdr menyediakan dan mengumumkan Tata cara pengaduan penyalahgunaan wewenang atau pelanggaran oleh pihak yang mendapatkan izin atau perjanjian kerja dari Badan Publik yang bersangkutan ?',
                'ques_description' => 'Yang dimaksud adalah tata cara pengaduan yang terdapat ditingkat provinsi melalui kanal pengaduan yang ada (online/offline)',
                'link_drive' => 'https://drive.google.com/drive/folders/1x74jlNJ2A1pBbAw-uTHGLYGHyAD9OZnw',
                'link_ppid' => 'https://ppid.bps.go.id/app/konten/3500/Tata-Cara-Pengaduan.html',
            ],
            [
                'order_no' => 35, 'id_indicators' => 3, 'id_sub_indicators' => 7, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdr menyediakan buku atau daftar register permohonan informasi publik yang sekurang-kurangnya memuat nama pemohon, alamat pemohon, informasi yang diminta, dan alasan penolakan bilamana permohonan informasi  ditolak ?',
                'ques_description' => 'Buku atau daftar register permohonan informasi publik yang tersedia pada ruangan layanan informasi publik/PPID',
                'link_drive' => 'https://docs.google.com/spreadsheets/d/1ahhdkAUNuIZEWjxl69SliudUKgsWq1VG/edit?usp=sharing&ouid=117014170219577938176&rtpof=true&sd=true',
                'link_ppid' => '',
            ],
            [
                'order_no' => 36, 'id_indicators' => 3, 'id_sub_indicators' => 7, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdr Menyediakan dokumen jawaban PPID atas penolakan permohonan informasi ?',
                'ques_description' => 'Yang dimaksud adalah daftar dokumen jawaban (surat berikut lampiran jika ada) PPID atas Penolakan Permintaan/Permohonan Informasi yang tersedia secara offline/online, atau Jika Tidak Ada dapat melampirkan Surat keterangan tidak ada data yang di tandatangani oleh Atasan PPID/Kepala Pemkab/Pemkot.',
                'link_drive' => 'https://drive.google.com/drive/folders/1YD6jXYbyUbnWNyfYr0F4UqHWYKZso3Ye?usp=drive_link',
                'link_ppid' => 'https://ppid.bps.go.id/app/konten/3500/Standar-Layanan-Informasi-Publik.html#pills-6',
            ],
            [
                'order_no' => 37, 'id_indicators' => 3, 'id_sub_indicators' => 7, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdr Menyediakan dokumen jawaban PPID terhadap permohonan informasi yang diterima ?',
                'ques_description' => 'Yang dimaksud adalah surat jawaban dari PPID tentang Permohonan Informasi Publik yang di tandatangani oleh Atasan PPID / Kepala Pemkab/Pemkot, atau Jika Tidak Ada dapat melampirkan Surat keterangan Tidak ada data  yang di tandatangani oleh Atasan PPID/Kepala Pemkab/Pemkot',
                'link_drive' => 'https://drive.google.com/drive/folders/1j_IA5L7AKBDv_v4QbjTsfGRyHKqSHwjl?usp=drive_link',
                'link_ppid' => 'https://ppid.bps.go.id/app/konten/3500/Standar-Layanan-Informasi-Publik.html#pills-6',
            ],
            [
                'order_no' => 38, 'id_indicators' => 3, 'id_sub_indicators' => 7, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdr Menyediakan dokumen serah terima pemberian informasi hasil kesepakatan mediasi ?',
                'ques_description' => 'Yang dimaksud adalah berupa berita acara serah terima atau bukti lain pemberian informasi, atau Jika Tidak Ada dapat melampirkan Surat keterangan Tidak Pernah Bersidang yang di tandatangani oleh Atasan PPID/Kepala Badan Publik.',
                'link_drive' => 'https://drive.google.com/drive/folders/1OxQ9_hieA-tOS-aFbCoJvHfvroz_y82J?usp=drive_link',
                'link_ppid' => 'https://ppid.bps.go.id/app/konten/3500/Standar-Layanan-Informasi-Publik.html#pills-6',
            ],
            [
                'order_no' => 39, 'id_indicators' => 3, 'id_sub_indicators' => 7, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdr Menyediakan dokumen pemberitahuan kepada pemohon informasi disertai alasan dalam hal PPID membutuhkan waktu perpanjangan pemberian informasi ?',
                'ques_description' => 'Yang dimaksud yaitu Perpanjangan waktu untuk memberikan tanggapan Permohonan Informasi Publik diatur dalam Pasal 36 Peraturan Komisi Informasi No. 1 Tahun 2021 tentang Standar Layanan Informasi Publik (PerKi SLIP). Jika Tidak Ada dapat melampirkan Surat keterangan Tidak ada data yang di tandatangani oleh Atasan PPID/Kepala Badan Publik.',
                'link_drive' => 'https://drive.google.com/drive/folders/19SjWeDye_SY7zWMy4XqRCf46Ma7gx-t0?usp=drive_link',
                'link_ppid' => 'https://ppid.bps.go.id/app/konten/3500/Standar-Layanan-Informasi-Publik.html#pills-6',
            ],

            // ══════════════════════════════════════════════════════════════
            // INDIKATOR 4: SARANA DAN PRASANA
            // ══════════════════════════════════════════════════════════════
            [
                'order_no' => 40, 'id_indicators' => 4, 'id_sub_indicators' => 8, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdr menyediakan Informasi Wajib Berkala ?',
                'ques_description' => 'Yang dimaksud adalah kanal informasi seperti : website, media sosial, digital screen, roll banner, poster, spanduk, papan pengumuman dll.',
                'link_drive' => 'https://drive.google.com/drive/folders/133-HPJ9qU6Eg21eUj0VAsi6qzAA6ndDm?usp=sharing',
                'link_ppid' => 'https://ppid.bps.go.id/app/3500/berkala',
            ],
            [
                'order_no' => 41, 'id_indicators' => 4, 'id_sub_indicators' => 8, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdrr menyediakan Informasi Tersedia Setiap Saat ?',
                'ques_description' => 'Yang dimaksud adalah kanal informasi seperti : website, media sosial, digital screen, roll banner, poster, spanduk, papan pengumuman dll.',
                'link_drive' => 'https://drive.google.com/drive/folders/13ngBhuqAjsT7dwyv6Pcr3btFRDrPkgl2?usp=sharing',
                'link_ppid' => 'https://ppid.bps.go.id/app/3500/setiap_saat',
            ],
            [
                'order_no' => 42, 'id_indicators' => 4, 'id_sub_indicators' => 8, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdr menyediakan Informasi Serta Merta ?',
                'ques_description' => 'Yang dimaksud adalah kanal informasi seperti : website, media sosial, digital screen, roll banner, poster, spanduk, papan pengumuman dll.',
                'link_drive' => 'https://drive.google.com/drive/folders/16Lq5QjXoHhUw9ZSnejk788i-o8aWButz?usp=sharing',
                'link_ppid' => 'https://ppid.bps.go.id/app/3500/serta_merta',
            ],
            [
                'order_no' => 43, 'id_indicators' => 4, 'id_sub_indicators' => 8, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdrr menyediakan Informasi Dikecualikan?',
                'ques_description' => 'Yang dimaksud adalah kanal informasi seperti : website, media sosial, digital screen, roll banner, poster, spanduk, papan pengumuman dll.',
                'link_drive' => 'https://drive.google.com/drive/folders/1YPs9Yv7Io_2S9tXatXBBeGIWiXt5P2_Z?usp=sharing',
                'link_ppid' => 'https://ppid.bps.go.id/app/3500/dikecualikan',
            ],
            [
                'order_no' => 44, 'id_indicators' => 4, 'id_sub_indicators' => 8, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdr menyediakan Daftar Informasi Publik ?',
                'ques_description' => 'Yang dimaksud adalah kanal informasi seperti : website, media sosial, digital screen, roll banner, poster, spanduk, papan pengumuman dll.',
                'link_drive' => 'https://drive.google.com/drive/folders/1OtO_17y6u_MrWe_rdaBazaRpspHoJX9A?usp=sharing',
                'link_ppid' => 'https://ppid.bps.go.id/app/konten/3500/Daftar-Informasi-Publik.html',
            ],
            [
                'order_no' => 45, 'id_indicators' => 4, 'id_sub_indicators' => 8, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdr menyediakan Permohonan informasi secara online (bukan mengunduh formulir permohonan) ?',
                'ques_description' => 'Yang dimaksud adalah berupa formulir permohonan informasi online dari Badan Publik sendiri atau link Permohonan Informasi Publik pada PPID Utama',
                'link_drive' => 'https://drive.google.com/drive/folders/17tta7tqIjSB_v_oUMq8uGB2tfd97x6O9?usp=sharing',
                'link_ppid' => 'https://ppid.bps.go.id/app/3500/pengajuan_informasi',
            ],
            [
                'order_no' => 46, 'id_indicators' => 4, 'id_sub_indicators' => 8, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdrmenyediakan Pengajuan keberatan secara online (bukan mengunduh formulir pengajuan keberatan) ?',
                'ques_description' => 'Yang dimaksud adalah berupa formulir Pengajuan Keberatan online dari Badan Publik sendiri atau link Pengajuan Keberatan pada PPID Utama',
                'link_drive' => 'https://drive.google.com/drive/folders/1T_jGQbR-xMLD9OLASXTl0Y9vyfxhgg0u?usp=sharing',
                'link_ppid' => 'https://ppid.bps.go.id/app/form_keberatan_informasi',
            ],
            [
                'order_no' => 47, 'id_indicators' => 4, 'id_sub_indicators' => 8, 'scores' => 2.5,
                'ques_text' => 'Apakah seluruh Layanan Informasi yang disediakan oleh badan publik/unit kerja PPID terintegrasi dengan Kanal Informasi Badan Publik ? Sebutkan beberapa diantaranya.',
                'ques_description' => 'Kanal informasi terdiri dari : website, medsos, roll banner, screen digital, papan pengumuman',
                'link_drive' => 'https://drive.google.com/drive/folders/1WROpFmH5LvmxVbzuBBSC-gzCEAkCzHMu?usp=sharing',
                'link_ppid' => 'https://ppid.bps.go.id/?mfd=3500',
            ],
            [
                'order_no' => 48, 'id_indicators' => 4, 'id_sub_indicators' => 8, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdrmenyediakan  audio visual yang menayangkan layanan informasi publik/papan informasi elektronik/lainnya ?',
                'ques_description' => 'Kanal informasi terdiri dari : website, medsos, roll banner, screen digital, papan pengumuman',
                'link_drive' => 'https://drive.google.com/drive/folders/1uU4FyCaFImm_ZO7Q2RDowGhwaXGiTuV2?usp=sharing',
                'link_ppid' => 'https://drive.google.com/drive/folders/1uU4FyCaFImm_ZO7Q2RDowGhwaXGiTuV2?usp=sharing',
            ],
            [
                'order_no' => 49, 'id_indicators' => 4, 'id_sub_indicators' => 9, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdr menyediakan Ruang  Khusus Layanan Informasi/PPID ?',
                'ques_description' => 'Yang dimaksud adalah tersedianya ruangan khusus untuk layanan informasi/PPID pada badan publik',
                'link_drive' => 'https://drive.google.com/drive/folders/1KlzZH9UoEFJxOjW5JX9P2MtqgrYwbPAZ?usp=sharing',
                'link_ppid' => 'https://drive.google.com/drive/folders/1KlzZH9UoEFJxOjW5JX9P2MtqgrYwbPAZ?usp=sharing',
            ],
            [
                'order_no' => 50, 'id_indicators' => 4, 'id_sub_indicators' => 9, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdr menyediakan Formulir Permohonan Informasi ?',
                'ques_description' => 'Yang dimaksud adalah tersedianya formulir permohonan informasi di ruangan layanan informasi/PPID maupun di website badan publik dan website PPID',
                'link_drive' => 'https://drive.google.com/drive/folders/1B7gWWOOxKhTZ6FE5tc1uODAQdQcnJOMg?usp=sharing',
                'link_ppid' => 'https://ppid.bps.go.id/app/3500/pengajuan_informasi',
            ],
            [
                'order_no' => 51, 'id_indicators' => 4, 'id_sub_indicators' => 9, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdr menyediakan Formulir Keberatan ?',
                'ques_description' => 'Yang dimaksud adalah tersedianya formulir keberatan di ruangan layanan informasi/PPID maupun di website badan publik dan website PPID',
                'link_drive' => 'https://drive.google.com/drive/folders/1oLSNCCsnkXPohjDyO4hSo_wlwq1jSU6H?usp=sharing',
                'link_ppid' => 'https://ppid.bps.go.id/app/form_keberatan_informasi',
            ],
            [
                'order_no' => 52, 'id_indicators' => 4, 'id_sub_indicators' => 9, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdr menyediakan Jadwal pelayanan informasi publik ?',
                'ques_description' => 'Yang dimaksud adalah tersediannya Jadwal pelayanan informasi publik di ruangan layanan informasi/PPID maupun di website badan publik dan website PPID',
                'link_drive' => 'https://drive.google.com/drive/folders/1P8yHMCHaCPkH3_au-2prfNS9sVc0BJ3m?usp=sharing',
                'link_ppid' => 'https://ppid.bps.go.id/app/konten/3500/Standar-Layanan-Informasi-Publik.html#pills-4',
            ],
            [
                'order_no' => 53, 'id_indicators' => 4, 'id_sub_indicators' => 9, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdr menyediakan Layanan Pendukung Lainnya ?',
                'ques_description' => 'Yang dimaksud adalah layanan pendukung lainnya dalam rangka layanan informasi/PPID. Contoh: Kursi, komputer, dll',
                'link_drive' => 'https://drive.google.com/drive/folders/1yYUO_Kz3D-h7S2Op_ReTxKC6sGssiRj6?usp=sharing',
                'link_ppid' => 'https://drive.google.com/drive/folders/1yYUO_Kz3D-h7S2Op_ReTxKC6sGssiRj6?usp=sharing',
            ],
            [
                'order_no' => 54, 'id_indicators' => 4, 'id_sub_indicators' => 10, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdr menyediakan Aksesibilitas Disabilitas Wicara ?',
                'ques_description' => 'Online dan offline',
                'link_drive' => 'https://drive.google.com/drive/folders/10nk0YwCjLCNqGUaX3lEXvr7O_mUb9_un?usp=sharing',
                'link_ppid' => 'https://ppid.bps.go.id/app/konten/3500/Layanan-BPS.html#pills-8',
            ],
            [
                'order_no' => 55, 'id_indicators' => 4, 'id_sub_indicators' => 10, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdr menyediakan Aksesibilitas Disabilitas Rungu ?',
                'ques_description' => 'Online dan offline',
                'link_drive' => 'https://drive.google.com/drive/folders/10nk0YwCjLCNqGUaX3lEXvr7O_mUb9_un?usp=sharing',
                'link_ppid' => 'https://ppid.bps.go.id/app/konten/3500/Layanan-BPS.html#pills-8',
            ],
            [
                'order_no' => 56, 'id_indicators' => 4, 'id_sub_indicators' => 10, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdrmenyediakan Aksesibilitas Disabilitas Lainnya ?',
                'ques_description' => 'Online dan offline
Contoh: kursi roda, buku braille, alat bantu dengar, dll',
                'link_drive' => 'https://drive.google.com/drive/folders/10nk0YwCjLCNqGUaX3lEXvr7O_mUb9_un?usp=sharing',
                'link_ppid' => 'https://ppid.bps.go.id/app/konten/3500/Layanan-BPS.html#pills-8',
            ],

            // ══════════════════════════════════════════════════════════════
            // INDIKATOR 5: KOMITMEN ORGANISASI
            // ══════════════════════════════════════════════════════════════
            [
                'order_no' => 57, 'id_indicators' => 5, 'id_sub_indicators' => 11, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdr menyediakan dan mengumumkan informasi profil PPID yang meliputi Stuktur, Visi dan Misi, dan SK Penetapan ?',
                'ques_description' => 'Tersedia dalam bentuk fisik/file di ruang layanan informasi/PPID dan atau website/online',
                'link_drive' => 'https://drive.google.com/drive/folders/1VjlBM04Q2qapVrn9zylGQXSeoiSeXm43?usp=drive_link',
                'link_ppid' => 'https://ppid.bps.go.id/app/konten/3500/Profil-PPID.html',
            ],
            [
                'order_no' => 58, 'id_indicators' => 5, 'id_sub_indicators' => 11, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdr Menyediakan dan mengumumkan tugas dan fungsi PPID ?',
                'ques_description' => 'Tersedia dalam bentuk fisik/file di ruang layanan informasi/PPID dan atau website/online',
                'link_drive' => 'https://drive.google.com/drive/folders/1NjvabuHIlJQCeC2wiTKgvxpU6_g0Xxns?usp=drive_link',
                'link_ppid' => 'https://ppid.bps.go.id/app/konten/3500/Profil-PPID.html#pills-3',
            ],
            [
                'order_no' => 59, 'id_indicators' => 5, 'id_sub_indicators' => 11, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdr Menyediakan dan mengumumkan  SOP standar pelayanan informasi publik ?',
                'ques_description' => '(Yang dimaksud adalah SOP yang sifatnya berbentuk Surat Keputusan atau Ketetapan dalam Standar Layanan Informasi Publik)',
                'link_drive' => 'https://drive.google.com/drive/folders/1hQYk5s8jtE8xwv0BTfGhcbL5ZdwKoAa5?usp=drive_link',
                'link_ppid' => 'https://ppid.bps.go.id/app/konten/3500/Standar-Layanan-Informasi-Publik.html#pills-1',
            ],
            [
                'order_no' => 60, 'id_indicators' => 5, 'id_sub_indicators' => 11, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdr Menyediakan dan mengumumkan SOP Permohonan Informasi ?',
                'ques_description' => 'Tersedia dalam bentuk fisik/file di ruang layanan informasi/PPID dan atau website/online',
                'link_drive' => 'https://drive.google.com/drive/folders/1mujCJJtV4zh7GCsMiNWhyMm778t9lhcc?usp=drive_link',
                'link_ppid' => 'https://ppid.bps.go.id/app/konten/3500/Standar-Layanan-Informasi-Publik.html#pills-6',
            ],
            [
                'order_no' => 61, 'id_indicators' => 5, 'id_sub_indicators' => 11, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdr Menyediakan dan mengumumkan SOP Uji Konsekuensi ?',
                'ques_description' => 'Tersedia dalam bentuk fisik/file di ruang layanan informasi/PPID dan atau website/online',
                'link_drive' => 'https://drive.google.com/drive/folders/178KcYQqE4_o_-jJrVpYwbHGM4s4b1Iw2?usp=drive_link',
                'link_ppid' => 'https://ppid.bps.go.id/app/konten/3500/Standar-Layanan-Informasi-Publik.html#pills-6',
            ],
            [
                'order_no' => 62, 'id_indicators' => 5, 'id_sub_indicators' => 11, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik SdrMenyediakan dan mengumumkan SOP Penetapan dan pemutakhiran daftar informasi publik ?',
                'ques_description' => 'Tersedia dalam bentuk fisik/file di ruang layanan informasi/PPID dan atau website/online',
                'link_drive' => 'https://drive.google.com/drive/folders/1LeipQYphS3QIgndB7J2LhTgfbqSMts1V?usp=drive_link',
                'link_ppid' => 'https://ppid.bps.go.id/app/konten/3500/Standar-Layanan-Informasi-Publik.html#pills-6',
            ],

            // ══════════════════════════════════════════════════════════════
            // INDIKATOR 6: DIGITALISASI
            // ══════════════════════════════════════════════════════════════
            [
                'order_no' => 63, 'id_indicators' => 6, 'id_sub_indicators' => 12, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdr Menyediakan dan mengumumkan SOP Pendokumentasian informasi publik ?',
                'ques_description' => 'Tersedia dalam bentuk fisik/file di ruang layanan informasi/PPID dan atau website/online',
                'link_drive' => 'https://drive.google.com/drive/folders/1DRkrIW6HUOsnpYb5JaUMKT2sglP5DLp5?usp=drive_link',
                'link_ppid' => 'https://ppid.bps.go.id/app/konten/3500/Standar-Layanan-Informasi-Publik.html#pills-6',
            ],
            [
                'order_no' => 64, 'id_indicators' => 6, 'id_sub_indicators' => 12, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdr Menyediakan dan mengumumkan Maklumat Pelayanan ?',
                'ques_description' => '(Yang dimaksud dapat secara online dan offline, Online tertera pada website atau media onlien lainnya. Offline dapat berupa Roll Banner, Poster, Layar Digital, dll.)',
                'link_drive' => 'https://drive.google.com/drive/folders/1CLbZV6SOkeLMNy0J1yD3XxUY0swv_7ex?usp=drive_link',
                'link_ppid' => 'https://ppid.bps.go.id/app/konten/3500/Standar-Layanan-Informasi-Publik.html#pills-1',
            ],
            [
                'order_no' => 65, 'id_indicators' => 6, 'id_sub_indicators' => 12, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdr Melakukan pembinaan, pengawasan, evaluasi, dan monitoring atas pelaksanaan kebijakan Informasi Publik?',
                'ques_description' => '(Yang dimaksud adalah dokumen yang sifatnya berisi agenda pembinaan terkait Kebijakan Informasi Publik atau jika Tidak Ada dapat melampirkan Surat keterangan Bahwa tidak ada Data tsb dan ditandatangani oleh Atasan PPID/Kepala Badan Publik.)',
                'link_drive' => 'https://drive.google.com/drive/folders/1yv4rKu6zapt-m1eei6_66G6HlZHE6mhE?usp=drive_link',
                'link_ppid' => 'https://ppid.bps.go.id/app/konten/3500/Laporan-PPID.html',
            ],
            [
                'order_no' => 66, 'id_indicators' => 6, 'id_sub_indicators' => 12, 'scores' => 2.5,
                'ques_text' => 'Apakah badan publik Sdr Melakukan Rapat Koordinasi Rutin dengan Internal Badan Publik terkait Pelayanan Informasi Publik di PPID Badan Publik ?',
                'ques_description' => '(Yang dimaksud adalah dokumen yang sifatnya berisi kegiatan rapat koordinasi terkait Pelayanan Informasi Publik di PPID Badan Publik',
                'link_drive' => 'https://drive.google.com/drive/folders/1QVrHKEnizjRHCoBan0xpZ1-JFwYuTwJ1?usp=drive_link',
                'link_ppid' => 'https://ppid.bps.go.id/app/konten/3500/Laporan-PPID.html',
            ],
            [
                'order_no' => 67, 'id_indicators' => 6, 'id_sub_indicators' => 12, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdr mengoordinasikan dan mengonsolidasikan proses penyimpanan, pendokumentasian, penyediaan, dan pelayanan Informasi Publik ?',
                'ques_description' => 'yang dimaksud adalah dokumentasi kegiatan koordinasi dan konsolidasi.',
                'link_drive' => 'https://drive.google.com/drive/folders/1_JYmBImBEm4KgVUBA8JL2fHzoKZEtn8F?usp=sharing',
                'link_ppid' => 'https://ppid.bps.go.id/app/konten/3500/Laporan-PPID.html',
            ],
            [
                'order_no' => 68, 'id_indicators' => 6, 'id_sub_indicators' => 12, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdr  Mengoordinasikan dan mengonsolidasikan pengumpulan dokumen Informasi Publik di internal Badan Publik ?',
                'ques_description' => 'yang dimaksud adalah dokumentasi kegiatan koordinasi dan konsolidasi.',
                'link_drive' => 'https://drive.google.com/drive/folders/1-WtPF9fDQ9ZorunNO1oFQ29q9XTOS3zU?usp=sharing',
                'link_ppid' => 'https://ppid.bps.go.id/app/konten/3500/Laporan-PPID.html',
            ],
            [
                'order_no' => 69, 'id_indicators' => 6, 'id_sub_indicators' => 12, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdr menyediakan anggaran pendukung kegiatan pelayanan keterbukaan informasi / PPID',
                'ques_description' => 'Yang dimaksud adalah dokumen anggaran yang mencantumkan dukungan anggaran kegiatan pelayanan informasi/PPID',
                'link_drive' => 'https://drive.google.com/drive/folders/14azieLjCjjWLDmx75yINrFPWHNVhmcDz?usp=drive_link',
                'link_ppid' => 'https://ppid.bps.go.id/app/konten/3500/Informasi-Tentang-Kepegawaian-dan-Keuangan.html',
            ],
            [
                'order_no' => 70, 'id_indicators' => 6, 'id_sub_indicators' => 12, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdr mengumumkan Informasi berkaitan ruang lingkup, tugas dan fungsi Badan Publik ?',
                'ques_description' => 'Terpublikasi di website, media sosial, media online dan kanal infromasi lainya',
                'link_drive' => 'https://drive.google.com/file/d/1Sf69rrAuYaG6hm2bsXlNWUVtz0h9Rt9F/view?usp=drive_link',
                'link_ppid' => 'https://ppid.bps.go.id/app/konten/3500/Profil-BPS.html#pills-3',
            ],
            [
                'order_no' => 71, 'id_indicators' => 6, 'id_sub_indicators' => 13, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdr mengumumkan Informasi berkaitan program dan kegiatan strategis sesuai ruang lingkup, tugas dan fungsi Badan Publik ?',
                'ques_description' => 'Terpublikasi di website, media sosial, media online dan kanal infromasi lainya',
                'link_drive' => 'https://drive.google.com/file/d/11I_2FrXWkJPurfgm7zjBmfXr2FDor48-/view?usp=drive_link',
                'link_ppid' => 'https://ppid.bps.go.id/app/konten/3500/Kegiatan.html',
            ],
            [
                'order_no' => 72, 'id_indicators' => 6, 'id_sub_indicators' => 13, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdr mengumumkan Informasi berkaitan penggunaan atau realisasi anggaran Tahun 2025-2026 ?',
                'ques_description' => 'Terpublikasi di website, media sosial, media online dan kanal infromasi lainya',
                'link_drive' => 'https://drive.google.com/file/d/16L-fE9Fp7iLfHmI1aPn7pGyZLCa4vdWu/view?usp=drive_link',
                'link_ppid' => 'https://ppid.bps.go.id/app/konten/3500/Informasi-Tentang-Kepegawaian-dan-Keuangan.html#pills-0',
            ],
            [
                'order_no' => 73, 'id_indicators' => 6, 'id_sub_indicators' => 14, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdr mengumumkan informasi Laporan Realisasi Anggaran dan Dokumen keuangan dalam bentuk DIPA Tahun 2026-2026',
                'ques_description' => 'Terpublikasi di website, media sosial, media online dan kanal infromasi lainya',
                'link_drive' => 'https://drive.google.com/file/d/16L-fE9Fp7iLfHmI1aPn7pGyZLCa4vdWu/view?usp=drive_link',
                'link_ppid' => 'https://ppid.bps.go.id/app/konten/3500/Laporan-Keuangan.html#pills-1',
            ],
            [
                'order_no' => 74, 'id_indicators' => 6, 'id_sub_indicators' => 14, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdr mengumumkan Informasi berkaitan tata cara pengajuan permohonan informasi ?',
                'ques_description' => 'Terpublikasi di website, media sosial, media online dan kanal infromasi lainya',
                'link_drive' => 'https://drive.google.com/file/d/1cTcBKEIa0N2EdXRBAhz96-aKZp3aYlWN/view?usp=drive_link',
                'link_ppid' => 'https://ppid.bps.go.id/app/konten/3500/Standar-Layanan-Informasi-Publik.html#pills-6',
            ],
            [
                'order_no' => 75, 'id_indicators' => 6, 'id_sub_indicators' => 15, 'scores' => 2.5,
                'ques_text' => 'Apakah Badan Publik Sdrmengumumkan Informasi berkaitan  alasan yang dapat digunakan Pemohon Informasi mengajukan keberatan ?',
                'ques_description' => 'Terpublikasi di website, media sosial, media online dan kanal infromasi lainya',
                'link_drive' => 'https://drive.google.com/file/d/1M0IcIWjX63JdER1rhkbZ32Ud2UEXC5jh/view?usp=drive_link',
                'link_ppid' => 'https://ppid.bps.go.id/app/konten/3500/Standar-Layanan-Informasi-Publik.html#pills-7',
            ],
        ];

        // Truncate or bulk-insert / update
        // We update existing or insert new without breaking foreign keys
        foreach ($questions as $q) {
            DB::table('master_pertanyaan')->updateOrInsert(
                ['order_no' => $q['order_no']],
                [
                    'id_indicators'     => $q['id_indicators'],
                    'id_sub_indicators' => $q['id_sub_indicators'],
                    'ques_text'         => $q['ques_text'],
                    'ques_description'  => $q['ques_description'],
                    'doc_requirement'   => null,
                    'link_drive'        => $q['link_drive'] ?? null,
                    'link_ppid'         => $q['link_ppid'] ?? null,
                    'bobot_pertanyaan'  => $q['scores'],
                ]
            );
        }
    }
}
