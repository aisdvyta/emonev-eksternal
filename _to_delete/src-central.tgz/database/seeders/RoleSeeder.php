<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Role;

class RoleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $roles = [
            'admin',
            'evaluator',
            'verifikator',
            'operator',
            'super_evaluator',
            'penilai_eksternal',
            // 'kabag' dihapus — user kabag kini ber-role super_evaluator
        ];

        foreach ($roles as $role) {
            Role::firstOrCreate(['name' => $role]);
        }
    }
}
