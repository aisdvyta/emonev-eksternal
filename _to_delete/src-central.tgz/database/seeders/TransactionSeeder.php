<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class TransactionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Fetch all seeded master questions from DB to generate answers
        $dbQuestions = DB::table('master_pertanyaan')->get();
        $scoreCol = 'bobot_pertanyaan';
        $linkMeetingCol = \Illuminate\Support\Facades\Schema::hasColumn('visitasi', 'link_meet_visitasi') ? 'link_meet_visitasi' : 'link_meeting';
        $meetsLinkCol = \Illuminate\Support\Facades\Schema::hasColumn('interview', 'link_meet_interview') ? 'link_meet_interview' : 'meets_link';

        $satkersAll = [
            '3501', '3502', '3503', '3504', '3505', '3506', '3507', '3508', '3509', '3510',
            '3511', '3512', '3513', '3514', '3515', '3516', '3517', '3518', '3519', '3520',
            '3521', '3522', '3523', '3524', '3525', '3526', '3527', '3528', '3529',
            '3571', '3572', '3573', '3574', '3575', '3576', '3577', '3578', '3579',
        ];

        $ratiosMatrix = [
            // 8 lolos submissions (Target average / ratios for 6 indicators)
            0 => [0.95, 0.90, 0.96, 0.88, 0.92, 0.91], // avg = ~92% (BPS Kab. Pacitan)
            1 => [0.86, 0.92, 0.84, 0.90, 0.88, 0.90], // avg = ~88% (BPS Kab. Ponorogo)
            2 => [0.98, 0.96, 0.94, 0.92, 0.95, 0.95], // avg = ~95% (BPS Kab. Trenggalek)
            3 => [0.80, 0.85, 0.82, 0.88, 0.84, 0.85], // avg = ~84% (BPS Kab. Tulungagung)
            4 => [0.92, 0.88, 0.90, 0.94, 0.86, 0.90], // avg = ~90% (BPS Kab. Blitar)
            5 => [0.84, 0.80, 0.82, 0.85, 0.80, 0.81], // avg = ~82% (BPS Kab. Kediri)
            6 => [0.90, 0.85, 0.88, 0.84, 0.85, 0.84], // avg = ~86% (BPS Kab. Malang)
            7 => [0.80, 0.80, 0.80, 0.80, 0.80, 0.80], // avg = 80.00% (BPS Kab. Lumajang - 3508)

            // 6 gugur submissions (must have at least one indicator < 80%)
            8 => [0.50, 0.50, 0.70, 0.50, 0.50, 0.70],
            9 => [0.50, 0.50, 0.50, 0.50, 0.70, 0.50],
            10 => [0.70, 0.50, 0.70, 0.50, 0.70, 0.70],
            11 => [0.50, 0.50, 0.50, 0.70, 0.50, 0.50],
            12 => [0.70, 0.50, 0.70, 0.50, 0.70, 0.70],
            13 => [0.70, 0.50, 0.70, 0.50, 0.70, 0.50],
        ];

        $makeAnswers = function (int $submissionId, array $indicatorRatios, int $evaluatorId = 2) use ($dbQuestions) {
            $answers = [];
            foreach ($dbQuestions as $q) {
                $qRatio = $indicatorRatios[$q->id_indicators - 1] ?? 1.0;
                $qScore = $q->bobot_pertanyaan ?? 2.5;
                $rawEarned = round($qScore * $qRatio, 2);

                // Map to valid dropdown options [0, 1, 2, 2.5]
                $options = [0, 1, 2, 2.5];
                $earned = 0;
                $minDiff = 999;
                foreach ($options as $opt) {
                    $diff = abs($rawEarned - $opt);
                    if ($diff < $minDiff) {
                        $minDiff = $diff;
                        $earned = $opt;
                    }
                }

                // Force 2.25 to 2.00 as requested
                if ($rawEarned == 2.25) {
                    $earned = 2.0;
                }

                $answers[] = [
                    'id_answer' => Str::uuid()->toString(),
                    'id_question' => $q->id_master_pertanyaan,
                    'id_submission' => $submissionId,
                    'id_indicators' => $q->id_indicators,
                    'answer' => 1,
                    'link_ppid' => 'https://bps.go.id/ppid/contoh-'.$q->id_master_pertanyaan,
                    'link_drive' => 'https://drive.google.com/drive/folders/bukti-dukung-sub'.$submissionId.'-q'.$q->id_master_pertanyaan,
                    'answer_score' => $earned,
                    'evaluator_note' => $earned == 2.5 ? 'Good job! sudah lengkap, dipertahankan.' : 'Dokumen bukti dukung telah sesuai.',
                    'evaluator_at' => now()->subDays(rand(1, 10)),
                ];
            }

            return $answers;
        };

        $makeOperatorAnswers = function (int $submissionId) use ($dbQuestions) {
            $answers = [];
            foreach ($dbQuestions as $q) {
                $answers[] = [
                    'id_answer' => Str::uuid()->toString(),
                    'id_question' => $q->id_master_pertanyaan,
                    'id_submission' => $submissionId,
                    'id_indicators' => $q->id_indicators,
                    'answer' => 1,
                    'link_ppid' => 'https://bps.go.id/ppid/q-'.$q->id_master_pertanyaan,
                    'link_drive' => 'https://drive.google.com/drive/folders/bukti-dukung-sub'.$submissionId.'-q'.$q->id_master_pertanyaan,
                    'answer_score' => null,
                    'evaluator_note' => null,
                    'evaluator_at' => null,
                ];
            }

            return $answers;
        };

        $makeOpDraft = function (int $subId, $questions): array {
            $rows = [];
            foreach ($questions as $q) {
                $rows[] = [
                    'id_answer' => Str::uuid()->toString(),
                    'id_question' => $q->id_master_pertanyaan,
                    'id_submission' => $subId,
                    'id_indicators' => $q->id_indicators,
                    'answer' => 1,
                    'link_ppid' => 'https://bps.go.id/ppid/draft-'.$q->id_master_pertanyaan,
                    'link_drive' => 'https://drive.google.com/drive/folders/bukti-dukung-draft-q'.$q->id_master_pertanyaan,
                    'answer_score' => null,
                    'evaluator_note' => null,
                    'evaluator_at' => null,
                ];
            }

            return $rows;
        };

        $now = now();
        $idResultCounter = 1;
        $activePeriodId = 3; // Periode 2026

        // Helper: build id_operator JSON with name snapshot
        $opEntry = function (int $id) {
            $u = DB::table('users')->where('id_user', $id)->first();

            return ['id' => $id, 'nama' => $u->nama_user ?? 'op_'.$id];
        };

        // Helper: build evaluated_by JSON with name snapshot
        $evalEntry = function (int $id) {
            $u = DB::table('users')->where('id_user', $id)->first();

            return ['id' => $id, 'nama' => $u->nama_user ?? 'eval_'.$id];
        };

        // Helper: assign evaluator ke submission_evaluators
        $assignSubEvaluator = function (int $subId, int $userId) {
            DB::table('submission_evaluators')->updateOrInsert(
                ['id_submission' => $subId, 'id_user' => $userId],
                []
            );
        };

        // Helper: assign evaluator ke visitasi_evaluators
        $assignVisitEvaluators = function (string $visitUuid, array $visitData) {
            foreach ($visitData as $vd) {
                DB::table('visitasi_evaluators')->updateOrInsert(
                    ['id_visit' => $visitUuid, 'id_user' => $vd['id_user']],
                    [
                        'score'   => isset($vd['score']) && $vd['score'] !== '' ? floatval($vd['score']) : null,
                        'catatan' => $vd['note'] ?? $vd['catatan'] ?? null,
                        'is_draft'=> (bool) ($vd['is_draft'] ?? false),
                    ]
                );
            }
        };

        // Helper: assign evaluator ke interview_evaluators
        $assignInterviewEvaluators = function (int $interviewId, array $interviewData) {
            foreach ($interviewData as $ivd) {
                DB::table('interview_evaluators')->updateOrInsert(
                    ['id_interview' => $interviewId, 'id_user' => $ivd['id_user']],
                    [
                        'score'   => isset($ivd['score']) && $ivd['score'] !== '' ? floatval($ivd['score']) : null,
                        'catatan' => $ivd['note'] ?? $ivd['catatan'] ?? null,
                        'is_draft'=> (bool) ($ivd['is_draft'] ?? false),
                    ]
                );
            }
        };

        // ── A. 8 Lolos (status=5, saq_score ≥80) ─────────────────────────────
        for ($i = 0; $i < 8; $i++) {
            $subId = $i + 1;
            $userId = 5 + $i;
            $satker = $satkersAll[$i];
            $ratios = $ratiosMatrix[$i];

            $answersData = $makeAnswers($subId, $ratios);
            $totalEarned = array_sum(array_column($answersData, 'answer_score'));
            $totalMax = $dbQuestions->sum($scoreCol);
            $saqScore = $totalMax > 0 ? round(($totalEarned / $totalMax) * 100, 2) : 0;

            $resultId = $idResultCounter++;

            // Reset variables per iterasi agar tidak bocor antar satker
            $visitMode = 'offline';
            $visitAt = null;
            $visitScore = null;
            $visitNote = null;
            $linkBukti = null;
            $linkMeeting = null;
            $visitData = null;

            if ($i == 0) {
                // 1. Sudah dinilai (Offline / Onsite) - 3501 Pacitan
                $visitMode = 'offline';
                $visitAt = '2026-12-01';
                $visitScore = 92.00;
                $visitNote = 'Pelayanan prima; Dokumentasi lengkap.';
                $visitData = [
                    ['id_user' => 2, 'score' => 90.00, 'note' => 'Pelayanan prima', 'is_draft' => false],
                    ['id_user' => 3, 'score' => 94.00, 'note' => 'Dokumentasi lengkap.', 'is_draft' => false],
                ];
            } elseif ($i == 1) {
                // 2. Sudah dinilai (Online Virtual Meeting) - 3502 Ponorogo
                $visitMode = 'online_meeting';
                $visitAt = '2026-12-01';
                $visitScore = 88.00;
                $visitNote = 'Tanggapan cepat dan sigap.';
                $linkMeeting = 'https://zoom.us/j/123456789';
                $visitData = [
                    ['id_user' => 2, 'score' => 88.00, 'note' => 'Tanggapan cepat dan sigap.', 'is_draft' => false],
                    ['id_user' => 3, 'score' => 88.00, 'note' => 'Cukup baik.', 'is_draft' => false],
                ];
            } elseif ($i == 3) {
                // 4. Terjadwal: Offline Kunjungan Lapangan - 3504 Tulungagung
                $visitMode = 'offline';
                $visitAt = '2026-12-02';
                $visitData = [
                    ['id_user' => 2, 'score' => null, 'note' => null, 'is_draft' => true],
                    ['id_user' => 3, 'score' => null, 'note' => null, 'is_draft' => true],
                ];
            } elseif ($i == 4) {
                // 5. Terjadwal: Online Virtual Meeting - 3505 Blitar
                $visitMode = 'online_meeting';
                $visitAt = '2026-12-03';
                $linkMeeting = 'https://zoom.us/j/987654321';
                $visitData = [
                    ['id_user' => 2, 'score' => null, 'note' => null, 'is_draft' => true],
                    ['id_user' => 7002, 'score' => null, 'note' => null, 'is_draft' => true],
                ];
            } elseif ($i == 5) {
                // 6. Terjadwal: Online Upload Bukti Dukung - 3506 Kediri
                $visitMode = 'online_upload';
                $visitAt = '2026-12-03';
                $linkBukti = 'https://drive.google.com/drive/folders/sample-3506-archive';
                $visitData = [
                    ['id_user' => 2, 'score' => null, 'note' => null, 'is_draft' => true],
                ];
            } else {
                // $i == 2 (3503 Trenggalek), $i == 6 (3507 Malang), $i == 7 (3508 Lumajang)
                // Belum Dijadwalkan
                $visitMode = 'offline';
                $visitAt = null;
                $visitScore = null;
                $visitNote = null;
                $linkBukti = null;
                $linkMeeting = null;
                $visitData = null;
            }

            DB::table('result')->insert([
                'id_result' => $resultId,
                'kode_satker' => $satker,
                'id_periode' => $activePeriodId,
                'ques_score' => $saqScore,
                'visit_score' => $visitScore,
                'interview_score' => null,
                'final_score' => null,
                'index_label' => null,
            ]);

            DB::table('submissions')->insert([
                'id_submission' => $subId,
                'id_result' => $resultId,
                'id_operator' => json_encode([$opEntry($userId)]),
                'verified_by' => 43 + $i,
                'verified_at' => $now->copy()->subDays(15),
                'verification_note' => 'Dokumen lengkap.',
                'status' => 5,
                'submitted_at' => $now->copy()->subDays(20),
                'evaluated_at' => $now->copy()->subDays(12),
            ]);
            $assignSubEvaluator($subId, 2, $now->copy()->subDays(12));

            DB::table('answer')->insert($answersData);

            $visitUuid = Str::uuid()->toString();

            DB::table('visitasi')->insert([
                'id_visit' => $visitUuid,
                'id_result' => $resultId,
                'visit_mode' => $visitMode,
                'visit_at' => $visitAt,
                'visit_score' => $visitScore,
                'visit_note' => $visitNote,
                $linkMeetingCol => $linkMeeting,
                'link_buktidukung' => $linkBukti,
            ]);
            if ($visitData) {
                $assignVisitEvaluators($visitUuid, $visitData);
            }

            if ($i == 0) {
                $pacitanInterviewersData = [
                    ['id_user' => 6000, 'score' => null, 'note' => null, 'is_draft' => true],
                    ['id_user' => 2, 'score' => 90.00, 'note' => 'Good job!', 'is_draft' => false],
                    ['id_user' => 3, 'score' => 90.00, 'note' => 'Good job!', 'is_draft' => false],
                ];
                $pacitanIntId = DB::table('interview')->insertGetId([
                    'id_result' => $resultId,
                    $meetsLinkCol => 'https://zoom.com',
                    'interview_at' => '2026-11-24',
                    'interview_score' => null,
                ]);
                $assignInterviewEvaluators($pacitanIntId, $pacitanInterviewersData);
            }

        }

        // ── B. 6 Gugur (status=8, saq_score <80) ─────────────────────────────
        for ($i = 0; $i < 6; $i++) {
            $subId = 9 + $i;
            $userId = 5 + 8 + $i;
            $satker = $satkersAll[8 + $i];
            $ratios = $ratiosMatrix[8 + $i];

            $answersData = $makeAnswers($subId, $ratios);
            $totalEarned = array_sum(array_column($answersData, 'answer_score'));
            $totalMax = $dbQuestions->sum($scoreCol);
            $saqScore = $totalMax > 0 ? round(($totalEarned / $totalMax) * 100, 2) : 0;

            $resultId = $idResultCounter++;

            DB::table('result')->insert([
                'id_result' => $resultId,
                'kode_satker' => $satker,
                'id_periode' => $activePeriodId,
                'ques_score' => $saqScore,
                'visit_score' => null,
                'interview_score' => null,
                'final_score' => round($saqScore * 0.3, 2),
                'index_label' => 'GUGUR',
                'published_at' => $now->copy()->subDays(10),
            ]);

            DB::table('submissions')->insert([
                'id_submission' => $subId,
                'id_result' => $resultId,
                'id_operator' => json_encode([$userId]),
                'verified_by' => 43 + 8 + $i,
                'verified_at' => $now->copy()->subDays(14),
                'verification_note' => 'Dokumen lengkap.',
                'status' => 8,
                'submitted_at' => $now->copy()->subDays(20),
                'evaluated_at' => $now->copy()->subDays(11),
            ]);
            $assignSubEvaluator($subId, 2, $now->copy()->subDays(11));

            DB::table('answer')->insert($answersData);
        }

        // ── C. 1 Sudah Submit Belum Verifikasi (status=1) ──────────────────────
        for ($i = 0; $i < 1; $i++) {
            $subId = 15 + $i;
            $userId = 5 + 8 + 6 + $i;
            $satker = $satkersAll[8 + 6 + $i];
            $resultId = $idResultCounter++;

            DB::table('result')->insert([
                'id_result' => $resultId,
                'kode_satker' => $satker,
                'id_periode' => $activePeriodId,
            ]);

            DB::table('submissions')->insert([
                'id_submission' => $subId,
                'id_result' => $resultId,
                'id_operator' => json_encode([$userId]),
                'status' => 1,
                'submitted_at' => $now->copy()->subDays(10),
            ]);

            DB::table('answer')->insert($makeOperatorAnswers($subId));
        }

        // ── C.2 Draft Mojokerto (status=0) ───────────────────────────────────
        $resultId = $idResultCounter++;
        DB::table('result')->insert([
            'id_result' => $resultId,
            'kode_satker' => '3516', // Mojokerto
            'id_periode' => $activePeriodId,
        ]);
        DB::table('submissions')->insert([
            'id_submission' => 16,
            'id_result' => $resultId,
            'id_operator' => json_encode([$opEntry(20)]),
            'status' => 0,
        ]);
        DB::table('answer')->insert($makeOpDraft(16, $dbQuestions->slice(0, 74)->values()));

        // ── D. 4 Sudah Submit Sudah Verifikasi (status=3) ──────────────────────
        for ($i = 0; $i < 4; $i++) {
            $subId = 17 + $i;
            $userId = 5 + 8 + 6 + 2 + $i;
            $verifierId = 43 + 8 + 6 + 2 + $i;
            $satker = $satkersAll[8 + 6 + 2 + $i];
            $resultId = $idResultCounter++;

            DB::table('result')->insert([
                'id_result' => $resultId,
                'kode_satker' => $satker,
                'id_periode' => $activePeriodId,
            ]);

            DB::table('submissions')->insert([
                'id_submission' => $subId,
                'id_result' => $resultId,
                'id_operator' => json_encode([$userId]),
                'verified_by' => $verifierId,
                'verified_at' => $now->copy()->subDays(5),
                'verification_note' => 'Dokumen terverifikasi lengkap.',
                'status' => 3,
                'submitted_at' => $now->copy()->subDays(10),
            ]);

            DB::table('answer')->insert($makeOperatorAnswers($subId));
        }

        // ── Seed Past Years (2024 & 2025) ──────────────────────────────────
        $pastYearsData = [
            1 => [ // Year 2024 (id_periode = 1)
                'year' => 2024,
                'start_sub_id' => 39,
                'date_prefix' => '2024',
                'pass_count' => 12,
            ],
            2 => [ // Year 2025 (id_periode = 2)
                'year' => 2025,
                'start_sub_id' => 77,
                'date_prefix' => '2025',
                'pass_count' => 15,
            ],
        ];

        foreach ($pastYearsData as $periodId => $pData) {
            $year = $pData['year'];
            $startSubId = $pData['start_sub_id'];
            $datePrefix = $pData['date_prefix'];
            $passCount = $pData['pass_count'];

            for ($j = 0; $j < 38; $j++) {
                $subId = $startSubId + $j;
                $userId = 5 + $j;
                $satker = $satkersAll[$j];

                $resultId = $idResultCounter++;

                if ($j < $passCount) {
                    // Passed SAQ & completed
                    $ratios = $ratiosMatrix[$j % 8];
                    $answersData = $makeAnswers($subId, $ratios);
                    $totalEarned = array_sum(array_column($answersData, 'answer_score'));
                    $totalMax = $dbQuestions->sum($scoreCol);
                    $saqScore = $totalMax > 0 ? round(($totalEarned / $totalMax) * 100, 2) : 0;

                    // Ensure SAQ score is at least 80
                    if ($saqScore < 80) {
                        $saqScore = 82.50;
                    }

                    $visitScore = round(80.00 + ($j % 18), 2);
                    $i1 = round(78.00 + ($j % 15), 2);
                    $i2 = round(82.00 + ($j % 15), 2);
                    $i3 = round(80.00 + ($j % 15), 2);
                    $interviewScore = round(($i1 + $i2 + $i3) / 3, 2);
                    $finalScore = round(($saqScore * 0.3) + ($visitScore * 0.4) + ($interviewScore * 0.3), 2);

                    $predikat = 'INFORMATIF';
                    if ($finalScore >= 80) {
                        $predikat = 'INFORMATIF';
                    } elseif ($finalScore >= 70) {
                        $predikat = 'MENUJU INFORMATIF';
                    } elseif ($finalScore >= 60) {
                        $predikat = 'CUKUP INFORMATIF';
                    } elseif ($finalScore >= 40) {
                        $predikat = 'KURANG INFORMATIF';
                    } else {
                        $predikat = 'TIDAK INFORMATIF';
                    }

                    DB::table('result')->insert([
                        'id_result' => $resultId,
                        'kode_satker' => $satker,
                        'id_periode' => $periodId,
                        'ques_score' => $saqScore,
                        'visit_score' => $visitScore,
                        'interview_score' => $interviewScore,
                        'final_score' => $finalScore,
                        'index_label' => $predikat,
                        'published_at' => "$datePrefix-07-01",
                    ]);

                    DB::table('submissions')->insert([
                        'id_submission' => $subId,
                        'id_result' => $resultId,
                        'id_operator' => json_encode([$opEntry($userId)]),
                        'verified_by' => 43 + ($j % 38),
                        'verified_at' => "$datePrefix-05-15",
                        'verification_note' => 'Dokumen lengkap.',
                        'status' => 7, // Completed
                        'submitted_at' => "$datePrefix-05-10",
                        'evaluated_at' => "$datePrefix-05-25",
                    ]);
                    $assignSubEvaluator($subId, 2, "$datePrefix-05-25");

                    DB::table('answer')->insert($answersData);

                    $visitUuid = Str::uuid()->toString();
                    $pastEvaluatorsData = [
                        ['id_user' => 2, 'score' => $visitScore, 'note' => 'Kunjungan lapangan berjalan tertib.', 'is_draft' => false],
                        ['id_user' => 3, 'score' => $visitScore, 'note' => 'Kunjungan lapangan berjalan tertib.', 'is_draft' => false],
                    ];
                    DB::table('visitasi')->insert([
                        'id_visit' => $visitUuid,
                        'id_result' => $resultId,
                        'visit_mode' => 'offline',
                        'visit_at' => "$datePrefix-06-05",
                        'visit_score' => $visitScore,
                        'visit_note' => 'Kunjungan lapangan berjalan tertib.',
                        'link_buktidukung' => 'https://drive.google.com/drive/folders/sample-archive',
                    ]);
                    $assignVisitEvaluators($visitUuid, $pastEvaluatorsData, "$datePrefix-06-05");

                    $pastInterviewersData = [
                        ['id_user' => 2, 'score' => $i1, 'note' => 'Komentar pewawancara 1', 'is_draft' => false],
                        ['id_user' => 3, 'score' => $i2, 'note' => 'Komentar pewawancara 2', 'is_draft' => false],
                        ['id_user' => 4, 'score' => $i3, 'note' => 'Komentar pewawancara 3', 'is_draft' => false],
                    ];

                    $pastIntId = DB::table('interview')->insertGetId([
                        'id_result' => $resultId,
                        'interview_at' => "$datePrefix-06-20",
                        'interview_score' => $interviewScore,
                    ]);
                    $assignInterviewEvaluators($pastIntId, $pastInterviewersData, "$datePrefix-06-20");

                } else {
                    // Gugur
                    $ratios = $ratiosMatrix[8 + ($j % 6)];
                    $answersData = $makeAnswers($subId, $ratios);
                    $totalEarned = array_sum(array_column($answersData, 'answer_score'));
                    $totalMax = $dbQuestions->sum($scoreCol);
                    $saqScore = $totalMax > 0 ? round(($totalEarned / $totalMax) * 100, 2) : 0;

                    // Ensure SAQ score is less than 80
                    if ($saqScore >= 80) {
                        $saqScore = 74.50;
                    }

                    $finalScore = round($saqScore * 0.3, 2);

                    DB::table('result')->insert([
                        'id_result' => $resultId,
                        'kode_satker' => $satker,
                        'id_periode' => $periodId,
                        'ques_score' => $saqScore,
                        'visit_score' => null,
                        'interview_score' => null,
                        'final_score' => $finalScore,
                        'index_label' => 'GUGUR',
                        'published_at' => "$datePrefix-07-01",
                    ]);

                    DB::table('submissions')->insert([
                        'id_submission' => $subId,
                        'id_result' => $resultId,
                        'id_operator' => json_encode([$userId]),
                        'verified_by' => 43 + ($j % 38),
                        'verified_at' => "$datePrefix-05-15",
                        'verification_note' => 'Dokumen lengkap.',
                        'status' => 8, // Gugur
                        'submitted_at' => "$datePrefix-05-10",
                        'evaluated_at' => "$datePrefix-05-25",
                    ]);
                    $assignSubEvaluator($subId, 2, "$datePrefix-05-25");

                    DB::table('answer')->insert($answersData);
                }
            }
        }

        // Seed Kabag Comments for each period
        DB::table('kabag_komentars')->insert([
            [
                'id_periode' => 1,
                'id_user' => 5000,
                'komentar' => 'Evaluasi KIP 2024. Masih terdapat beberapa Satker dengan predikat Kurang Informatif. Harap dilakukan pembinaan lebih lanjut.',
                'created_at' => '2024-07-01 10:00:00',
            ],
            [
                'id_periode' => 2,
                'id_user' => 5000,
                'komentar' => 'Secara umum pelaksanaan KIP 2025 berjalan sangat baik. Satker yang memperoleh predikat Informatif meningkat dibanding tahun lalu.',
                'created_at' => '2025-07-01 10:00:00',
            ],
            [
                'id_periode' => 3,
                'id_user' => 5000,
                'komentar' => 'Evaluasi KIP 2026 menunjukkan peningkatan komitmen dari seluruh Satker. Terus pertahankan transparansi informasi dan tingkatkan kualitas data dukung SAQ.',
                'created_at' => '2026-06-08 10:00:00',
            ],
        ]);

        // ── Draft Scenarios (Sub 115 - 118) ──────────────────────────────────
        $opUsers = [37, 36, 38, 39];
        $vkUsers = [74, 75];
        $allQuestions = $dbQuestions;
        $totalQuestions = $allQuestions->count();

        // Helper: jawaban sudah dinilai evaluator
        $makeEvalDraft = function (int $subId, $questions, int $evalId) use ($now): array {
            $rows = [];
            foreach ($questions as $q) {
                $rawEarned = round(($q->bobot_pertanyaan ?? 2.5) * 0.90, 2);

                // Map to valid dropdown options [0, 1, 2, 2.5]
                $options = [0, 1, 2, 2.5];
                $earned = 0;
                $minDiff = 999;
                foreach ($options as $opt) {
                    $diff = abs($rawEarned - $opt);
                    if ($diff < $minDiff) {
                        $minDiff = $diff;
                        $earned = $opt;
                    }
                }

                // Force 2.25 to 2.00 as requested
                if ($rawEarned == 2.25) {
                    $earned = 2.0;
                }

                $rows[] = [
                    'id_answer' => Str::uuid()->toString(),
                    'id_question' => $q->id_master_pertanyaan,
                    'id_submission' => $subId,
                    'id_indicators' => $q->id_indicators,
                    'answer' => 1,
                    'link_ppid' => 'https://bps.go.id/ppid/eval-'.$q->id_master_pertanyaan,
                    'link_drive' => 'https://drive.google.com/drive/folders/bukti-dukung-eval-q'.$q->id_master_pertanyaan,
                    'answer_score' => $earned,
                    'evaluator_note' => $earned == 2.5 ? 'Good job! sudah lengkap, dipertahankan.' : 'Dokumen bukti dukung telah sesuai.',
                    'evaluator_at' => $now->copy()->subHours(2),
                ];
            }

            return $rows;
        };

        // Sub 115 — Satker 3574 (Kota Probolinggo) - Draft Pengisian (70 dari 75 pertanyaan)
        $resultId = $idResultCounter++;
        DB::table('result')->insert([
            'id_result' => $resultId,
            'kode_satker' => $satkersAll[32], // 3574 Kota Probolinggo
            'id_periode' => $activePeriodId,
        ]);
        DB::table('submissions')->insert([
            'id_submission' => 115,
            'id_result' => $resultId,
            'id_operator' => json_encode([$opEntry($opUsers[0])]), // op_3574 (id: 37)
            'status' => 0, // Draft Pengisian
            'draft_saved_at' => $now->copy()->subHours(1),
        ]);
        DB::table('answer')->insert($makeOpDraft(115, $allQuestions->slice(0, 70)->values()));

        // Sub 116 — Satker 3573 (Kota Malang) - Draft Pengisian (70 dari 75 pertanyaan)
        $resultId = $idResultCounter++;
        DB::table('result')->insert([
            'id_result' => $resultId,
            'kode_satker' => $satkersAll[31], // 3573 Kota Malang
            'id_periode' => $activePeriodId,
        ]);
        DB::table('submissions')->insert([
            'id_submission' => 116,
            'id_result' => $resultId,
            'id_operator' => json_encode([$opEntry($opUsers[1])]), // op_3573 (id: 36)
            'status' => 0, // Draft Pengisian
            'draft_saved_at' => $now->copy()->subHours(3),
        ]);
        DB::table('answer')->insert($makeOpDraft(116, $allQuestions->slice(0, 70)->values()));

        // Sub 117 — Draft penilaian evaluator KURANG 5 oleh evaluator 1
        $resultId = $idResultCounter++;
        DB::table('result')->insert([
            'id_result' => $resultId,
            'kode_satker' => $satkersAll[33],
            'id_periode' => $activePeriodId,
        ]);
        DB::table('submissions')->insert([
            'id_submission' => 117,
            'id_result' => $resultId,
            'id_operator' => json_encode([$opEntry($opUsers[2])]),
            'verified_by' => $vkUsers[0],
            'verified_at' => $now->copy()->subDays(3),
            'verification_note' => 'Dokumen lengkap dan valid.',
            'status' => 3,
            'submitted_at' => $now->copy()->subDays(5),
        ]);
        $assignSubEvaluator(117, 2, $now->copy()->subDays(5));
        $scored70 = $allQuestions->slice(0, $totalQuestions - 5)->values();
        $unscored5 = $allQuestions->slice($totalQuestions - 5)->values();
        DB::table('answer')->insert($makeEvalDraft(117, $scored70, 2));
        DB::table('answer')->insert($makeOpDraft(117, $unscored5));

        // Sub 118 — Draft penilaian evaluator KURANG 5 oleh evaluator 2
        $resultId = $idResultCounter++;
        DB::table('result')->insert([
            'id_result' => $resultId,
            'kode_satker' => $satkersAll[34],
            'id_periode' => $activePeriodId,
        ]);
        DB::table('submissions')->insert([
            'id_submission' => 118,
            'id_result' => $resultId,
            'id_operator' => json_encode([$opEntry($opUsers[3])]),
            'verified_by' => $vkUsers[1],
            'verified_at' => $now->copy()->subDays(2),
            'verification_note' => 'Dokumen terverifikasi.',
            'status' => 3,
            'submitted_at' => $now->copy()->subDays(4),
        ]);
        $assignSubEvaluator(118, 3, $now->copy()->subDays(4));
        DB::table('answer')->insert($makeEvalDraft(118, $scored70, 3));
        DB::table('answer')->insert($makeOpDraft(118, $unscored5));

        // =====================================================================
        // UJICOBA DANISIAN SEEDING DATA
        // =====================================================================
        $opUji1 = DB::table('users')->where('nama_user', 'op_ujicoba1')->first();
        $opUji2 = DB::table('users')->where('nama_user', 'op_ujicoba2')->first();
        $opUji3 = DB::table('users')->where('nama_user', 'op_ujicoba3')->first();

        $vkUji1 = DB::table('users')->where('nama_user', 'vk_ujicoba1')->first();
        $vkUji2 = DB::table('users')->where('nama_user', 'vk_ujicoba2')->first();
        $vkUji3 = DB::table('users')->where('nama_user', 'vk_ujicoba3')->first();

        $evalUji1 = DB::table('users')->where('nama_user', 'evaluator_ujicoba1')->first();
        $evalUji2 = DB::table('users')->where('nama_user', 'evaluator_ujicoba2')->first();
        $evalUji3 = DB::table('users')->where('nama_user', 'evaluator_ujicoba3')->first();

        $questions70 = $dbQuestions->take(70);

        $getOrCreateSub = function (string $satkerCode, ?object $op, ?object $vk, int $status = 1) use (&$idResultCounter, $now, $activePeriodId) {
            $existingRes = DB::table('result')->where('kode_satker', $satkerCode)->where('id_periode', $activePeriodId)->first();
            if (! $existingRes) {
                $resId = $idResultCounter++;
                DB::table('result')->insert([
                    'id_result' => $resId,
                    'kode_satker' => $satkerCode,
                    'id_periode' => $activePeriodId,
                ]);
            } else {
                $resId = $existingRes->id_result;
            }

            $existingSub = DB::table('submissions')->where('id_result', $resId)->first();
            if (! $existingSub) {
                $subId = DB::table('submissions')->insertGetId([
                    'id_result' => $resId,
                    'id_operator' => $op ? json_encode([['id' => $op->id_user, 'nama' => $op->nama_user]]) : null,
                    'verified_by' => $vk?->id_user,
                    'verified_at' => $vk ? $now->copy()->subDays(5) : null,
                    'verification_note' => $vk ? 'Dokumen terverifikasi' : null,
                    'status' => $status,
                    'submitted_at' => $now->copy()->subDays(10),
                ]);
            } else {
                $subId = $existingSub->id_submission;
                if ($op) {
                    DB::table('submissions')->where('id_submission', $subId)->update([
                        'id_operator' => json_encode([['id' => $op->id_user, 'nama' => $op->nama_user]]),
                    ]);
                }
            }

            return [$resId, $subId];
        };

        // 1. Operator Submissions: op_ujicoba1 (3521), op_ujicoba2 (3522), op_ujicoba3 (3523) - STATUS 0 (DRAFT 70/75)
        $opConfigs = [
            ['satker' => '3521', 'op' => $opUji1, 'forceNew' => false],
            ['satker' => '3522', 'op' => $opUji2, 'forceNew' => false],
            ['satker' => '3523', 'op' => $opUji3, 'forceNew' => false],
        ];
        foreach ($opConfigs as $cfg) {
            if (! $cfg['op']) {
                continue;
            }

            if ($cfg['forceNew']) {
                $resId = $idResultCounter++;
                DB::table('result')->insert([
                    'id_result' => $resId,
                    'kode_satker' => $cfg['satker'],
                    'id_periode' => $activePeriodId,
                ]);

                $subId = DB::table('submissions')->insertGetId([
                    'id_result' => $resId,
                    'id_operator' => json_encode([['id' => $cfg['op']->id_user, 'nama' => $cfg['op']->nama_user]]),
                    'verified_by' => null,
                    'verified_at' => null,
                    'verification_note' => null,
                    'status' => 0, // DRAFT
                    'draft_saved_at' => $now,
                    'submitted_at' => null,
                ]);
            } else {
                [$resId, $subId] = $getOrCreateSub($cfg['satker'], $cfg['op'], null, 0);

                DB::table('submissions')->where('id_submission', $subId)->update([
                    'id_operator' => json_encode([['id' => $cfg['op']->id_user, 'nama' => $cfg['op']->nama_user]]),
                    'status' => 0, // DRAFT
                    'draft_saved_at' => $now,
                    'submitted_at' => null,
                    'verified_by' => null,
                    'verified_at' => null,
                ]);
            }

            foreach ($questions70 as $q) {
                DB::table('answer')->updateOrInsert(
                    ['id_submission' => $subId, 'id_question' => $q->id_master_pertanyaan],
                    [
                        'id_answer' => Str::uuid()->toString(),
                        'id_indicators' => $q->id_indicators,
                        'answer' => 1,
                        'link_ppid' => 'https://bps.go.id/ppid/ujicoba-'.$q->id_master_pertanyaan,
                        'link_drive' => 'https://drive.google.com/drive/folders/ujicoba-sub'.$subId.'-q'.$q->id_master_pertanyaan,
                        'answer_score' => null,
                        'evaluator_note' => null,
                        'evaluator_at' => null,
                    ]
                );
            }
        }

        // 2. Evaluator SAQ Evaluations:
        // - evaluator_ujicoba1 -> SAQ 3517 (Operator: op_3517)
        // - evaluator_ujicoba2 -> SAQ 3518 (Operator: op_3518)
        // - evaluator_ujicoba3 -> SAQ 3519 (Operator: op_3519)
        $op3517 = DB::table('users')->where('nama_user', 'op_3517')->first();
        $op3518 = DB::table('users')->where('nama_user', 'op_3518')->first();
        $op3519 = DB::table('users')->where('nama_user', 'op_3519')->first();

        $vk3517 = DB::table('users')->where('nama_user', 'vk_3517')->first();
        $vk3518 = DB::table('users')->where('nama_user', 'vk_3518')->first();
        $vk3519 = DB::table('users')->where('nama_user', 'vk_3519')->first();

        $evalConfigs = [
            ['satker' => '3517', 'eval' => $evalUji1, 'op' => $op3517, 'vk' => $vk3517],
            ['satker' => '3518', 'eval' => $evalUji2, 'op' => $op3518, 'vk' => $vk3518],
            ['satker' => '3519', 'eval' => $evalUji3, 'op' => $op3519, 'vk' => $vk3519],
        ];
        foreach ($evalConfigs as $cfg) {
            if (! $cfg['eval'] || ! $cfg['op']) {
                continue;
            }

            [$resId, $subId] = $getOrCreateSub($cfg['satker'], $cfg['op'], $cfg['vk'], 3);

            DB::table('submissions')->where('id_submission', $subId)->update([
                'id_operator' => json_encode([['id' => $cfg['op']->id_user, 'nama' => $cfg['op']->nama_user]]),
                'evaluated_at' => null, // Masih draft penilaian
                'status' => 3, // Status 3 (Menunggu / Draft Penilaian Evaluator)
            ]);
            $assignSubEvaluator($subId, $cfg['eval']->id_user);

            // Isi semua 75 pertanyaan sebagai jawaban operator terlebih dahulu
            foreach ($dbQuestions as $q) {
                DB::table('answer')->updateOrInsert(
                    ['id_submission' => $subId, 'id_question' => $q->id_master_pertanyaan],
                    [
                        'id_answer' => Str::uuid()->toString(),
                        'id_indicators' => $q->id_indicators,
                        'answer' => 1,
                        'link_ppid' => 'https://bps.go.id/ppid/ujicoba-'.$q->id_master_pertanyaan,
                        'link_drive' => 'https://drive.google.com/drive/folders/eval-sub'.$subId.'-q'.$q->id_master_pertanyaan,
                        'answer_score' => null,
                        'evaluator_note' => null,
                        'evaluator_at' => null,
                    ]
                );
            }

            // Berikan penilaian evaluator HANYA untuk 70 pertanyaan (5 pertanyaan belum dinilai)
            foreach ($questions70 as $q) {
                $score = $q->bobot_pertanyaan ?? 2.5;

                DB::table('answer')->where('id_submission', $subId)->where('id_question', $q->id_master_pertanyaan)->update([
                    'answer_score' => $score,
                    'evaluator_note' => 'Dokumen bukti dukung telah sesuai dan diverifikasi oleh '.$cfg['eval']->nama_user,
                    'evaluator_at' => $now->copy()->subDays(3),
                ]);
            }

            DB::table('result')->where('id_result', $resId)->update([
                'ques_score' => null, // Masih draft
            ]);
        }

        // 3. Visitasi Assignments:
        // - Satker 3504 (Tulungagung): evaluator_ujicoba1 + evaluator1 (Belum dinilai, offline)
        // - Satker 3503 (Trenggalek): evaluator_ujicoba2 (Belum dinilai) + evaluator1 (Sudah dinilai 90.50, online_upload)
        // - Satker 3506 (Kediri): evaluator_ujicoba3 + evaluator1 (Belum dinilai, online_upload)
        $eval1 = DB::table('users')->where('nama_user', 'evaluator1')->first();
        $eval1Id = $eval1 ? $eval1->id_user : 2;

        // 3504 (Tulungagung)
        if ($evalUji1) {
            [$res3504Id, $sub3504Id] = $getOrCreateSub('3504', null, null, 5);
            $visitData3504 = [
                ['id_user' => $eval1Id, 'score' => null, 'note' => null, 'is_draft' => true],
                ['id_user' => $evalUji1->id_user, 'score' => null, 'note' => null, 'is_draft' => true],
            ];
            $existingVisit3504 = DB::table('visitasi')->where('id_result', $res3504Id)->first();
            $visitUuid3504 = $existingVisit3504 ? $existingVisit3504->id_visit : Str::uuid()->toString();
            DB::table('visitasi')->updateOrInsert(
                ['id_result' => $res3504Id],
                [
                    'id_visit' => $visitUuid3504,
                    'visit_mode' => 'offline',
                    'visit_at' => '2026-12-02',
                    'visit_score' => null,
                    'visit_note' => null,
                ]
            );
            $assignVisitEvaluators($visitUuid3504, $visitData3504);

            DB::table('result')->where('id_result', $res3504Id)->update([
                'visit_score' => null,
            ]);
        }

        // 3505 (Blitar - online_meeting, eval1 & evaluator_ujicoba2 belum menilai)
        if ($evalUji2) {
            [$res3505Id, $sub3505Id] = $getOrCreateSub('3505', null, null, 5);
            $visitData3505 = [
                ['id_user' => $eval1Id, 'score' => null, 'note' => null, 'is_draft' => true],
                ['id_user' => $evalUji2->id_user, 'score' => null, 'note' => null, 'is_draft' => true],
            ];
            $existingVisit3505 = DB::table('visitasi')->where('id_result', $res3505Id)->first();
            $visitUuid3505 = $existingVisit3505 ? $existingVisit3505->id_visit : Str::uuid()->toString();
            DB::table('visitasi')->updateOrInsert(
                ['id_result' => $res3505Id],
                [
                    'id_visit' => $visitUuid3505,
                    'visit_mode' => 'online_meeting',
                    'visit_at' => '2026-12-03',
                    'visit_score' => null,
                    'visit_note' => null,
                    $linkMeetingCol => 'https://zoom.us/j/987654321',
                ]
            );
            $assignVisitEvaluators($visitUuid3505, $visitData3505);

            DB::table('result')->where('id_result', $res3505Id)->update([
                'visit_score' => null,
            ]);
        }

        // 3506 (Kediri - online_upload, eval1 & evaluator_ujicoba3 belum menilai)
        if ($evalUji3) {
            [$res3506Id, $sub3506Id] = $getOrCreateSub('3506', null, null, 5);
            $visitData3506 = [
                ['id_user' => $eval1Id, 'score' => null, 'note' => null, 'is_draft' => true],
                ['id_user' => $evalUji3->id_user, 'score' => null, 'note' => null, 'is_draft' => true],
            ];
            $existingVisit3506 = DB::table('visitasi')->where('id_result', $res3506Id)->first();
            $visitUuid3506 = $existingVisit3506 ? $existingVisit3506->id_visit : Str::uuid()->toString();
            DB::table('visitasi')->updateOrInsert(
                ['id_result' => $res3506Id],
                [
                    'id_visit' => $visitUuid3506,
                    'visit_mode' => 'online_upload',
                    'visit_at' => '2026-12-03',
                    'visit_score' => null,
                    'visit_note' => null,
                    'link_buktidukung' => 'https://drive.google.com/drive/folders/sample-3506-archive',
                ]
            );
            $assignVisitEvaluators($visitUuid3506, $visitData3506);

            DB::table('result')->where('id_result', $res3506Id)->update([
                'visit_score' => null,
            ]);
        }

        // 4. Wawancara / Interview (MAPPING SAJA KOTA PONOROGO 3502, BELUM DINILAI): Satker 3502 (evaluator_ujicoba1, evaluator_ujicoba2, evaluator_ujicoba3)
        if ($evalUji1 && $evalUji2 && $evalUji3) {
            [$res3502Id, $sub3502Id] = $getOrCreateSub('3502', null, null, 6);

            $interviewData = [
                ['id_user' => $evalUji1->id_user, 'score' => null, 'note' => null, 'is_draft' => true],
                ['id_user' => $evalUji2->id_user, 'score' => null, 'note' => null, 'is_draft' => true],
                ['id_user' => $evalUji3->id_user, 'score' => null, 'note' => null, 'is_draft' => true],
            ];

            DB::table('interview')->updateOrInsert(
                ['id_result' => $res3502Id],
                [
                    $meetsLinkCol => 'https://meet.google.com/ujicoba-wawancara-3502',
                    'interview_at' => '2026-11-25',
                    'interview_score' => null,
                ]
            );
            $actualInt3502 = DB::table('interview')->where('id_result', $res3502Id)->value('id_interview');
            $assignInterviewEvaluators($actualInt3502, $interviewData);

            DB::table('result')->where('id_result', $res3502Id)->update([
                'interview_score' => null,
            ]);
        }
    }
}
