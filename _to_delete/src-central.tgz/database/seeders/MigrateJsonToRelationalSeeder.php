<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class MigrateJsonToRelationalSeeder extends Seeder
{
    /**
     * Run the database seeds to migrate data from JSON columns to new relational tables.
     */
    public function run(): void
    {
        $this->command?->info('Memulai migrasi data JSON ke tabel relasional...');

        // 1. Migrasi evaluated_by pada submissions -> submission_evaluators
        if (\Illuminate\Support\Facades\Schema::hasColumn('submissions', 'evaluated_by')) {
            $subs = DB::table('submissions')->whereNotNull('evaluated_by')->get();
            $subCount = 0;
            foreach ($subs as $sub) {
                $raw = $sub->evaluated_by;
                $items = is_string($raw) ? json_decode($raw, true) : (array) $raw;
                if (!is_array($items)) {
                    continue;
                }

                foreach ($items as $item) {
                    $userId = is_array($item) ? ($item['id'] ?? $item['id_user'] ?? null) : $item;
                    if ($userId && DB::table('users')->where('id_user', (int) $userId)->exists()) {
                        DB::table('submission_evaluators')->updateOrInsert(
                            [
                                'id_submission' => $sub->id_submission,
                                'id_user'       => (int) $userId,
                            ],
                            []
                        );
                        $subCount++;
                    }
                }
            }
            $this->command?->info("Tersinkronisasi {$subCount} penugasan evaluator SAQ ke submission_evaluators.");
        }

        // 2. Migrasi interview_data pada interview -> interview_evaluators
        if (\Illuminate\Support\Facades\Schema::hasColumn('interview', 'interview_data')) {
            $interviews = DB::table('interview')->whereNotNull('interview_data')->get();
            $intCount = 0;
            foreach ($interviews as $inv) {
                $raw = $inv->interview_data;
                $items = is_string($raw) ? json_decode($raw, true) : (array) $raw;
                if (!is_array($items)) {
                    continue;
                }

                foreach ($items as $item) {
                    $userId = $item['id_user'] ?? null;
                    if ($userId && DB::table('users')->where('id_user', (int) $userId)->exists()) {
                        DB::table('interview_evaluators')->updateOrInsert(
                            [
                                'id_interview' => $inv->id_interview,
                                'id_user'      => (int) $userId,
                            ],
                            [
                                'score'    => isset($item['score']) && $item['score'] !== '' ? floatval($item['score']) : null,
                                'catatan'  => $item['note'] ?? $item['catatan'] ?? null,
                                'is_draft' => (bool) ($item['is_draft'] ?? false),
                            ]
                        );

                        if (!empty($item['name']) || !empty($item['instansi']) || !empty($item['is_external'])) {
                            $userUp = [];
                            if (!empty($item['name'])) $userUp['name'] = $item['name'];
                            if (!empty($item['instansi'])) $userUp['instansi'] = $item['instansi'];
                            if (!empty($item['is_external'])) $userUp['is_eksternal'] = true;
                            DB::table('users')->where('id_user', (int) $userId)->update($userUp);
                        }
                        $intCount++;
                    }
                }
            }
            $this->command?->info("Tersinkronisasi {$intCount} data penilaian evaluator wawancara ke interview_evaluators.");
        }

        // 3. Migrasi visit_data pada visitasi -> visitasi_evaluators
        if (\Illuminate\Support\Facades\Schema::hasColumn('visitasi', 'visit_data')) {
            $visitasis = DB::table('visitasi')->whereNotNull('visit_data')->get();
            $visCount = 0;
            foreach ($visitasis as $v) {
                $raw = $v->visit_data;
                $items = is_string($raw) ? json_decode($raw, true) : (array) $raw;
                if (!is_array($items)) {
                    continue;
                }

                foreach ($items as $item) {
                    $userId = $item['id_user'] ?? null;
                    if ($userId && DB::table('users')->where('id_user', (int) $userId)->exists()) {
                        DB::table('visitasi_evaluators')->updateOrInsert(
                            [
                                'id_visit' => $v->id_visit,
                                'id_user'  => (int) $userId,
                            ],
                            [
                                'score'    => isset($item['score']) && $item['score'] !== '' ? floatval($item['score']) : null,
                                'catatan'  => $item['note'] ?? $item['catatan'] ?? null,
                                'is_draft' => (bool) ($item['is_draft'] ?? false),
                            ]
                        );

                        if (!empty($item['name']) || !empty($item['instansi']) || !empty($item['is_external'])) {
                            $userUp = [];
                            if (!empty($item['name'])) $userUp['name'] = $item['name'];
                            if (!empty($item['instansi'])) $userUp['instansi'] = $item['instansi'];
                            if (!empty($item['is_external'])) $userUp['is_eksternal'] = true;
                            DB::table('users')->where('id_user', (int) $userId)->update($userUp);
                        }
                        $visCount++;
                    }
                }
            }
            $this->command?->info("Tersinkronisasi {$visCount} data penilaian evaluator visitasi ke visitasi_evaluators.");
        }

        // 4. Inisialisasi master_link dari storage/app/panduan_url.txt atau env
        $panduanFile = storage_path('app/panduan_url.txt');
        $panduanUrl = file_exists($panduanFile)
            ? trim(file_get_contents($panduanFile))
            : env('PANDUAN_DRIVE_URL', 'https://drive.google.com');

        $periods = DB::table('periods')->get();
        $linkCount = 0;
        foreach ($periods as $p) {
            DB::table('master_link')->updateOrInsert(
                ['id_periode' => $p->id_periode],
                [
                    'link_panduan' => $panduanUrl ?: 'https://drive.google.com',
                ]
            );
            $linkCount++;
        }
        $this->command?->info("Tersinkronisasi {$linkCount} record link periode ke master_link.");
    }
}
