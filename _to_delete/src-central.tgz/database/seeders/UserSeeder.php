<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Seed Main Users
        $users = [
            [
                'id_user' => 1, 'nama_user' => 'admin',
                'email' => 'admin@bps.go.id', 'password' => Hash::make('password123'),
                'role' => 'admin', 'kode_satker' => '3500',
                'nip_panjang' => '199001012015011001', 'nip_pendek' => '340011111'
            ],
            [
                'id_user' => 2, 'nama_user' => 'evaluator1',
                'email' => 'evaluator1@bps.go.id', 'password' => Hash::make('password123'),
                'role' => 'evaluator', 'kode_satker' => '3500',
                'nip_panjang' => '199102022016021002', 'nip_pendek' => '340022222'
            ],
            [
                'id_user' => 3, 'nama_user' => 'evaluator2',
                'email' => 'evaluator2@bps.go.id', 'password' => Hash::make('password123'),
                'role' => 'evaluator', 'kode_satker' => '3500',
                'nip_panjang' => '199203032017031003', 'nip_pendek' => '340033333'
            ],
            [
                'id_user' => 4, 'nama_user' => 'evaluator3',
                'email' => 'evaluator3@bps.go.id', 'password' => Hash::make('password123'),
                'role' => 'evaluator', 'kode_satker' => '3500',
                'nip_panjang' => '199304042018041004', 'nip_pendek' => '340044444'
            ],
            [
                'id_user' => 4000, 'nama_user' => 'kepala',
                'email' => 'kepala@bps.go.id', 'password' => Hash::make('password123'),
                'role' => 'super_evaluator', 'kode_satker' => '3500',  // nambah akun kepala
                'nip_panjang' => '198505052010051005', 'nip_pendek' => '340055555'
            ],
            [
                'id_user' => 5000, 'nama_user' => 'kabag',
                'email' => 'kabag@bps.go.id', 'password' => Hash::make('password123'),
                'role' => 'super_evaluator', 'kode_satker' => '3500',  // role kabag → super_evaluator
                'nip_panjang' => '198505052010051005', 'nip_pendek' => '340055555'
            ],
            [
                'id_user' => 6000, 'nama_user' => 'superevaluator',
                'email' => 'superevaluator@bps.go.id', 'password' => Hash::make('password123'),
                'role' => 'super_evaluator', 'kode_satker' => '3500',
                'nip_panjang' => '198505052010051005', 'nip_pendek' => '340055555'
            ],
            [
                'id_user' => 8000, 'nama_user' => 'eksternal',
                'name' => 'Penilai Eksternal (Akademisi)',
                'instansi' => 'Universitas Airlangga',
                'is_eksternal' => true,
                'email' => 'eksternal@bps.go.id', 'password' => Hash::make('password123'),
                'role' => 'penilai_eksternal', 'kode_satker' => '3500',
                'nip_panjang' => '198808082012081008', 'nip_pendek' => '340088888'
            ],
        ];
        foreach ($users as $userData) {
            $role = $userData['role'];
            unset($userData['role']);
            $user = User::create($userData);
            $user->assignRole($role);
        }

        // Satker list for op and vk users
        $satkersAll = [
            '3501','3502','3503','3504','3505','3506','3507','3508','3509','3510',
            '3511','3512','3513','3514','3515','3516','3517','3518','3519','3520',
            '3521','3522','3523','3524','3525','3526','3527','3528','3529',
            '3571','3572','3573','3574','3575','3576','3577','3578','3579',
        ];

        // Seed Operator Users (id_user 5 to 42)
        foreach ($satkersAll as $idx => $kode) {
            $user = User::create([
                'id_user'    => 5 + $idx,
                'nama_user'  => 'op_' . $kode,
                'email'      => 'op_' . $kode . '@bps.go.id',
                'password'   => Hash::make('password123'),
                'kode_satker'=> $kode,
                'nip_panjang'=> '199501' . str_pad($idx + 10, 2, '0', STR_PAD_LEFT) . '20201210' . str_pad($idx + 10, 2, '0', STR_PAD_LEFT),
                'nip_pendek' => '3400' . str_pad($idx + 1000, 5, '0', STR_PAD_LEFT),
            ]);
            $user->assignRole('operator');
        }

        // Seed Verifikator Users (id_user 43 to 80)
        foreach ($satkersAll as $idx => $kode) {
            $user = User::create([
                'id_user'    => 43 + $idx,
                'nama_user'  => 'vk_' . $kode,
                'email'      => 'vk_' . $kode . '@bps.go.id',
                'password'   => Hash::make('password123'),
                'kode_satker'=> $kode,
                'nip_panjang'=> '199401' . str_pad($idx + 10, 2, '0', STR_PAD_LEFT) . '20191210' . str_pad($idx + 10, 2, '0', STR_PAD_LEFT),
                'nip_pendek' => '3400' . str_pad($idx + 2000, 5, '0', STR_PAD_LEFT),
            ]);
            $user->assignRole('verifikator');
        }

        // Seed Ujicoba Evaluator Users
        $ujicobaEvaluators = [
            [
                'id_user' => 7001, 'nama_user' => 'evaluator_ujicoba1',
                'email' => 'evaluator_ujicoba1@bps.go.id', 'password' => Hash::make('password123'),
                'role' => 'evaluator', 'kode_satker' => '3500',
                'nip_panjang' => '199105012016021001', 'nip_pendek' => '34009901'
            ],
            [
                'id_user' => 7002, 'nama_user' => 'evaluator_ujicoba2',
                'email' => 'evaluator_ujicoba2@bps.go.id', 'password' => Hash::make('password123'),
                'role' => 'evaluator', 'kode_satker' => '3500',
                'nip_panjang' => '199105022016021002', 'nip_pendek' => '34009902'
            ],
            [
                'id_user' => 7003, 'nama_user' => 'evaluator_ujicoba3',
                'email' => 'evaluator_ujicoba3@bps.go.id', 'password' => Hash::make('password123'),
                'role' => 'evaluator', 'kode_satker' => '3500',
                'nip_panjang' => '199105032016021003', 'nip_pendek' => '34009903'
            ],
        ];
        foreach ($ujicobaEvaluators as $userData) {
            $role = $userData['role'];
            unset($userData['role']);
            $user = User::create($userData);
            $user->assignRole($role);
        }

        // Seed Ujicoba Operator Users
        $ujicobaOps = [
            ['id_user' => 7101, 'nama_user' => 'op_ujicoba1', 'email' => 'op_ujicoba1@bps.go.id', 'kode_satker' => '3521', 'nip_panjang' => '199501152020121015', 'nip_pendek' => '34001515'],
            ['id_user' => 7102, 'nama_user' => 'op_ujicoba2', 'email' => 'op_ujicoba2@bps.go.id', 'kode_satker' => '3522', 'nip_panjang' => '199501162020121016', 'nip_pendek' => '34001616'],
            ['id_user' => 7103, 'nama_user' => 'op_ujicoba3', 'email' => 'op_ujicoba3@bps.go.id', 'kode_satker' => '3523', 'nip_panjang' => '199501172020121017', 'nip_pendek' => '34001717'],
        ];
        foreach ($ujicobaOps as $opData) {
            $user = User::create([
                'id_user'     => $opData['id_user'],
                'nama_user'   => $opData['nama_user'],
                'email'       => $opData['email'],
                'password'    => Hash::make('password123'),
                'kode_satker' => $opData['kode_satker'],
                'nip_panjang' => $opData['nip_panjang'],
                'nip_pendek'  => $opData['nip_pendek'],
            ]);
            $user->assignRole('operator');
        }

        // Seed Ujicoba Verifikator Users
        $ujicobaVks = [
            ['id_user' => 7201, 'nama_user' => 'vk_ujicoba1', 'email' => 'vk_ujicoba1@bps.go.id', 'kode_satker' => '3521', 'nip_panjang' => '199401152019121015', 'nip_pendek' => '34002515'],
            ['id_user' => 7202, 'nama_user' => 'vk_ujicoba2', 'email' => 'vk_ujicoba2@bps.go.id', 'kode_satker' => '3522', 'nip_panjang' => '199401162019121016', 'nip_pendek' => '34002616'],
            ['id_user' => 7203, 'nama_user' => 'vk_ujicoba3', 'email' => 'vk_ujicoba3@bps.go.id', 'kode_satker' => '3523', 'nip_panjang' => '199401172019121017', 'nip_pendek' => '34002717'],
        ];
        foreach ($ujicobaVks as $vkData) {
            $user = User::create([
                'id_user'     => $vkData['id_user'],
                'nama_user'   => $vkData['nama_user'],
                'email'       => $vkData['email'],
                'password'    => Hash::make('password123'),
                'kode_satker' => $vkData['kode_satker'],
                'nip_panjang' => $vkData['nip_panjang'],
                'nip_pendek'  => $vkData['nip_pendek'],
            ]);
            $user->assignRole('verifikator');
        }
    }
}
