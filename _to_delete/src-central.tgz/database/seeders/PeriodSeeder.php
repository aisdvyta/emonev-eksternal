<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;

class PeriodSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        Cache::forget('periods_desc');

        $periods = [
            [
                'id_periode' => 1,
                'periode_start' => '2024-05-01',
                'periode_end' => '2024-07-08',
                'saq_start' => '2024-05-01',
                'saq_end' => '2024-05-20',
                'eval_start' => '2024-05-21',
                'eval_end' => '2024-06-03',
                'visit_start' => '2024-06-04',
                'visit_end' => '2024-06-17',
                'interview_start' => '2024-06-18',
                'interview_end' => '2024-06-27',
                'result_start' => '2024-06-28',
                'result_end' => '2024-07-08',
            ],
            [
                'id_periode' => 2,
                'periode_start' => '2025-05-01',
                'periode_end' => '2025-07-08',
                'saq_start' => '2025-05-01',
                'saq_end' => '2025-05-20',
                'eval_start' => '2025-05-21',
                'eval_end' => '2025-06-03',
                'visit_start' => '2025-06-04',
                'visit_end' => '2025-06-17',
                'interview_start' => '2025-06-18',
                'interview_end' => '2025-06-27',
                'result_start' => '2025-06-28',
                'result_end' => '2025-07-08',
            ],
            [
                'id_periode' => 3,
                'periode_start' => '2026-11-02',
                'periode_end' => '2026-12-15',
                'saq_start' => '2026-11-02',
                'saq_end' => '2026-11-08',
                'eval_start' => '2026-11-09',
                'eval_end' => '2026-11-22',
                'interview_start' => '2026-11-23',
                'interview_end' => '2026-11-27',
                'visit_start' => '2026-11-30',
                'visit_end' => '2026-12-04',
                'result_start' => '2026-12-05',
                'result_end' => '2026-12-15',
            ],
        ];

        foreach ($periods as $period) {
            DB::table('periods')->updateOrInsert(['id_periode' => $period['id_periode']], $period);
        }
    }
}
