<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Cache;
use App\Models\Period;

class PembobotanSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $periods = Period::all();
        $defaultIndicatorWeights = [
            '1' => 20.00,
            '2' => 20.00,
            '3' => 20.00,
            '4' => 10.00,
            '5' => 15.00,
            '6' => 15.00,
        ];

        foreach ($periods as $period) {
            $year = date('Y', strtotime($period->periode_start ?? $period->saq_start ?? '2026-01-01'));
            if ($year < 2026) {
                // Historical periods (2024 & 2025): SAQ 30%, Visitasi 40%, Wawancara 30%
                $weightSaq = 30.00;
                $weightVisitasi = 40.00;
                $weightWawancara = 30.00;
                $stageOrder = ['saq', 'visitasi', 'wawancara'];
            } else {
                // Periode 2026+: SAQ 50%, Wawancara 30%, Visitasi 20%
                $weightSaq = 50.00;
                $weightVisitasi = 20.00;
                $weightWawancara = 30.00;
                $stageOrder = ['saq', 'wawancara', 'visitasi'];
            }

            DB::table('master_pembobotan')->updateOrInsert(
                ['id_periode' => $period->id_periode],
                [
                    'weight_saq'       => $weightSaq,
                    'weight_visitasi'  => $weightVisitasi,
                    'weight_wawancara' => $weightWawancara,
                    'threshold_saq'    => 80.00,
                    'bobot_indikator'  => json_encode($defaultIndicatorWeights),
                    'stage_order'      => json_encode($stageOrder),
                ]
            );
        }

        // Default record if no period exists yet
        if ($periods->isEmpty()) {
            DB::table('master_pembobotan')->updateOrInsert(
                ['id_periode' => null],
                [
                    'weight_saq'       => 50.00,
                    'weight_visitasi'  => 20.00,
                    'weight_wawancara' => 30.00,
                    'threshold_saq'    => 80.00,
                    'bobot_indikator'  => json_encode($defaultIndicatorWeights),
                    'stage_order'      => json_encode(['saq', 'wawancara', 'visitasi']),
                ]
            );
        }

        // Clear caches for stage orders & pembobotan
        Cache::forget('periods_desc');
        foreach ($periods as $period) {
            Cache::forget('pembobotan_stage_order_' . $period->id_periode);
            Cache::forget('pembobotan_config_' . $period->id_periode);
            Cache::forget('pembobotan_indicator_order_' . $period->id_periode);
        }
    }
}
