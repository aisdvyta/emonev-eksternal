<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class IndikatorSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Seed Indicators
        $indicators = [
            [
                'id_indicators' => 1,
                'nama_indikator' => 'Kualitas Informasi',
                'deskripsi_indikator' => 'Mutu informasi berdasarkan relevansi, akurasi dan kekinian data',
            ],
            [
                'id_indicators' => 2,
                'nama_indikator' => 'Jenis Informasi',
                'deskripsi_indikator' => 'Klasifikasi informasi publik yang wajib disediakan dan diumumkan secara berkala, setiap saat, dan serta-merta',
            ],
            [
                'id_indicators' => 3,
                'nama_indikator' => 'Pelayanan Informasi',
                'deskripsi_indikator' => 'Mekanisme, jangka waktu, dan kompetensi petugas dalam penyediaan layanan informasi publik',
            ],
            [
                'id_indicators' => 4,
                'nama_indikator' => 'Sarana Prasarana',
                'deskripsi_indikator' => 'Fasilitas pendukung aksesibilitas pelayanan informasi baik fisik maupun digital',
            ],
            [
                'id_indicators' => 5,
                'nama_indikator' => 'Digitalisasi',
                'deskripsi_indikator' => 'Pemanfaatan media sosial, situs web resmi, dan aplikasi digital untuk keterbukaan informasi',
            ],
            [
                'id_indicators' => 6,
                'nama_indikator' => 'Komitmen Organisasi',
                'deskripsi_indikator' => 'Kebijakan, kelembagaan, penunjukan SK PPID, peningkatan kapasitas bimtek, dan evaluasi internal',
            ],
        ];
        DB::table('master_indikator')->insert($indicators);

        // Seed Sub-Indicators
        $subIndicators = [
            // Kualitas Informasi (id_indicators = 1)
            ['id_sub_indicators' => 1,  'id_indicators' => 1, 'nama_sub_indikator' => 'Informasi Wajib Berkala'],
            ['id_sub_indicators' => 2,  'id_indicators' => 1, 'nama_sub_indikator' => 'Daftar Informasi Publik'],
            ['id_sub_indicators' => 3,  'id_indicators' => 1, 'nama_sub_indikator' => 'Informasi Dikecualikan'],
            // Jenis Informasi (id_indicators = 2)
            ['id_sub_indicators' => 4,  'id_indicators' => 2, 'nama_sub_indikator' => 'Informasi Tersedia Setiap Saat'],
            ['id_sub_indicators' => 5,  'id_indicators' => 2, 'nama_sub_indikator' => 'Informasi Terbuka Lainnya'],
            // Pelayanan Informasi (id_indicators = 3)
            ['id_sub_indicators' => 6,  'id_indicators' => 3, 'nama_sub_indikator' => 'Mekanisme dan Ketepatan Pelayanan'],
            ['id_sub_indicators' => 7,  'id_indicators' => 3, 'nama_sub_indikator' => 'Pemahaman Substansi'],
            // Sarana & Prasarana (id_indicators = 4)
            ['id_sub_indicators' => 8,  'id_indicators' => 4, 'nama_sub_indikator' => 'Elektronik'],
            ['id_sub_indicators' => 9,  'id_indicators' => 4, 'nama_sub_indikator' => 'Non Elektronik'],
            ['id_sub_indicators' => 10, 'id_indicators' => 4, 'nama_sub_indikator' => 'Layanan Difabel'],
            // Digitalisasi (id_indicators = 5)
            ['id_sub_indicators' => 11, 'id_indicators' => 5, 'nama_sub_indikator' => 'Media Sosial'],
            // Komitmen Organisasi (id_indicators = 6)
            ['id_sub_indicators' => 12, 'id_indicators' => 6, 'nama_sub_indikator' => 'Profil PPID'],
            ['id_sub_indicators' => 13, 'id_indicators' => 6, 'nama_sub_indikator' => 'Tugas dan Kewenangan Atasan PPID'],
            ['id_sub_indicators' => 14, 'id_indicators' => 6, 'nama_sub_indikator' => 'Pelaksanaan Tugas PPID'],
            ['id_sub_indicators' => 15, 'id_indicators' => 6, 'nama_sub_indikator' => 'Anggaran PPID'],
        ];
        DB::table('master_sub_indikator')->insert($subIndicators);
    }
}
