<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class SatkerSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $satkers = [
            ['kode_satker' => '3500', 'nama_satker' => 'BPS Provinsi Jawa Timur'],
            ['kode_satker' => '3501', 'nama_satker' => 'BPS Kabupaten Pacitan'],
            ['kode_satker' => '3502', 'nama_satker' => 'BPS Kabupaten Ponorogo'],
            ['kode_satker' => '3503', 'nama_satker' => 'BPS Kabupaten Trenggalek'],
            ['kode_satker' => '3504', 'nama_satker' => 'BPS Kabupaten Tulungagung'],
            ['kode_satker' => '3505', 'nama_satker' => 'BPS Kabupaten Blitar'],
            ['kode_satker' => '3506', 'nama_satker' => 'BPS Kabupaten Kediri'],
            ['kode_satker' => '3507', 'nama_satker' => 'BPS Kabupaten Malang'],
            ['kode_satker' => '3508', 'nama_satker' => 'BPS Kabupaten Lumajang'],
            ['kode_satker' => '3509', 'nama_satker' => 'BPS Kabupaten Jember'],
            ['kode_satker' => '3510', 'nama_satker' => 'BPS Kabupaten Banyuwangi'],
            ['kode_satker' => '3511', 'nama_satker' => 'BPS Kabupaten Bondowoso'],
            ['kode_satker' => '3512', 'nama_satker' => 'BPS Kabupaten Situbondo'],
            ['kode_satker' => '3513', 'nama_satker' => 'BPS Kabupaten Probolinggo'],
            ['kode_satker' => '3514', 'nama_satker' => 'BPS Kabupaten Pasuruan'],
            ['kode_satker' => '3515', 'nama_satker' => 'BPS Kabupaten Sidoarjo'],
            ['kode_satker' => '3516', 'nama_satker' => 'BPS Kabupaten Mojokerto'],
            ['kode_satker' => '3517', 'nama_satker' => 'BPS Kabupaten Jombang'],
            ['kode_satker' => '3518', 'nama_satker' => 'BPS Kabupaten Nganjuk'],
            ['kode_satker' => '3519', 'nama_satker' => 'BPS Kabupaten Madiun'],
            ['kode_satker' => '3520', 'nama_satker' => 'BPS Kabupaten Magetan'],
            ['kode_satker' => '3521', 'nama_satker' => 'BPS Kabupaten Ngawi'],
            ['kode_satker' => '3522', 'nama_satker' => 'BPS Kabupaten Bojonegoro'],
            ['kode_satker' => '3523', 'nama_satker' => 'BPS Kabupaten Tuban'],
            ['kode_satker' => '3524', 'nama_satker' => 'BPS Kabupaten Lamongan'],
            ['kode_satker' => '3525', 'nama_satker' => 'BPS Kabupaten Gresik'],
            ['kode_satker' => '3526', 'nama_satker' => 'BPS Kabupaten Bangkalan'],
            ['kode_satker' => '3527', 'nama_satker' => 'BPS Kabupaten Sampang'],
            ['kode_satker' => '3528', 'nama_satker' => 'BPS Kabupaten Pamekasan'],
            ['kode_satker' => '3529', 'nama_satker' => 'BPS Kabupaten Sumenep'],
            ['kode_satker' => '3571', 'nama_satker' => 'BPS Kota Kediri'],
            ['kode_satker' => '3572', 'nama_satker' => 'BPS Kota Blitar'],
            ['kode_satker' => '3573', 'nama_satker' => 'BPS Kota Malang'],
            ['kode_satker' => '3574', 'nama_satker' => 'BPS Kota Probolinggo'],
            ['kode_satker' => '3575', 'nama_satker' => 'BPS Kota Pasuruan'],
            ['kode_satker' => '3576', 'nama_satker' => 'BPS Kota Mojokerto'],
            ['kode_satker' => '3577', 'nama_satker' => 'BPS Kota Madiun'],
            ['kode_satker' => '3578', 'nama_satker' => 'BPS Kota Surabaya'],
            ['kode_satker' => '3579', 'nama_satker' => 'BPS Kota Batu'],
        ];
        DB::table('master_satker')->insert($satkers);
    }
}
