<?php

namespace Tests\Unit;

use Tests\TestCase;
use App\Models\Submission;
use App\Models\Result;
use App\Models\Visitasi;
use App\Models\Interview;
use App\Models\MasterPembobotan;
use App\Services\PenilaianService;

class EvaluationTest extends TestCase
{
    /**
     * Test KIP Index Classification logic.
     */
    public function test_kip_index_classification()
    {
        $this->assertEquals('INFORMATIF', $this->getPredikat(92.45));
        $this->assertEquals('MENUJU INFORMATIF', $this->getPredikat(80.00));
        $this->assertEquals('CUKUP INFORMATIF', $this->getPredikat(75.50));
        $this->assertEquals('CUKUP INFORMATIF', $this->getPredikat(70.00));
        $this->assertEquals('CUKUP INFORMATIF', $this->getPredikat(65.00));
        $this->assertEquals('CUKUP INFORMATIF', $this->getPredikat(60.00));
        $this->assertEquals('KURANG INFORMATIF', $this->getPredikat(55.00));
        $this->assertEquals('KURANG INFORMATIF', $this->getPredikat(40.00));
        $this->assertEquals('TIDAK INFORMATIF', $this->getPredikat(39.99));
        $this->assertEquals('TIDAK INFORMATIF', $this->getPredikat(0.00));
    }

    /**
     * Test Final Score Calculation logic.
     */
    public function test_final_score_calculation()
    {
        $saqScore = 85.50; // 30% -> 25.65
        $visitScore = 90.00; // 40% -> 36.00
        $interviewScore = 95.00; // 30% -> 28.50
        // Expected: 25.65 + 36.00 + 28.50 = 90.15

        $finalScore = ($saqScore * 0.3) + ($visitScore * 0.4) + ($interviewScore * 0.3);
        $this->assertEquals(90.15, round($finalScore, 2));
    }

    /**
     * Test Tie-Breaker Ranking when a stage has 0% weight.
     * Skenario: SAQ 40%, Wawancara 60%, Visitasi 0%.
     * Kabkot A dan Kabkot B sama-sama memiliki Nilai Akhir 90.00.
     * Kabkot A memiliki Nilai Visitasi 95, Kabkot B memiliki Nilai Visitasi 85.
     * Peringkat 1 harus Kabkot A.
     */
    public function test_tie_breaker_ranking_with_zero_weight_stage()
    {
        $service = app(PenilaianService::class);

        // Mock Sub A: SAQ 90, Wawancara 90, Visitasi 95 -> Final = 90.00
        $subA = new Submission();
        $subA->id_submission = 1;
        $subA->calculated_final = 90.00;
        $resA = new Result();
        $resA->kode_satker = '3501';
        $resA->ques_score = 90.00;
        $resA->final_score = 90.00;
        $subA->setRelation('result', $resA);
        $visA = new Visitasi();
        $visA->visit_score = 95.00;
        $subA->setRelation('visitasi', $visA);
        $intA = new Interview();
        $intA->interview_score = 90.00;
        $subA->setRelation('interview', $intA);

        // Mock Sub B: SAQ 90, Wawancara 90, Visitasi 85 -> Final = 90.00
        $subB = new Submission();
        $subB->id_submission = 2;
        $subB->calculated_final = 90.00;
        $resB = new Result();
        $resB->kode_satker = '3502';
        $resB->ques_score = 90.00;
        $resB->final_score = 90.00;
        $subB->setRelation('result', $resB);
        $visB = new Visitasi();
        $visB->visit_score = 85.00;
        $subB->setRelation('visitasi', $visB);
        $intB = new Interview();
        $intB->interview_score = 90.00;
        $subB->setRelation('interview', $intB);

        // Mock MasterPembobotan: SAQ 40%, Wawancara 60%, Visitasi 0%
        $pembobotanMock = new MasterPembobotan();
        $pembobotanMock->weight_saq = 40.0;
        $pembobotanMock->weight_wawancara = 60.0;
        $pembobotanMock->weight_visitasi = 0.0;
        $pembobotanMock->stage_order = ['saq', 'wawancara', 'visitasi'];

        // Masukkan koleksi dalam urutan acak [B, A]
        $collection = collect([$subB, $subA]);

        // Jalankan sortSubmissions dengan $pembobotanMock
        $sorted = $service->sortSubmissions($collection, $pembobotanMock, 'desc');

        $this->assertCount(2, $sorted);
        // Sub A (id=1) harus di peringkat 1 karena Visitasi 95 > Visitasi 85 milik Sub B
        $this->assertEquals(1, $sorted->first()->id_submission);
        $this->assertEquals(2, $sorted->last()->id_submission);
    }

    /**
     * Test stage order resolution fallback and string handling.
     */
    public function test_stage_order_resolution()
    {
        $p = new MasterPembobotan();
        $p->stage_order = ['wawancara', 'visitasi', 'saq'];
        $this->assertEquals(['wawancara', 'visitasi', 'saq'], $p->resolvedStageOrder());

        $p2 = new MasterPembobotan();
        $p2->stage_order = null;
        $this->assertEquals(['saq', 'visitasi', 'wawancara'], $p2->resolvedStageOrder());

        $p3 = new MasterPembobotan();
        $p3->stage_order = json_encode(['wawancara', 'saq', 'visitasi']);
        $this->assertEquals(['wawancara', 'saq', 'visitasi'], $p3->resolvedStageOrder());
    }

    /**
     * Test Period date realignment according to stage order.
     */
    public function test_period_realign_stage_dates()
    {
        $period = new \App\Models\Period();
        $period->periode_start   = '2026-08-01';
        $period->saq_start       = '2026-08-01';
        $period->saq_end         = '2026-08-10';
        $period->eval_start      = '2026-08-11';
        $period->eval_end        = '2026-08-15';
        $period->visit_start     = '2026-08-16';
        $period->visit_end       = '2026-08-20';
        $period->interview_start = '2026-08-21';
        $period->interview_end   = '2026-08-25';
        $period->result_start    = '2026-08-26';
        $period->result_end      = '2026-08-30';

        // Realign with Wawancara -> Visitasi -> SAQ
        $stageOrder = ['wawancara', 'visitasi', 'saq'];
        
        // Emulate update without db call
        $durSaq       = max(1, \Carbon\Carbon::parse($period->saq_start)->diffInDays(\Carbon\Carbon::parse($period->saq_end)) + 1);
        $durEval      = max(1, \Carbon\Carbon::parse($period->eval_start)->diffInDays(\Carbon\Carbon::parse($period->eval_end)) + 1);
        $durVisit     = max(1, \Carbon\Carbon::parse($period->visit_start)->diffInDays(\Carbon\Carbon::parse($period->visit_end)) + 1);
        $durInterview = max(1, \Carbon\Carbon::parse($period->interview_start)->diffInDays(\Carbon\Carbon::parse($period->interview_end)) + 1);

        $cursor = \Carbon\Carbon::parse($period->periode_start);
        $newDates = [];
        foreach ($stageOrder as $stgKey) {
            if ($stgKey === 'wawancara') {
                $newDates['interview_start'] = $cursor->toDateString();
                $newDates['interview_end']   = $cursor->copy()->addDays($durInterview - 1)->toDateString();
                $cursor = \Carbon\Carbon::parse($newDates['interview_end'])->addDay();
            } elseif ($stgKey === 'visitasi') {
                $newDates['visit_start'] = $cursor->toDateString();
                $newDates['visit_end']   = $cursor->copy()->addDays($durVisit - 1)->toDateString();
                $cursor = \Carbon\Carbon::parse($newDates['visit_end'])->addDay();
            } elseif ($stgKey === 'saq') {
                $newDates['saq_start']  = $cursor->toDateString();
                $newDates['saq_end']    = $cursor->copy()->addDays($durSaq - 1)->toDateString();
                $newDates['eval_start'] = \Carbon\Carbon::parse($newDates['saq_end'])->addDay()->toDateString();
                $newDates['eval_end']   = \Carbon\Carbon::parse($newDates['eval_start'])->addDays($durEval - 1)->toDateString();
                $cursor = \Carbon\Carbon::parse($newDates['eval_end'])->addDay();
            }
        }

        $this->assertTrue(\Carbon\Carbon::parse($newDates['interview_start'])->lessThan(\Carbon\Carbon::parse($newDates['visit_start'])));
        $this->assertTrue(\Carbon\Carbon::parse($newDates['visit_start'])->lessThan(\Carbon\Carbon::parse($newDates['saq_start'])));
    }

    /**
     * Helper mimicking ResultController's getPredikat method.
     */
    private function getPredikat($score)
    {
        if ($score >= 90) {
            return 'INFORMATIF';
        } elseif ($score >= 80) {
            return 'MENUJU INFORMATIF';
        } elseif ($score >= 60) {
            return 'CUKUP INFORMATIF';
        } elseif ($score >= 40) {
            return 'KURANG INFORMATIF';
        } else {
            return 'TIDAK INFORMATIF';
        }
    }
}
