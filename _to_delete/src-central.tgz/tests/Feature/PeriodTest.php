<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;
use App\Models\User;
use App\Models\Period;

class PeriodTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();

        // Seed Spatie roles
        $this->seed(\Database\Seeders\RoleSeeder::class);

        // Seed satkers
        \DB::table('master_satker')->insert([
            ['kode_satker' => '3500', 'nama_satker' => 'BPS Provinsi Jawa Timur'],
        ]);
    }

    /**
     * Test manage periods page renders and CRUD operations work.
     */
    public function test_evaluator_can_manage_periods()
    {
        $evaluator = User::create([
            'nama_user' => 'evaluator1',
            'email' => 'evaluator1@bps.go.id',
            'password' => \Hash::make('password123'),
            'kode_satker' => '3500',
        ]);
        $evaluator->assignRole('evaluator');

        // 1. Get manage periods list (should be empty/no records initially, except we can query it)
        $response = $this->actingAs($evaluator)->get('/evaluator/manage-jadwal');
        $response->assertStatus(200);

        // 2. Add a new period (store)
        $storeResponse = $this->actingAs($evaluator)->post('/evaluator/periode', [
            'start' => '2026-06-01',
            'end' => '2026-07-31',
        ]);

        $storeResponse->assertRedirect('/evaluator/manage-jadwal');
        $this->assertDatabaseHas('periods', [
            'periode_start' => '2026-06-01',
            'periode_end' => '2026-07-31',
        ]);

        $period = Period::first();

        // 3. Edit period (update)
        $updateResponse = $this->actingAs($evaluator)->put("/evaluator/periode/{$period->id_periode}", [
            'start' => '2026-06-10',
            'end' => '2026-08-10',
        ]);

        $updateResponse->assertRedirect('/evaluator/manage-jadwal');
        $this->assertDatabaseHas('periods', [
            'id_periode' => $period->id_periode,
            'periode_start' => '2026-06-10',
            'periode_end' => '2026-08-10',
        ]);

        // 4. Delete period (destroy)
        $deleteResponse = $this->actingAs($evaluator)->delete("/evaluator/periode/{$period->id_periode}");
        $deleteResponse->assertRedirect('/evaluator/manage-jadwal');
        $this->assertDatabaseMissing('periods', [
            'id_periode' => $period->id_periode,
        ]);
    }

    /**
     * Test overlap validation and dynamic Roman suffix.
     */
    public function test_period_overlap_validation_and_roman_numerals()
    {
        $evaluator = User::create([
            'nama_user' => 'evaluator1',
            'email' => 'evaluator1@bps.go.id',
            'password' => \Hash::make('password123'),
            'kode_satker' => '3500',
        ]);
        $evaluator->assignRole('evaluator');

        // 1. Create a base period
        $period1 = Period::create([
            'periode_start' => '2026-06-01',
            'periode_end' => '2026-06-30',
            'saq_start' => '2026-06-01', 'saq_end' => '2026-06-10',
            'eval_start' => '2026-06-11', 'eval_end' => '2026-06-15',
            'visit_start' => '2026-06-16', 'visit_end' => '2026-06-20',
            'interview_start' => '2026-06-21', 'interview_end' => '2026-06-25',
            'result_start' => '2026-06-26', 'result_end' => '2026-06-30',
        ]);

        $this->assertEquals('Evaluasi KIP 2026', $period1->nama);

        // 2. Try creating an overlapping period (should fail validation)
        $response = $this->actingAs($evaluator)
            ->from('/evaluator/manage-jadwal')
            ->post('/evaluator/periode', [
                'start' => '2026-06-15',
                'end' => '2026-07-15',
            ]);

        $response->assertSessionHasErrors('start');

        // 3. Create a non-overlapping period in the same year
        $period2 = Period::create([
            'periode_start' => '2026-07-01',
            'periode_end' => '2026-07-31',
            'saq_start' => '2026-07-01', 'saq_end' => '2026-07-10',
            'eval_start' => '2026-07-11', 'eval_end' => '2026-07-15',
            'visit_start' => '2026-07-16', 'visit_end' => '2026-07-20',
            'interview_start' => '2026-07-21', 'interview_end' => '2026-07-25',
            'result_start' => '2026-07-26', 'result_end' => '2026-07-31',
        ]);

        $this->assertEquals('Evaluasi KIP II 2026', $period2->nama);

        // 4. Try updating period 2 to overlap with period 1 (should fail validation)
        $updateResponse = $this->actingAs($evaluator)
            ->from('/evaluator/manage-jadwal')
            ->put("/evaluator/periode/{$period2->id_periode}", [
                'start' => '2026-06-25',
                'end' => '2026-07-25',
            ]);

        $updateResponse->assertSessionHasErrors('start');
    }
}
