<?php

namespace Tests\Feature\Evaluasi;

use App\Models\Interview;
use App\Models\Period;
use App\Models\Result;
use App\Models\Submission;
use App\Models\User;
use App\Models\Visitasi;
use App\Services\NavigationService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Tests\TestCase;

class PenilaiEksternalMonitoringNavTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed(\Database\Seeders\RoleSeeder::class);

        DB::table('master_satker')->insert([
            ['kode_satker' => '3500', 'nama_satker' => 'BPS Provinsi Jawa Timur'],
            ['kode_satker' => '3578', 'nama_satker' => 'BPS Kota Surabaya'],
        ]);

        NavigationService::clearAssignedStagesCache();
    }

    public function test_penilai_eksternal_assigned_only_visitasi_shows_only_visitasi_and_penilaian_akhir()
    {
        $user = User::create([
            'nama_user' => 'Eksternal Visitasi Only',
            'email' => 'visitasi_only@test.com',
            'password' => Hash::make('password123'),
            'kode_satker' => '3500',
        ]);
        $user->assignRole('penilai_eksternal');
        Auth::login($user);

        // Buat penugasan di visitasi saja
        $visit = Visitasi::create([]);
        $visit->evaluators()->create(['id_user' => $user->id_user]);

        $items = NavigationService::getSidebarItems('penilai_eksternal');
        $monitoring = collect($items)->firstWhere('label', 'Monitoring Kegiatan');

        $this->assertNotNull($monitoring);
        $children = collect($monitoring['children']);

        $labels = $children->pluck('label')->all();
        $this->assertEquals(['Visitasi & Verif. Faktual', 'Penilaian Akhir'], $labels);
    }

    public function test_penilai_eksternal_assigned_saq_and_wawancara_shows_saq_wawancara_and_penilaian_akhir()
    {
        $user = User::create([
            'nama_user' => 'Eksternal SAQ & Wawancara',
            'email' => 'saq_wawancara@test.com',
            'password' => Hash::make('password123'),
            'kode_satker' => '3500',
        ]);
        $user->assignRole('penilai_eksternal');
        Auth::login($user);

        // Buat penugasan SAQ
        $sub = Submission::create([
            'status' => 3,
        ]);
        $sub->evaluators()->attach($user->id_user);

        // Buat penugasan Wawancara
        $interview = Interview::create([]);
        $interview->evaluators()->create(['id_user' => $user->id_user]);

        $items = NavigationService::getSidebarItems('penilai_eksternal');
        $monitoring = collect($items)->firstWhere('label', 'Monitoring Kegiatan');

        $this->assertNotNull($monitoring);
        $children = collect($monitoring['children']);

        $labels = $children->pluck('label')->all();
        $this->assertEquals(['Kuesioner SAQ', 'Wawancara', 'Penilaian Akhir'], $labels);
    }

    public function test_penilai_eksternal_without_assignment_shows_only_penilaian_akhir()
    {
        $user = User::create([
            'nama_user' => 'Eksternal Unassigned',
            'email' => 'unassigned@test.com',
            'password' => Hash::make('password123'),
            'kode_satker' => '3500',
        ]);
        $user->assignRole('penilai_eksternal');
        Auth::login($user);

        $items = NavigationService::getSidebarItems('penilai_eksternal');
        $monitoring = collect($items)->firstWhere('label', 'Monitoring Kegiatan');

        $this->assertNotNull($monitoring);
        $children = collect($monitoring['children']);

        $labels = $children->pluck('label')->all();
        $this->assertEquals(['Penilaian Akhir'], $labels);
    }
}
