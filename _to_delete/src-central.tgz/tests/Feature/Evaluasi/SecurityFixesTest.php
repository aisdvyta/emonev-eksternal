<?php

namespace Tests\Feature\Evaluasi;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;
use App\Models\User;
use App\Models\Period;
use App\Models\Result;
use App\Models\Submission;
use App\Models\MasterSatker;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class SecurityFixesTest extends TestCase
{
    use RefreshDatabase;

    protected User $evaluatorA;
    protected User $evaluatorB;
    protected User $verifikator3501;
    protected User $verifikator3502;
    protected Period $period;
    protected Submission $submission3501;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed(\Database\Seeders\RoleSeeder::class);

        DB::table('master_satker')->insert([
            ['kode_satker' => '3500', 'nama_satker' => 'BPS Provinsi Jawa Timur'],
            ['kode_satker' => '3501', 'nama_satker' => 'BPS Kabupaten Pacitan'],
            ['kode_satker' => '3502', 'nama_satker' => 'BPS Kabupaten Ponorogo'],
        ]);

        $this->period = Period::create([
            'nama' => 'Periode 2026',
            'tahun' => 2026,
            'periode_start' => '2026-01-01',
            'periode_end' => '2026-12-31',
            'saq_start' => '2026-01-01',
            'saq_end' => '2026-02-01',
            'verif_start' => '2026-02-02',
            'verif_end' => '2026-03-01',
            'visit_start' => '2026-03-02',
            'visit_end' => '2026-04-01',
            'interview_start' => '2026-04-02',
            'interview_end' => '2026-05-01',
            'result_start' => '2026-05-02',
            'result_end' => '2026-06-01',
        ]);

        $this->evaluatorA = User::create([
            'nama_user' => 'Evaluator A',
            'email' => 'evaluatorA@test.com',
            'password' => Hash::make('password123'),
            'kode_satker' => '3500',
        ]);
        $this->evaluatorA->assignRole('evaluator');

        $this->evaluatorB = User::create([
            'nama_user' => 'Evaluator B',
            'email' => 'evaluatorB@test.com',
            'password' => Hash::make('password123'),
            'kode_satker' => '3500',
        ]);
        $this->evaluatorB->assignRole('evaluator');

        $this->verifikator3501 = User::create([
            'nama_user' => 'Kasubag 3501',
            'email' => 'verifikator3501@test.com',
            'password' => Hash::make('password123'),
            'kode_satker' => '3501',
        ]);
        $this->verifikator3501->assignRole('verifikator');

        $this->verifikator3502 = User::create([
            'nama_user' => 'Kasubag 3502',
            'email' => 'verifikator3502@test.com',
            'password' => Hash::make('password123'),
            'kode_satker' => '3502',
        ]);
        $this->verifikator3502->assignRole('verifikator');

        $result = Result::create([
            'kode_satker' => '3501',
            'id_periode' => $this->period->id_periode,
        ]);

        $this->submission3501 = Submission::create([
            'id_result' => $result->id_result,
            'status' => 3, // Verified
        ]);

        // Tugaskan Evaluator A ke submission 3501
        $this->submission3501->evaluators()->attach($this->evaluatorA->id_user);
    }

    /**
     * F-01: Evaluator yang tidak ditugaskan ditolak saat review SAQ (HTTP 403).
     */
    public function test_unassigned_evaluator_cannot_review_saq()
    {
        $response = $this->actingAs($this->evaluatorB)
            ->get(route('evaluator.review-kues', ['submission' => $this->submission3501->id_submission]));

        $response->assertStatus(403);
    }

    /**
     * F-01: Evaluator yang tidak ditugaskan ditolak saat export SAQ (HTTP 403).
     */
    public function test_unassigned_evaluator_cannot_export_saq()
    {
        $response = $this->actingAs($this->evaluatorB)
            ->get(route('evaluator.review-kues.export', ['submission' => $this->submission3501->id_submission]));

        $response->assertStatus(403);
    }

    /**
     * F-01: Evaluator ditolak jika submission belum diverifikasi (status < 3).
     */
    public function test_evaluator_cannot_review_or_export_unverified_saq()
    {
        $this->submission3501->update(['status' => 1]); // Status menunggu verifikasi

        $reviewResp = $this->actingAs($this->evaluatorA)
            ->get(route('evaluator.review-kues', ['submission' => $this->submission3501->id_submission]));
        $reviewResp->assertStatus(403);

        $exportResp = $this->actingAs($this->evaluatorA)
            ->get(route('evaluator.review-kues.export', ['submission' => $this->submission3501->id_submission]));
        $exportResp->assertStatus(403);
    }

    /**
     * F-02: Role evaluator biasa ditolak dari rute penjadwalan visitasi (HTTP 403).
     */
    public function test_evaluator_cannot_schedule_visitasi()
    {
        // JSON request menerima 403 Forbidden
        $jsonResp = $this->actingAs($this->evaluatorA)
            ->postJson(route('evaluator.schedule-visitasi', ['id' => 1]), [
                'visit_mode' => 'offline',
                'id_visitor' => [$this->evaluatorA->id_user],
            ]);
        $jsonResp->assertStatus(403);

        // Web request dialihkan ke index evaluator dengan pesan peringatan (tidak sampai ke controller)
        $webResp = $this->actingAs($this->evaluatorA)
            ->post(route('evaluator.schedule-visitasi', ['id' => 1]), [
                'visit_mode' => 'offline',
                'id_visitor' => [$this->evaluatorA->id_user],
            ]);
        $webResp->assertRedirect(route('evaluator.index'));
    }

    /**
     * F-04: Verifikator 3502 tidak boleh mengakses submission milik satker 3501 (HTTP 403).
     */
    public function test_verifikator_cross_satker_access_is_forbidden()
    {
        $response = $this->actingAs($this->verifikator3502)
            ->get(route('verifikator.verifikasi-saq', ['submission' => $this->submission3501->id_submission]));

        $response->assertStatus(403);
    }

    /**
     * K-01: Verifikator tidak bisa memproses keputusan jika status bukan menunggu verifikasi (status != 1).
     */
    public function test_verifikator_cannot_decide_submission_when_status_not_one()
    {
        $this->submission3501->update(['status' => 3]); // Sudah berstatus lolos verifikasi

        $response = $this->actingAs($this->verifikator3501)
            ->post(route('verifikator.verifikasi-saq.decision', ['id' => $this->submission3501->id_submission]), [
                'decision' => 'approve',
                'verification_note' => 'Disetujui ulang secara ilegal',
            ]);

        $response->assertStatus(409);
    }

    /**
     * K-02: Publikasi penilaian ditolak jika submission belum menyelesaikan tahap evaluasi/wawancara (status != 5, 6).
     */
    public function test_publish_rejected_when_submission_not_in_final_stage()
    {
        $admin = User::create([
            'nama_user' => 'Admin',
            'email' => 'admin@test.com',
            'password' => Hash::make('password123'),
            'kode_satker' => '3500',
        ]);
        $admin->assignRole('admin');

        $this->submission3501->update(['status' => 3]); // Baru tahap evaluasi awal

        $response = $this->actingAs($admin)
            ->post(route('evaluasi.penilaian.publish', ['id' => $this->submission3501->id_submission]));

        $response->assertStatus(409);
    }
}
