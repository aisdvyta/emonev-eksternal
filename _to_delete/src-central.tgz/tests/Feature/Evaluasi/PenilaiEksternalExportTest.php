<?php

namespace Tests\Feature\Evaluasi;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;
use App\Models\User;
use App\Models\Period;
use App\Models\Result;
use App\Models\Submission;
use App\Models\MasterSatker;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class PenilaiEksternalExportTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed(\Database\Seeders\RoleSeeder::class);

        DB::table('master_satker')->insert([
            ['kode_satker' => '3500', 'nama_satker' => 'BPS Provinsi Jawa Timur'],
            ['kode_satker' => '3578', 'nama_satker' => 'BPS Kota Surabaya'],
        ]);
    }

    public function test_penilai_eksternal_can_view_penilaian_page_with_unduh_button()
    {
        $user = User::create([
            'nama_user' => 'eksternal_test',
            'email' => 'eksternal@test.com',
            'password' => Hash::make('password123'),
            'kode_satker' => '3500',
        ]);
        $user->assignRole('penilai_eksternal');

        $period = Period::create([
            'nama' => 'Periode 2025',
            'tahun' => 2025,
            'periode_start' => '2025-01-01',
            'periode_end' => '2025-05-01',
            'saq_start' => '2025-01-01',
            'saq_end' => '2025-02-01',
            'verif_start' => '2025-02-02',
            'verif_end' => '2025-03-01',
            'visit_start' => '2025-03-02',
            'visit_end' => '2025-03-15',
            'interview_start' => '2025-03-16',
            'interview_end' => '2025-04-01',
            'result_start' => '2025-04-02',
            'result_end' => '2025-05-01', // Ended in past
        ]);

        $response = $this->actingAs($user)->get(route('penilai-eksternal.penilaian'));

        $response->assertStatus(200);
        $response->assertSee('Unduh Excel');
        $response->assertSee('id="modal-export"', false);
    }

    public function test_penilai_eksternal_dashboard_layout()
    {
        $user = User::create([
            'nama_user' => 'eksternal_test',
            'email' => 'eksternal@test.com',
            'password' => Hash::make('password123'),
            'kode_satker' => '3500',
        ]);
        $user->assignRole('penilai_eksternal');

        $period = Period::create([
            'nama' => 'Periode 2026',
            'tahun' => 2026,
            'periode_start' => '2026-01-01',
            'periode_end' => '2026-12-31',
            'saq_start' => '2026-01-01',
            'saq_end' => '2026-02-01',
            'verif_start' => '2026-02-02',
            'verif_end' => '2026-03-01',
            'visit_start' => '2026-03-02',
            'visit_end' => '2026-03-15',
            'interview_start' => '2026-03-16',
            'interview_end' => '2026-04-01',
            'result_start' => '2026-04-02',
            'result_end' => '2026-12-31',
        ]);

        $response = $this->actingAs($user)->get(route('dashboard'));

        $response->assertStatus(200);
        $response->assertSee('Progress Evaluasi Tahun 2026');
        $response->assertSee('Agenda Mendatang');
        $response->assertSee('Fase Saat Ini:');
    }

    public function test_penilai_eksternal_cannot_export_ongoing_period()
    {
        $user = User::create([
            'nama_user' => 'eksternal_test',
            'email' => 'eksternal@test.com',
            'password' => Hash::make('password123'),
            'kode_satker' => '3500',
        ]);
        $user->assignRole('penilai_eksternal');

        $ongoingPeriod = Period::create([
            'nama' => 'Periode 2026',
            'tahun' => 2026,
            'periode_start' => '2026-01-01',
            'periode_end' => '2026-12-31',
            'saq_start' => '2026-01-01',
            'saq_end' => '2026-02-01',
            'verif_start' => '2026-02-02',
            'verif_end' => '2026-03-01',
            'visit_start' => '2026-03-02',
            'visit_end' => '2026-03-15',
            'interview_start' => '2026-03-16',
            'interview_end' => '2026-04-01',
            'result_start' => '2026-04-02',
            'result_end' => '2026-12-31', // Active
        ]);

        $response = $this->actingAs($user)->get(route('penilai-eksternal.penilaian.export', [
            'id_periode' => $ongoingPeriod->id_periode,
            'validate' => 1,
        ]));

        $response->assertJson([
            'success' => false,
            'message' => 'Periode yang sedang berjalan belum memiliki penilaian akhir yang final.',
        ]);
    }

    public function test_penilai_eksternal_can_export_ended_period()
    {
        $user = User::create([
            'nama_user' => 'eksternal_test',
            'email' => 'eksternal@test.com',
            'password' => Hash::make('password123'),
            'kode_satker' => '3500',
        ]);
        $user->assignRole('penilai_eksternal');

        $opUser = User::create([
            'nama_user' => 'op_surabaya',
            'email' => 'op@surabaya.com',
            'password' => Hash::make('password123'),
            'kode_satker' => '3578',
        ]);
        $opUser->assignRole('operator');

        $endedPeriod = Period::create([
            'nama' => 'Periode 2024',
            'tahun' => 2024,
            'periode_start' => '2024-01-01',
            'periode_end' => '2024-05-01',
            'saq_start' => '2024-01-01',
            'saq_end' => '2024-02-01',
            'verif_start' => '2024-02-02',
            'verif_end' => '2024-03-01',
            'visit_start' => '2024-03-02',
            'visit_end' => '2024-03-15',
            'interview_start' => '2024-03-16',
            'interview_end' => '2024-04-01',
            'result_start' => '2024-04-02',
            'result_end' => '2024-05-01', // Ended
        ]);

        $res = Result::create([
            'id_periode' => $endedPeriod->id_periode,
            'kode_satker' => '3578',
            'ques_score' => 90,
            'final_score' => 90,
        ]);

        $sub = Submission::create([
            'id_user' => $opUser->id_user,
            'id_result' => $res->id_result,
            'status' => 7,
        ]);

        // Validate check
        $resValidate = $this->actingAs($user)->get(route('penilai-eksternal.penilaian.export', [
            'id_periode' => $endedPeriod->id_periode,
            'validate' => 1,
        ]));
        $resValidate->assertJson(['success' => true]);

        // Actual export download
        $resExport = $this->actingAs($user)->get(route('penilai-eksternal.penilaian.export', [
            'id_periode' => $endedPeriod->id_periode,
        ]));
        $resExport->assertStatus(200);
        $resExport->assertHeader('content-type', 'application/vnd.ms-excel; charset=utf-8');
    }
}

