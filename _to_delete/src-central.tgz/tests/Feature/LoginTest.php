<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;
use App\Models\User;
use App\Models\Period;

class LoginTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();

        // Seed Spatie roles
        $this->seed(\Database\Seeders\RoleSeeder::class);

        // Seed necessary satkers
        \DB::table('master_satker')->insert([
            ['kode_satker' => '3500', 'nama_satker' => 'BPS Provinsi Jawa Timur'],
            ['kode_satker' => '3578', 'nama_satker' => 'BPS Kota Surabaya'],
        ]);
    }

    /**
     * Test login view contains no role selector and has correct inputs.
     */
    public function test_login_view_has_username_and_password_only()
    {
        $response = $this->get(route('login'));
        $response->assertStatus(200);
        $response->assertSee('Username atau Email');
        $response->assertSee('Password');
        $response->assertDontSee('PILIH PERAN');
        $response->assertDontSee('Kab/Kota');
        $response->assertDontSee('Provinsi');
    }

    /**
     * Test successful login and redirect based on role.
     */
    public function test_user_can_login_with_correct_credentials()
    {
        $user = User::create([
            'nama_user' => 'op_surabaya',
            'email' => 'op_surabaya@bps.go.id',
            'password' => \Hash::make('password123'),
            'kode_satker' => '3578',
        ]);
        $user->assignRole('operator');

        $response = $this->post('/login', [
            'nama_user' => 'op_surabaya',
            'password' => 'password123',
        ]);

        $response->assertRedirect('/operator');
        $this->assertAuthenticatedAs($user);
    }

    /**
     * Test operator page works when logged in.
     */
    public function test_operator_dashboard_loads_without_query_exception()
    {
        $user = User::create([
            'nama_user' => 'op_surabaya',
            'email' => 'op_surabaya@bps.go.id',
            'password' => \Hash::make('password123'),
            'kode_satker' => '3578',
        ]);
        $user->assignRole('operator');

        // Seed period
        Period::create([
            'id_periode' => 1,
            'periode_start' => '2026-05-01',
            'periode_end' => '2026-12-31',
            'saq_start' => '2026-05-15',
            'saq_end' => '2026-06-15',
            'eval_start' => '2026-06-16',
            'eval_end' => '2026-07-15',
            'visit_start' => '2026-07-16',
            'visit_end' => '2026-07-31',
            'interview_start' => '2026-08-01',
            'interview_end' => '2026-08-15',
            'result_start' => '2026-08-16',
            'result_end' => '2026-08-31',
        ]);

        $response = $this->actingAs($user)->get('/operator');
        $response->assertStatus(200);
        $response->assertSee('Selamat Datang');
        $response->assertSee('Sistem Monitoring');
    }

    /**
     * Test operator page contains the logout dropdown and clicking logout works.
     */
    public function test_operator_dashboard_has_logout_button_and_can_logout()
    {
        $user = User::create([
            'nama_user' => 'op_surabaya',
            'email' => 'op_surabaya@bps.go.id',
            'password' => \Hash::make('password123'),
            'kode_satker' => '3578',
        ]);
        $user->assignRole('operator');

        Period::create([
            'id_periode' => 1,
            'periode_start' => '2026-05-01',
            'periode_end' => '2026-12-31',
        ]);

        $response = $this->actingAs($user)->get('/operator');
        $response->assertStatus(200);
        $response->assertSee('Logout / Keluar');
        $response->assertSee('id="logout-form"', false);

        // Now post logout
        $logoutResponse = $this->actingAs($user)->post('/logout');
        $logoutResponse->assertRedirect('/');
        $this->assertGuest();
    }
}
