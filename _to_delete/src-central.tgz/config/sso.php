<?php

return [
    'auth_server_url' => env('SSO_BPS_AUTH_SERVER_URL', 'https://accounts.bps.go.id'),
    'realm'           => env('SSO_BPS_REALM', 'pegawai'),
    'client_id'       => env('SSO_BPS_CLIENT_ID', ''),
    'client_secret'   => env('SSO_BPS_CLIENT_SECRET', ''),
    'redirect_uri'    => env('SSO_BPS_REDIRECT_URI', env('APP_URL', 'http://localhost:8000') . '/auth/sso/callback'),
    'verify_ssl'      => env('SSO_BPS_VERIFY_SSL', false),
];
