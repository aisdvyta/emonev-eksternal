# Rencana Implementasi Refaktor Database & Standarisasi Kolom
**Sistem**: HaloKIP (emonev-refactor)  
**Dokumen**: `implementation_refactor_database.md`  
**Status**: Proposal Desain & Rencana Eksekusi  

---

## 1. Latar Belakang & Tujuan Refaktor

1. **Eliminasi Full Table Scan (Performa Query)**:
   - Menghilangkan pencarian teks pada kolom JSON (`LIKE '%"id_user":...'` dan `whereRaw("JSON_CONTAINS(...)")`) pada tabel `submissions`, `interview`, dan `visitasi`.
   - Menggantinya dengan relasi tabel standar yang ter-index B-Tree sehingga query filter dashboard dan monitoring Livewire berjalan instan (< 5ms).
2. **Integritas Relasi & Foreign Key**:
   - Memastikan ID evaluator dan operator terikat ke tabel `users(id_user)` dengan aturan integritas (`ON DELETE CASCADE` atau `SET NULL`), mencegah data *orphan*.
3. **Pencegahan *Race Condition***:
   - Mencegah data penilaian tertimpa ketika dua evaluator menilai sesi wawancara/visitasi yang sama dalam waktu bersamaan.
4. **Standarisasi Penamaan (*Naming Convention*)**:
   - Menyeragamkan nama-nama kolom yang fungsinya sama namun memiliki nama berbeda antar tabel (contoh: `link_meeting` vs `meets_link`, `scores` vs `bobot_pertanyaan`).

---

## 2. Matriks Standarisasi Nama Kolom

| Tabel | Nama Kolom Lama | Nama Kolom Baru | Tipe Data | Keterangan & Alasan |
| :--- | :--- | :--- | :--- | :--- |
| **`interview`** | `meets_link` | `link_meet_interview` | `VARCHAR(500)` nullable | Tautan virtual meeting (Google Meet/Zoom) khusus sesi wawancara. Diseragamkan menggunakan prefiks `link_meet_*`. |
| **`visitasi`** | `link_meeting` | `link_meet_visitasi` | `VARCHAR(500)` nullable | Tautan virtual meeting khusus sesi visitasi online. Diseragamkan dengan pola yang sama. |
| **`master_pertanyaan`** | `scores` | `bobot_pertanyaan` | `DECIMAL(5,2)` nullable | Menghilangkan ambiguitas antara "bobot soal kuesioner" vs "nilai/skor perolehan peserta". |
| **`submissions`** | `id_operator` (`TEXT`/JSON) | `id_operator` | `BIGINT UNSIGNED` nullable | Diubah dari teks array menjadi Foreign Key tunggal ke `users(id_user)` sebagai penanggung jawab kuesioner satker. |
| **`submissions`** | `evaluated_by` (JSON) | *(Dipindah ke tabel pivot)* | `submission_evaluators` | Penugasan tim evaluator penilai SAQ kuesioner. |
| **`interview`** | `interview_data` (JSON) | *(Dipindah ke tabel relasi)* | `interview_evaluators` | Rincian nilai, catatan, dan draft status per evaluator wawancara. |
| **`visitasi`** | `visit_data` (JSON) | *(Dipindah ke tabel relasi)* | `visitasi_evaluators` | Rincian nilai, catatan, dan draft status per evaluator visitasi. |
| **`master_link`** | *(Tabel Baru)* | `link_panduan` | `VARCHAR(500)` nullable | Tautan Google Drive panduan resmi per periode. Terhubung via `id_periode` (FK ke `periods`). |
| **`master_link`** | *(Tabel Baru)* | `link_drive_review_saq` | `VARCHAR(500)` nullable | Tautan Google Drive folder berkas PDF hasil review/kesimpulan SAQ kab/kota per periode (bisa diakses eksternal & evaluator). |

> [!NOTE]
> **Keputusan untuk `master_pembobotan`**:
> - **`stage_order`**: **Tetap dipertahankan sebagai JSON** pada tabel `master_pembobotan` karena hanya berupa array urutan 3 string (`['saq', 'visitasi', 'wawancara']`) yang bersifat konfigurasi murni dan tidak pernah dicari dengan `WHERE`.
> - **`bobot_indikator`**: **Tetap disimpan di `master_pembobotan`** (atau tabel baru `pembobotan_indikator`), **JANGAN dipindah langsung ke `master_indikator`**. Tabel `master_indikator` bersifat master global (tanpa tahun), sedangkan bobot indikator diatur berbeda per periode.

---

## 3. Desain Skema Database Baru (DDL Migration)

### 3.1. Tabel-Tabel Baru

#### A. Tabel Pivot: `submission_evaluators`
Menghubungkan submission kuesioner dengan tim evaluator penilainya (Many-to-Many).
```php
Schema::create('submission_evaluators', function (Blueprint $table) {
    $table->id();
    $table->unsignedBigInteger('id_submission');
    $table->unsignedBigInteger('id_user');
    $table->timestamps();

    $table->foreign('id_submission')->references('id_submission')->on('submissions')->onDelete('cascade');
    $table->foreign('id_user')->references('id_user')->on('users')->onDelete('cascade');

    $table->unique(['id_submission', 'id_user']);
    $table->index('id_user');
});
```

#### B. Tabel Relasi: `interview_evaluators`
Menyimpan penilaian dan catatan masing-masing evaluator pada sesi wawancara.
```php
Schema::create('interview_evaluators', function (Blueprint $table) {
    $table->id();
    $table->unsignedBigInteger('id_interview');
    $table->unsignedBigInteger('id_user');
    $table->decimal('score', 6, 2)->nullable();
    $table->text('catatan')->nullable();
    $table->boolean('is_draft')->default(true);
    $table->timestamps();

    $table->foreign('id_interview')->references('id_interview')->on('interview')->onDelete('cascade');
    $table->foreign('id_user')->references('id_user')->on('users')->onDelete('cascade');

    $table->unique(['id_interview', 'id_user']);
    $table->index('id_user');
    $table->index(['id_interview', 'is_draft']);
});
```

#### C. Tabel Relasi: `visitasi_evaluators`
Menyimpan penilaian dan catatan masing-masing evaluator pada sesi visitasi.
```php
Schema::create('visitasi_evaluators', function (Blueprint $table) {
    $table->id();
    $table->uuid('id_visit');
    $table->unsignedBigInteger('id_user');
    $table->decimal('score', 6, 2)->nullable();
    $table->text('catatan')->nullable();
    $table->boolean('is_draft')->default(true);
    $table->timestamps();

    $table->foreign('id_visit')->references('id_visit')->on('visitasi')->onDelete('cascade');
    $table->foreign('id_user')->references('id_user')->on('users')->onDelete('cascade');

    $table->unique(['id_visit', 'id_user']);
    $table->index('id_user');
    $table->index(['id_visit', 'is_draft']);
});
```

#### D. Tabel Pengaturan Link: `master_link`
Menyimpan seluruh tautan eksternal per periode (Link Panduan, Link Drive Review SAQ, dll).
```php
Schema::create('master_link', function (Blueprint $table) {
    $table->id('id_link');
    $table->unsignedBigInteger('id_periode')->unique();
    $table->string('link_panduan', 500)->nullable();
    $table->string('link_drive_review_saq', 500)->nullable();
    $table->timestamps();

    $table->foreign('id_periode')->references('id_periode')->on('periods')->onDelete('cascade');
});
```

---

### 3.2. Modifikasi Tabel Eksisting

#### A. Tabel `submissions`
```php
Schema::table('submissions', function (Blueprint $table) {
    // 1. Ubah id_operator menjadi foreign key ke users(id_user)
    $table->unsignedBigInteger('id_operator')->nullable()->change();
    $table->foreign('id_operator')->references('id_user')->on('users')->onDelete('set null');

    // 2. Drop kolom JSON evaluated_by setelah migrasi data
    // $table->dropColumn('evaluated_by');
});
```

#### B. Tabel `interview`
```php
Schema::table('interview', function (Blueprint $table) {
    // Rename kolom tautan meeting
    $table->renameColumn('meets_link', 'link_meet_interview');

    // Drop interview_data setelah migrasi data
    // $table->dropColumn('interview_data');
});
```

#### C. Tabel `visitasi`
```php
Schema::table('visitasi', function (Blueprint $table) {
    // Rename kolom tautan meeting
    $table->renameColumn('link_meeting', 'link_meet_visitasi');

    // Drop visit_data setelah migrasi data
    // $table->dropColumn('visit_data');
});
```

#### D. Tabel `master_pertanyaan`
```php
Schema::table('master_pertanyaan', function (Blueprint $table) {
    // Rename scores menjadi bobot_pertanyaan
    $table->renameColumn('scores', 'bobot_pertanyaan');
});
```

---

## 4. Rencana Migrasi Data (Data Seeder / Migration Script)

Untuk menjamin tidak ada data yang hilang (*zero-loss migration*), buat migrasi bertahap:

```php
// Contoh Script Migrasi Data dari JSON ke Tabel Relasi Baru:

// 1. Migrasi evaluated_by ke submission_evaluators
foreach (DB::table('submissions')->whereNotNull('evaluated_by')->cursor() as $sub) {
    $evaluators = json_decode($sub->evaluated_by, true) ?: [];
    foreach ($evaluators as $item) {
        $userId = is_array($item) ? ($item['id'] ?? $item['id_user'] ?? null) : $item;
        if ($userId && DB::table('users')->where('id_user', $userId)->exists()) {
            DB::table('submission_evaluators')->updateOrInsert(
                ['id_submission' => $sub->id_submission, 'id_user' => (int) $userId],
                ['created_at' => now(), 'updated_at' => now()]
            );
        }
    }
}

// 2. Migrasi interview_data ke interview_evaluators
foreach (DB::table('interview')->whereNotNull('interview_data')->cursor() as $inv) {
    $data = json_decode($inv->interview_data, true) ?: [];
    foreach ($data as $item) {
        $userId = $item['id_user'] ?? null;
        if ($userId && DB::table('users')->where('id_user', $userId)->exists()) {
            DB::table('interview_evaluators')->updateOrInsert(
                ['id_interview' => $inv->id_interview, 'id_user' => (int) $userId],
                [
                    'score'      => $item['score'] ?? null,
                    'catatan'    => $item['catatan'] ?? null,
                    'is_draft'   => (bool) ($item['is_draft'] ?? false),
                    'created_at' => now(),
                    'updated_at' => now(),
                ]
            );
        }
    }
}

// 3. Migrasi visit_data ke visitasi_evaluators (Logika sama seperti interview)
```

---

## 5. File-File yang Terdampak & Perubahan yang Diperlukan

### 5.1. Model Eloquent
1. **`App\Models\Submission`**:
   - Hapus casting `'evaluated_by' => 'array'` dan accessor parsing JSON manual.
   - Tambah relasi:
     ```php
     public function evaluators() {
         return $this->belongsToMany(User::class, 'submission_evaluators', 'id_submission', 'id_user');
     }
     public function operator() {
         return $this->belongsTo(User::class, 'id_operator', 'id_user');
     }
     ```
2. **`App\Models\Interview`**:
   - Ganti `'meets_link'` menjadi `'link_meet_interview'` di `$fillable`.
   - Hapus casting `'interview_data' => 'array'`.
   - Tambah relasi:
     ```php
     public function evaluators() {
         return $this->hasMany(InterviewEvaluator::class, 'id_interview', 'id_interview');
     }
     ```
3. **`App\Models\Visitasi`**:
   - Ganti `'link_meeting'` menjadi `'link_meet_visitasi'` di `$fillable`.
   - Hapus casting `'visit_data' => 'array'`.
   - Tambah relasi:
     ```php
     public function evaluators() {
         return $this->hasMany(VisitasiEvaluator::class, 'id_visit', 'id_visit');
     }
     ```
4. **`App\Models\MasterPertanyaan`**:
   - Ubah `$fillable` dari `'scores'` menjadi `'bobot_pertanyaan'`.

---

### 5.2. Service & Controller
1. **`App\Services\NavigationService`**:
   - **SEBELUM**: 8 baris klausa `WHERE evaluated_by LIKE '%...%'`.
   - **SESUDAH**:
     ```php
     $q->whereHas('submission.evaluators', fn($evQ) => $evQ->where('users.id_user', $userId));
     ```
2. **`App\Livewire\Evaluasi\MonitorWawancaraTable` & `MonitorVisitasiTable`**:
   - Filter query evaluator diganti dari `JSON_CONTAINS` atau `LIKE` menjadi:
     ```php
     $q->whereHas('evaluators', fn($ev) => $ev->where('id_user', $userId));
     ```
3. **`App\Http\Controllers\Evaluasi\WawancaraController` & `VisitasiController`**:
   - Ganti penyimpanan JSON array `$interview->interview_data = ...` menjadi `updateOrCreate` pada model `InterviewEvaluator`.
   - Ganti referensi `$interview->meets_link` menjadi `$interview->link_meet_interview`.
   - Ganti referensi `$visitasi->link_meeting` menjadi `$visitasi->link_meet_visitasi`.
4. **`App\Http\Controllers\Dokumen\SkSertifikatController`**:
   - Ubah `savePanduan` dan `readPanduanLink` untuk membaca/menulis ke kolom `periods.link_panduan` daripada `storage/app/panduan_url.txt`.

---

### 5.3. Blade Views
- `resources/views/pages/evaluasi/wawancara/review.blade.php`: input name & property `link_meet_interview`.
- `resources/views/pages/evaluasi/wawancara/detail.blade.php`: tampilan `link_meet_interview`.
- `resources/views/pages/evaluasi/visitasi/review.blade.php`: input name & property `link_meet_visitasi`.
- `resources/views/pages/evaluasi/visitasi/monitoring.blade.php`: modal & data binding `link_meet_visitasi`.
- `resources/views/pages/dokumen/manage-panduan.blade.php`: form update panduan periode.

---

## 6. Tahapan Langkah Eksekusi (Roadmap) & Status

- [x] **Fase 1: Migration Database & Kolom Standar** (Selesai - Commit `8e652b9`)
  - Tabel pivot & evaluasi baru: `submission_evaluators`, `interview_evaluators`, `visitasi_evaluators`, `master_link`.
  - Standardisasi nama kolom: `link_meet_interview`, `link_meet_visitasi`, `bobot_pertanyaan`.
- [x] **Fase 2: ETL Seeding / Migrasi Data Eksisting** (Selesai - Commit `babeab8`)
  - Script seeder `MigrateJsonToRelationalSeeder.php` berhasil menyalin 97 data SAQ evaluator, 90 interview evaluator, 66 visitasi evaluator, dan 3 data master link tanpa kehilangan data.
- [x] **Fase 3: Model Eloquent & Relasi Baru** (Selesai - Commit `c2a5f53`)
  - Model baru: `InterviewEvaluator`, `VisitasiEvaluator`, `SubmissionEvaluator`, `MasterLink`.
  - Relasi & kompatibilitas accessor/mutator di `Submission`, `Interview`, `Visitasi`, `Period`, dan `User`.
- [x] **Fase 4: Refactor Query, Controller, Livewire & Banner Drive Review SAQ** (Selesai - Commit `7cff513`)
  - Eliminasi 8 klausa `LIKE` di `NavigationService` dan `JSON_CONTAINS` di `DashboardController` & Livewire.
  - Implementasi penyimpanan evaluasi & jadwal di `WawancaraController` dan `VisitasiController`.
  - Implementasi banner Google Drive Review SAQ di bawah kartu grafik monitoring SAQ (`banner-drive-review.blade.php`), lengkap dengan hak akses (hanya untuk penilai & eksternal; disembunyikan dari operator & verifikator), form pengaturan interaktif, serta sinkronisasi dinamis ke `master_link`.
- [x] **Fase 5: Verifikasi Menyeluruh & Pembersihan Kolom JSON Lama** (Selesai)
  - Penyesuaian `PenilaianService` untuk perhitungan skor visitasi & interview berbasis data relasional `evaluators`.
  - Aksesor fallback otomatis pada `Submission`, `Interview`, dan `Visitasi` untuk menjaga kompatibilitas seluruh helper & view.
  - Penyesuaian `PertanyaanSeeder` dan `TransactionSeeder` agar kompatibel dengan kolom baru saat fresh seed.
  - Eksekusi migration `2026_10_15_000003_drop_legacy_json_columns` untuk menghapus kolom JSON lama (`submissions.evaluated_by`, `interview.interview_data`, `visitasi.visit_data`).
