# Project Rules & Workflow Guidelines - HaloKIP (emonev-refactor)

## 1. Fast Execution & Verification Rule
- **Perubahan Kecil/Minor**:
  - Untuk tugas seperti perbaikan UI/Blade, penyesuaian route, menyembunyikan/menampilkan menu atau tombol, edit teks, fix typo, atau penyesuaian logic sederhana:
    - **DILARANG** menjalankan pengetesan berulang di terminal (seperti perintah `php -r "require 'vendor/autoload.php'..."`, simulasi Auth manual, atau tes route di CLI).
    - Langsung ubah/edit file terkait dan segera laporkan hasilnya kepada user.
- **Pengujian Terminal**:
  - Hanya jalankan perintah pengetesan terminal jika:
    1. Diminta secara eksplisit oleh user.
    2. Perubahan melibatkan migrasi database kritis, query massal berisiko tinggi, atau refactor core framework.

## 2. Code Quality & Styling
- Pertahankan struktur blade component dan Alpine.js yang sudah ada.
- Gunakan eager loading untuk query relasi dan hindari N+1 query.
- Jangan menambahkan query database yang tidak perlu dan jaga performa aplikasi agar tetap ringan.
