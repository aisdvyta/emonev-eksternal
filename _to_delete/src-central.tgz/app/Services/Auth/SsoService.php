<?php

namespace App\Services\Auth;

use Illuminate\Support\Facades\Http;
use Exception;

class SsoService
{
    protected string $authServerUrl;
    protected string $realm;
    protected string $clientId;
    protected string $clientSecret;
    protected string $redirectUri;
    protected bool $verifySsl;
    protected string $baseRealmUrl;

    public function __construct()
    {
        $this->authServerUrl = rtrim(config('sso.auth_server_url', 'https://accounts.bps.go.id'), '/');
        $this->realm         = config('sso.realm', 'pegawai');
        $this->clientId      = config('sso.client_id', '');
        $this->clientSecret  = config('sso.client_secret', '');
        $this->redirectUri   = config('sso.redirect_uri', url('/auth/sso/callback'));
        $this->verifySsl     = filter_var(config('sso.verify_ssl', false), FILTER_VALIDATE_BOOLEAN);

        // OIDC Endpoint Keycloak 26 (tanpa /auth/)
        $this->baseRealmUrl  = "{$this->authServerUrl}/realms/{$this->realm}/protocol/openid-connect";
    }

    /**
     * Dapatkan URL Authorization untuk diarahkan ke login SSO BPS
     */
    public function getAuthorizationUrl(string $state): string
    {
        $params = [
            'response_type' => 'code',
            'client_id'     => $this->clientId,
            'redirect_uri'  => $this->redirectUri,
            'scope'         => 'openid profile email',
            'state'         => $state,
        ];

        return "{$this->baseRealmUrl}/auth?" . http_build_query($params);
    }

    /**
     * Tukarkan authorization code dengan access token dan id token
     */
    public function getAccessToken(string $code): array
    {
        $tokenUrl = "{$this->baseRealmUrl}/token";

        $http = Http::asForm();
        if (!$this->verifySsl) {
            $http = $http->withoutVerifying();
        }

        $response = $http->post($tokenUrl, [
            'grant_type'    => 'authorization_code',
            'client_id'     => $this->clientId,
            'client_secret' => $this->clientSecret,
            'code'          => $code,
            'redirect_uri'  => $this->redirectUri,
        ]);

        if (!$response->successful()) {
            $errMsg = $response->json('error_description') ?? ($response->json('error') ?? $response->body());
            throw new Exception("Gagal menukarkan token SSO: {$errMsg}");
        }

        return $response->json();
    }

    /**
     * Ambil data profil pegawai dari endpoint userinfo
     */
    public function getUserInfo(string $accessToken): array
    {
        $userinfoUrl = "{$this->baseRealmUrl}/userinfo";

        $http = Http::withToken($accessToken);
        if (!$this->verifySsl) {
            $http = $http->withoutVerifying();
        }

        $response = $http->get($userinfoUrl);

        if (!$response->successful()) {
            throw new Exception("Gagal mengambil data profil SSO: " . $response->body());
        }

        return $response->json();
    }

    /**
     * Ekstrak atribut spesifik pengguna BPS dari payload Keycloak (toleran format top-level maupun attributes array)
     */
    public function extractUserAttributes(array $ssoUser): array
    {
        $getAttr = function ($key, $default = null) use ($ssoUser) {
            if (isset($ssoUser[$key]) && !empty($ssoUser[$key])) {
                return is_array($ssoUser[$key]) ? $ssoUser[$key][0] : $ssoUser[$key];
            }
            if (isset($ssoUser['attributes'][$key]) && !empty($ssoUser['attributes'][$key])) {
                return is_array($ssoUser['attributes'][$key]) ? $ssoUser['attributes'][$key][0] : $ssoUser['attributes'][$key];
            }
            return $default;
        };

        return [
            'name'            => $getAttr('name') ?? ($getAttr('preferred_username') ?? ''),
            'email'           => $getAttr('email') ?? '',
            'nip_panjang'     => $getAttr('nip') ?? ($getAttr('nip_baru') ?? ($getAttr('nipbaru') ?? null)),
            'nip_pendek'      => $getAttr('nip-lama') ?? ($getAttr('nip_lama') ?? ($getAttr('niplama') ?? null)),
            'kode_organisasi' => $getAttr('organisasi') ?? ($getAttr('kode_organisasi') ?? null),
            'foto_url'        => $getAttr('foto') ?? ($getAttr('foto_url') ?? ($getAttr('picture') ?? null)),
        ];
    }

    /**
     * Dapatkan URL Logout Keycloak (RP-Initiated Logout OIDC)
     */
    public function getLogoutUrl(?string $idToken = null, ?string $redirectUri = null): string
    {
        $logoutEndpoint = "{$this->baseRealmUrl}/logout";
        $redirect       = $redirectUri ?? route('login');

        $params = [
            'post_logout_redirect_uri' => $redirect,
        ];

        if ($idToken) {
            $params['id_token_hint'] = $idToken;
        }

        return $logoutEndpoint . '?' . http_build_query($params);
    }

    // =========================================================================
    // FASE 6: REST API Data Pegawai BPS (Client Credentials Grant)
    // =========================================================================

    /**
     * Dapatkan Access Token via Client Credentials Grant (M2M / Backend-to-Backend)
     */
    public function getClientAccessToken(): string
    {
        return cache()->remember('sso_bps_client_token', 240, function () {
            $tokenUrl = "{$this->baseRealmUrl}/token";

            $http = Http::asForm();
            if (!$this->verifySsl) {
                $http = $http->withoutVerifying();
            }

            $response = $http->post($tokenUrl, [
                'grant_type'    => 'client_credentials',
                'client_id'     => $this->clientId,
                'client_secret' => $this->clientSecret,
            ]);

            if (!$response->successful()) {
                $errMsg = $response->json('error_description') ?? ($response->json('error') ?? $response->body());
                throw new Exception("Gagal mendapatkan client access token SSO: {$errMsg}");
            }

            return (string) $response->json('access_token');
        });
    }

    /**
     * Helper request generic ke REST API Pegawai BPS (/realms/{realm}/api/...)
     */
    public function callPegawaiApi(string $endpoint): array
    {
        $token = $this->getClientAccessToken();
        $apiUrl = "{$this->authServerUrl}/realms/{$this->realm}/api/" . ltrim($endpoint, '/');

        $http = Http::withToken($token);
        if (!$this->verifySsl) {
            $http = $http->withoutVerifying();
        }

        $response = $http->get($apiUrl);

        if (!$response->successful()) {
            throw new Exception("Gagal mengambil data dari API Pegawai [{$endpoint}]: " . $response->body());
        }

        return $response->json() ?? [];
    }

    /**
     * Cari data pegawai berdasarkan NIP Baru (18 digit) atau NIP Lama (9 digit)
     */
    public function getPegawaiByNip(string $nip): array
    {
        $nipClean = trim($nip);
        $endpoint = strlen($nipClean) === 18 ? "nipbaru/{$nipClean}" : "nip/{$nipClean}";
        return $this->callPegawaiApi($endpoint);
    }

    /**
     * Cari data pegawai berdasarkan Email BPS
     */
    public function getPegawaiByEmail(string $email): array
    {
        return $this->callPegawaiApi("email/" . trim($email));
    }

    /**
     * Cari data pegawai berdasarkan Username SSO BPS
     */
    public function getPegawaiByUsername(string $username): array
    {
        return $this->callPegawaiApi("username/" . trim($username));
    }

    /**
     * Cari data pegawai berdasarkan Kode Unit / Satker BPS
     */
    public function getPegawaiByUnit(string $kodeUnit): array
    {
        return $this->callPegawaiApi("unit/" . trim($kodeUnit));
    }
}
