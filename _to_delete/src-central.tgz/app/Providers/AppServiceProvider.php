<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Blade;

use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Route;
use Illuminate\Cache\RateLimiting\Limit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\RateLimiter;
use App\Models\Submission;
use App\Policies\SubmissionPolicy;
use App\Helpers\SecureId;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        RateLimiter::for('login', function (Request $request) {
            return Limit::perMinute(5)->by($request->input('nama_user') . $request->ip());
        });

        Gate::policy(Submission::class, SubmissionPolicy::class);
        Carbon::setLocale('id');

        // Pastikan storage/clockwork writable di local (Windows read-only attribute fix)
        if ($this->app->isLocal()) {
            $clockworkPath = storage_path('clockwork');
            if (!is_dir($clockworkPath)) {
                mkdir($clockworkPath, 0755, true);
            }
            // Hapus read-only attribute di Windows jika folder tidak writable
            if (PHP_OS_FAMILY === 'Windows' && !is_writable($clockworkPath)) {
                exec('attrib -R ' . escapeshellarg($clockworkPath) . ' /S /D');
            }
        }

        // Register views/layouts/app.blade.php sebagai <x-layouts.app>
        Blade::component('layouts.app', 'layouts.app');

        // Eager-load masterSatker untuk auth user agar blade tidak lazy-load per-akses
        \Illuminate\Support\Facades\Event::listen(
            \Illuminate\Auth\Events\Authenticated::class,
            function ($event) {
                if ($event->user && !$event->user->relationLoaded('masterSatker')) {
                    $event->user->load('masterSatker');
                }
            }
        );

        Route::bind('id_periode', function ($value) {
            if (is_numeric($value)) {
                return (int) $value;
            }
            return (int) SecureId::decrypt($value);
        });
    }
}
