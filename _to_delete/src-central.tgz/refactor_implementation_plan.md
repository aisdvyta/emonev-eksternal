# Implementation Plan: Refactoring Arsitektur HaloKIP (Feature & Domain-Driven)

Dokumen ini berisi rencana implementasi komprehensif untuk merestrukturisasi Frontend (Blade/Tailwind/Alpine) dan Backend (Laravel Controllers/Routes) sistem **HaloKIP** dari pola lama (*Role-Oriented Anti-Pattern*) menjadi pola modern (*Feature/Domain-Driven Architecture*).

---

## 1. Latar Belakang & Tujuan Refactoring

### Masalah Saat Ini (Role-Oriented)
1. **Frontend**:
   - Terdapat **7 file sidebar** (`sidebar-admin`, `sidebar-evaluator`, `sidebar-kabag`, `sidebar-operator`, `sidebar-penilai-eksternal`, `sidebar-super-evaluator`, `sidebar-verifikator`) dan **5 file bottom navigation**.
   - Folder view dipecah berdasarkan role (`admin/`, `evaluator-provinsi/`, `operator/`, `verifikator/`, dll.), menghasilkan duplikasi 99% pada halaman seperti Wawancara, Visitasi, Penilaian Akhir, dan SK/Sertifikat.
2. **Backend**:
   - Memiliki **32 file controller** di mana controller seperti `ResultController`, `SkSertifikatController`, `VisitasiController`, `WawancaraController`, dan `SAQController` dibuat berulang kali untuk tiap folder role.
   - `routes/web.php` sangat panjang (>200 baris) dengan pengulangan rute yang hampir identik antar role.

### Target Setelah Refactoring
- **Single Source of Truth**: 1 file Sidebar dinamis dan 1 file Bottom Nav dinamis untuk seluruh role.
- **Konsolidasi Controller**: Dari 32 controller dipangkas menjadi **10 controller berbasis domain**.
- **Penyatuan Halaman Bersama**:
  - Halaman Master Data terpusat di `pages/master/`.
  - Halaman Wawancara, Visitasi, Penilaian, dan Sertifikat untuk Satker Kab/Kota disatukan (Operator & Verifikator menggunakan view yang sama).
  - Halaman Evaluasi Provinsi disatukan (Evaluator & Super Evaluator menggunakan view yang sama).
- **Zero Breaking Changes**: Migrasi dilakukan bertahap (incremental) sehingga aplikasi tetap berjalan normal di setiap tahapan.

---

## 2. Target Arsitektur Baru

### A. Struktur Frontend (`resources/views/`)
```text
resources/views/
├── components/                  # Atomic & Reusable UI Components
│   ├── card-stat.blade.php
│   ├── modal-form.blade.php
│   ├── monitoring-table.blade.php
│   ├── page-header.blade.php
│   ├── sidebar-link.blade.php
│   └── ...
│
├── layouts/                     # Master Layouts
│   ├── app.blade.php            # Main Application Shell
│   ├── sidebar.blade.php        # [BARU] 1 Dynamic Sidebar untuk semua role
│   ├── bottom-nav.blade.php     # [BARU] 1 Dynamic Mobile Bottom Navigation
│   └── header.blade.php         # Topbar & User Profile
│
└── pages/                       # View Berbasis Objek / Domain Fitur
    ├── dashboard/               # Beranda Universal (Widget dinamis per role)
    │   └── index.blade.php
    │
    ├── master/                  # Manajemen Pengaturan & Master Data
    │   ├── periode.blade.php
    │   ├── indikator.blade.php
    │   ├── sub-indikator.blade.php
    │   ├── kuesioner.blade.php
    │   └── pembobotan.blade.php
    │
    ├── evaluasi/                # Core Modul Kegiatan Evaluasi
    │   ├── saq/
    │   │   ├── pengisian.blade.php  # Pengisian Kuesioner (Operator)
    │   │   ├── verifikasi.blade.php # Verifikasi Kuesioner (Kasubag)
    │   │   ├── review.blade.php     # Penilaian SAQ (Evaluator Provinsi)
    │   │   └── monitor.blade.php    # Monitoring SAQ
    │   ├── visitasi/
    │   │   ├── detail.blade.php     # Jadwal & Unggah Bukti (Satker Kab/Kota)
    │   │   ├── review.blade.php     # Penilaian Lapangan (Evaluator)
    │   │   └── monitor.blade.php    # Monitoring Visitasi
    │   ├── wawancara/
    │   │   ├── detail.blade.php     # Jadwal Wawancara (Satker Kab/Kota)
    │   │   ├── review.blade.php     # Penilaian (Evaluator & Penilai Eksternal)
    │   │   └── monitor.blade.php    # Monitoring Wawancara
    │   └── penilaian/
    │       ├── index.blade.php      # Hasil Akhir & Tabulasi (Semua Role)
    │       └── monitor.blade.php    # Monitoring Kelulusan & Nilai
    │
    ├── dokumen/                 # Modul Dokumen
    │   ├── sk-sertifikat.blade.php  # Kelola, Unduh SK & Sertifikat
    │   └── panduan.blade.php        # Link Buku Panduan
    │
    └── user/                    # Modul Pengguna
        └── index.blade.php          # CRUD & Import User (Admin & Super Evaluator)
```

---

### B. Struktur Backend (`app/Http/Controllers/`)
```text
app/Http/Controllers/
├── Auth/
│   ├── LoginController.php
│   └── SsoController.php
│
├── DashboardController.php          # [BARU] Menangani beranda seluruh role
│
├── Evaluasi/                        # [BARU] Domain Kegiatan Evaluasi
│   ├── SaqController.php            # Form input, draft, verifikasi, scoring, export
│   ├── VisitasiController.php       # Jadwal visitasi, upload bukti, review nilai
│   ├── WawancaraController.php      # Jadwal wawancara, scoring evaluator/eksternal
│   └── PenilaianController.php      # Rekap nilai, tabulasi, publish, export excel
│
├── Master/                          # [BARU] Domain Master Data & Konfigurasi
│   ├── PeriodeController.php        # Manajemen periode & jadwal tahapan
│   ├── IndikatorController.php      # Master indikator & sub-indikator
│   ├── KuesionerController.php      # Bank pertanyaan, bobot, import excel
│   └── PembobotanController.php     # Bobot SAQ, Visitasi, Wawancara
│
├── Dokumen/
│   └── SkSertifikatController.php   # [BARU] Upload SK, generate sertifikat, download
│
└── User/
    └── UserController.php           # CRUD user, import user Excel
```

---

## 3. Desain Konfigurasi Navigasi Terpusat (`config/menu.php`)

Untuk menggantikan 7 sidebar dan 5 bottom nav terpisah, dibuat sebuah struktur menu terkonfigurasi. 

```php
return [
    [
        'label' => 'Beranda',
        'icon'  => 'home',
        'route' => 'dashboard',
        'active_pattern' => 'dashboard*',
        'roles' => ['*'],
        'bottom_nav' => true,
    ],
    [
        'label' => 'Kegiatan Evaluasi',
        'icon'  => 'clipboard-list',
        'roles' => ['operator', 'evaluator', 'super_evaluator', 'verifikator', 'penilai_eksternal'],
        'children' => [
            [
                'label'   => 'Kuesioner SAQ',
                'route'   => 'evaluasi.saq.index',
                'pattern' => 'evaluasi/saq*',
                'roles'   => ['operator', 'evaluator', 'super_evaluator', 'verifikator'],
            ],
            [
                'label'   => 'Visitasi & Verif. Faktual',
                'route'   => 'evaluasi.visitasi.index',
                'pattern' => 'evaluasi/visitasi*',
                'roles'   => ['operator', 'evaluator', 'super_evaluator', 'verifikator'],
            ],
            [
                'label'   => 'Wawancara',
                'route'   => 'evaluasi.wawancara.index',
                'pattern' => 'evaluasi/wawancara*',
                'roles'   => ['operator', 'evaluator', 'super_evaluator', 'penilai_eksternal'],
            ],
            [
                'label'   => 'Penilaian Akhir',
                'route'   => 'evaluasi.penilaian.index',
                'pattern' => 'evaluasi/penilaian*',
                'roles'   => ['*'],
            ],
        ],
    ],
    [
        'label' => 'Master Data',
        'icon'  => 'database',
        'roles' => ['evaluator', 'super_evaluator'],
        'children' => [
            ['label' => 'Master Pembobotan', 'route' => 'master.pembobotan.index', 'pattern' => 'master/pembobotan*'],
            ['label' => 'Master Indikator', 'route' => 'master.indikator.index', 'pattern' => 'master/indikator*'],
            ['label' => 'Master Pertanyaan', 'route' => 'master.kuesioner.index', 'pattern' => 'master/kuesioner*'],
            ['label' => 'Master Periode & Jadwal', 'route' => 'master.periode.index', 'pattern' => 'master/periode*'],
        ],
    ],
    [
        'label' => 'SK & Sertifikat',
        'icon'  => 'document',
        'route' => 'dokumen.sk-sertifikat',
        'pattern' => 'dokumen/sk-sertifikat*',
        'roles' => ['operator', 'evaluator', 'super_evaluator', 'verifikator'],
        'bottom_nav' => true,
    ],
    [
        'label' => 'Manajemen User',
        'icon'  => 'users',
        'route' => 'users.index',
        'pattern' => 'users*',
        'roles' => ['admin', 'super_evaluator'],
    ],
    [
        'label' => 'Buku Panduan',
        'icon'  => 'book-open',
        'route' => 'dokumen.panduan',
        'pattern' => 'dokumen/panduan*',
        'roles' => ['*'],
        'external' => true,
    ],
];
```

---

## 4. Tahapan Eksekusi Bertahap (Roadmap)

```mermaid
graph TD
    Step1[Fase 1: Unifikasi Navigasi FE] --> Step2[Fase 2: Satukan Domain Master Data & Users]
    Step2 --> Step3[Fase 3: Satukan Domain Dokumen SK & Sertifikat]
    Step3 --> Step4[Fase 4: Satukan Domain Evaluasi SAQ, Visitasi, Wawancara, Nilai]
    Step4 --> Step5[Fase 5: Dashboard Tunggal & Cleanup Routes]
```

### Fase 1: Unifikasi Navigasi (Sidebar & Bottom Nav) — Quick Win
- [x] Buat file konfigurasi navigasi `config/menu.php` dan `App\Services\NavigationService`.
- [x] Buat `resources/views/layouts/sidebar.blade.php` dinamis yang merender menu sesuai role user login.
- [x] Buat `resources/views/layouts/bottom-nav.blade.php` dinamis yang memfilter menu bertanda `bottom_nav => true`.
- [x] Update [resources/views/layouts/app.blade.php](file:///d:/file%20Aisyah/KERJAA%20BPS/01.%20IPDS/02.%20Proyek%20Emonev/00.%20emonev-kip-refactor/emonev-refactor/resources/views/layouts/app.blade.php) untuk menggunakan sidebar dan bottom nav baru.
- [x] Hapus 7 file sidebar lama (`sidebar-*.blade.php`) dan 5 file bottom nav lama (`bottomnav-*.blade.php`).
- [x] **Verifikasi**: Uji render view dan struktur navigasi untuk semua role (Operator, Evaluator, Super Evaluator, Verifikator, Penilai Eksternal, Admin).

### Fase 2: Satukan Domain Master Data & User Management
- [x] Buat folder `resources/views/pages/master/` dan satukan seluruh view master & user (`periode.blade.php`, `indikator.blade.php`, `sub-indikator.blade.php`, `kuesioner.blade.php`, `pembobotan.blade.php`, dan `user.blade.php`).
- [x] Konsolidasikan controller master dan user ke namespace `App\Http\Controllers\Master\` (`PeriodeController`, `IndikatorController`, `SubIndikatorController`, `KuesionerController`, `PembobotanController`, dan `UserController`).
- [x] Rapikan route prefix `/master` dan `/users` di `routes/web.php` dengan middleware `role:super_evaluator|evaluator|admin` serta mempertahankan backwards compatibility untuk legacy routes.
- [x] Hubungkan `NavigationService` (Sidebar & Bottom Nav) ke `/users` dan `/master/*`.
- [x] **Verifikasi**: Buka CRUD Periode, Indikator, Kuesioner, Bobot, dan User Management. Pastikan validasi route, syntax Blade template, dan controller binding berhasil (semua route dan cache teruji).

### Fase 3: Satukan Domain Dokumen (SK & Sertifikat)
- [x] Satukan dan sentralisasi view ke `resources/views/pages/dokumen/` (`sk-sertifikat.blade.php`, `manage-sk.blade.php`, `manage-panduan.blade.php`).
- [x] Satukan controller dokumen ke satu controller: `App\Http\Controllers\Dokumen\SkSertifikatController`.
- [x] Atur otorisasi: Evaluator/Super Evaluator dapat upload SK & kelola template/panduan, Operator/Verifikator hanya melihat dan mengunduh berkas miliknya.
- [x] Hapus controller lama (`Operator\SkSertifikatController`, `Verifikator\SkSertifikatController`, `Evaluator\SkSertifikatController`) dan view lama yang duplikat.
- [x] Hubungkan `NavigationService` (Sidebar & Bottom Nav) ke `/dokumen/*` dengan tetap mempertahankan backwards compatibility untuk route alias lama.
- [x] **Verifikasi**: Uji register route, binding controller, cache view Blade, dan akses file download teruji bersih tanpa error.

### Fase 4: Satukan Domain Kegiatan Evaluasi (SAQ, Visitasi, Wawancara, Penilaian)
- [x] **Wawancara**: Satukan `operator/wawancara.blade.php` dan `verifikator/wawancara.blade.php` menjadi `pages/evaluasi/wawancara/detail.blade.php`. Satukan `WawancaraController`.
- [x] **Visitasi**: Satukan `operator/visitasi.blade.php` dan `verifikator/visitasi.blade.php` menjadi `pages/evaluasi/visitasi/detail.blade.php`. Satukan `VisitasiController`.
- [x] **Penilaian Akhir**: Satukan `penilaian.blade.php` dari 4 role menjadi `pages/evaluasi/penilaian/monitoring.blade.php` dan `detail.blade.php`. Satukan `PenilaianController`.
- [x] **SAQ**: Rapikan form pengisian operator, verifikasi kasubag, dan review evaluator di bawah `pages/evaluasi/saq/`. Satukan `SaqController`.
- [x] **Verifikasi**: Jalankan pengujian alur evaluasi dari input SAQ $\rightarrow$ verifikasi $\rightarrow$ jadwal visitasi/wawancara $\rightarrow$ rekapitulasi nilai akhir. Blade templates cached 100% dan Unit tests lolos.

### Fase 5: Dashboard Tunggal & Cleanup Routes
- [x] Buat `App\Http\Controllers\DashboardController` dengan satu method `index()`.
- [x] Buat `pages/dashboard/index.blade.php` yang memanggil partial widget sesuai context role (`partials/admin.blade.php`, `partials/evaluator.blade.php`, `partials/operator.blade.php`, `partials/verifikator.blade.php`, `partials/penilai-eksternal.blade.php`).
- [x] Hapus controller lama (`AdminController`, `OperatorController`, `EvaluatorController`, `VerifikatorController`, `SuperEvaluatorController`, `PenilaiEksternalController`).
- [x] Hapus folder role yang sudah kosong di `resources/views/` (`operator/`, `verifikator/`, `evaluator-provinsi/`, `super-evaluator/`, `admin/`, `penilai-eksternal/`).
- [x] Sederhanakan [routes/web.php](file:///d:/file%20Aisyah/KERJAA%20BPS/01.%20IPDS/02.%20Proyek%20Emonev/00.%20emonev-kip-refactor/emonev-refactor/routes/web.php) secara total dengan tetap mempertahankan legacy route alias untuk zero breaking change.
- [x] **Verifikasi**: Route list 225 routes resolved bersih, Blade templates compile cache 100% lolos, dan Unit tests lolos 100%.

---

## 5. Status Akhir Refactoring

Seluruh tahapan (Fase 1 sampai Fase 5) dari rencana refactoring arsitektur Emonev KIP telah **selesai 100% dieksekusi**:
1. **Fase 1: Unifikasi Navigasi FE** (Sidebar dinamis, Bottom Nav dinamis, NavigationService).
2. **Fase 2: Domain Master Data & User Management** (`Master/` controllers & views).
3. **Fase 3: Domain Dokumen SK & Sertifikat** (`Dokumen/` controller & views).
4. **Fase 4: Domain Kegiatan Evaluasi** (SAQ, Visitasi, Wawancara, Penilaian Akhir disatukan).
5. **Fase 5: Dashboard Tunggal & Cleanup** (`DashboardController`, `pages/dashboard/`, penghapusan seluruh controller dan view berbasis role lama).
