# 📖 Rencana Implementasi: Migrasi ke SSO BPS Baru (Keycloak 26.7.0)

Dokumen ini berisi panduan teknis, daftar prasyarat administratif yang harus disiapkan oleh pengembang/user, serta peta jalan (*roadmap*) langkah-langkah implementasi kodingan untuk memigrasikan autentikasi **HaloKIP** ke **SSO BPS Baru (Keycloak 26.7.0)** berbasis standar OpenID Connect (OIDC).

---

## 📌 1. Hal yang Harus Anda Lakukan / Siapkan (Prasyarat Administratif)

Sebelum kodingan baru dapat diuji secara *live*, ada beberapa hal yang perlu dipersiapkan dari sisi tim pengelola SSO BPS (Direktorat SIS / Pengelola SSO BPS Pusat):

### A. Pengajuan / Pengecekan Kredensial Client OAuth2 Baru
Server SSO BPS baru menggunakan arsitektur berbeda:
- **Server URL Baru**: `https://accounts.bps.go.id`
- **Realm Baru**: `pegawai` *(bukan `pegawai-bps` lagi)*

> [!IMPORTANT]
> **Tindakan Anda**:
> 1. Pastikan apakah kredensial Client ID & Client Secret lama (`13500-halokip-bb6`) sudah dimigrasikan ke Keycloak baru (`accounts.bps.go.id`), ATAU Anda perlu mengajukan **Client ID & Client Secret baru** melalui tiket/formulir layanan SSO BPS.
> 2. Pastikan **Valid Redirect URIs** yang terdaftar di Keycloak BPS mencakup URL development lokal dan server produksi Anda:
>    - **Lokal**: `http://localhost:8000/auth/sso/callback` (dan `http://127.0.0.1:8000/auth/sso/callback`)
>    - **Produksi**: `https://[domain-halokip]/auth/sso/callback`
> 3. Pastikan **Post Logout Redirect URIs** di Keycloak BPS didaftarkan:
>    - `http://localhost:8000` (atau `http://localhost:8000/`)

### B. Menyiapkan Konfigurasi `.env`
Setelah kredensial tersedia, variabel lingkungan di `.env` disesuaikan menjadi:

```env
# =============================================================================
# SSO BPS Keycloak 26 Configuration
# =============================================================================
SSO_BPS_AUTH_SERVER_URL=https://accounts.bps.go.id
SSO_BPS_REALM=pegawai
SSO_BPS_CLIENT_ID=client_id_anda
SSO_BPS_CLIENT_SECRET=client_secret_anda
SSO_BPS_REDIRECT_URI="${APP_URL}/auth/sso/callback"
SSO_BPS_VERIFY_SSL=false
```

---

## 🚀 2. Mengapa Perlu Refactor Kodingan ke Standar OIDC Murni?

Saat ini HaloKIP menggunakan package pihak ketiga `irsadarief/jkd-sso`. Di dalam library tersebut, path URL login dan token di-*hardcode* menggunakan format Keycloak lama:
```
{authServerUrl}/auth/realms/{realm}/...
```
Pada **Keycloak 26.7.0**, prefix `/auth/` **sudah dihapus total**. Pemanggilan URL dengan prefix `/auth/` ke `https://accounts.bps.go.id` akan menghasilkan **404 Not Found**.

### Solusi Modern:
Kita **melepas ketergantungan pada library pihak ketiga** dan beralih menggunakan **OIDC Standar** berbasis HTTP Client bawaan Laravel (`Illuminate\Support\Facades\Http` / `GuzzleHttp`), persis seperti pola resmi yang ada di folder referensi `sso-example-main`.

---

## 🗺️ 3. Tahapan Implementasi Kodingan (Technical Roadmap)

```mermaid
flowchart TD
    A[Fase 1: Update config/sso.php & .env] --> B[Fase 2: Refactor SsoService.php ke OIDC Standar]
    B --> C[Fase 3: Penyesuaian SsoController.php]
    C --> D[Fase 4: Penanganan ID Token & Logout di LoginController.php]
    D --> E[Fase 5: Pengujian End-to-End]
    E --> F[Fase 6 Opsi Tambahan: Integrasi REST API Pegawai]
```

---

### Fase 1: Pembaruan Konfigurasi (`config/sso.php`)
Menyesuaikan *default value* di [`config/sso.php`](file:///d:/Aisyah%20Kerja/01.%20IPDS/02.%20Proyek%20Emonev/emonev-refactor/config/sso.php):
- Default URL: `https://accounts.bps.go.id`
- Default Realm: `pegawai`
- Dynamic Base Endpoint: `rtrim($url, '/') . '/realms/' . $realm . '/protocol/openid-connect'`

---

### Fase 2: Transformasi [`SsoService.php`](file:///d:/Aisyah%20Kerja/01.%20IPDS/02.%20Proyek%20Emonev/emonev-refactor/app/Services/Auth/SsoService.php) ke Native OIDC
Mengubah `SsoService` agar menyediakan endpoint-endpoint standar tanpa `irsadarief/jkd-sso`:

1. **`getAuthorizationUrl(string $state): string`**
   - Menghasilkan URL redirect login ke `/protocol/openid-connect/auth`.
   - Parameter: `client_id`, `redirect_uri`, `response_type=code`, `scope=openid profile email`, `state`.
2. **`getAccessToken(string $code): array`**
   - Melakukan POST request ke `/protocol/openid-connect/token`.
   - Mengambil `access_token`, `id_token`, dan `refresh_token`.
3. **`getUserInfo(string $accessToken): array`**
   - Melakukan GET request ke `/protocol/openid-connect/userinfo` dengan Bearer Token.
   - Mengembalikan data pengguna: nama, email, username, NIP, satker.
4. **`getLogoutUrl(?string $idToken = null): string`**
   - Menghasilkan URL logout ke `/protocol/openid-connect/logout`.
   - Menyertakan parameter `post_logout_redirect_uri` dan `id_token_hint` (agar tidak muncul prompt konfirmasi manual).

---

### Fase 3: Penyesuaian [`SsoController.php`](file:///d:/Aisyah%20Kerja/01.%20IPDS/02.%20Proyek%20Emonev/emonev-refactor/app/Http/Controllers/Auth/SsoController.php)

1. **Inisiasi Login (`redirectToSso`)**:
   - Generate acak `state` (32 karakter) untuk CSRF protection.
   - Simpan `state` di session `oauth2state`.
   - Redirect ke URL yang dihasilkan `SsoService::getAuthorizationUrl($state)`.
2. **Callback Handler (`handleSsoCallback`)**:
   - Validasi parameter `state` dari request dengan session.
   - Tukar `code` dengan token via `SsoService::getAccessToken($code)`.
   - Simpan `id_token` ke session: `$request->session()->put('sso_id_token', $tokenData['id_token'])`.
   - Ambil profil user via `SsoService::getUserInfo($tokenData['access_token'])`.
   - Sinkronisasi atribut pegawai ke model [`User`](file:///d:/Aisyah%20Kerja/01.%20IPDS/02.%20Proyek%20Emonev/emonev-refactor/app/Models/User.php) (email, NIP, kode satker, foto).
   - Login user ke session Laravel (`Auth::login($user, true)`).
   - Set flag `$request->session()->put('is_sso', true)`.

---

### Fase 4: Penanganan Logout Terpusat (Single Sign-Out)
Di [`LoginController.php`](file:///d:/Aisyah%20Kerja/01.%20IPDS/02.%20Proyek%20Emonev/emonev-refactor/app/Http/Controllers/Auth/LoginController.php#L72):
- Saat user logout dan `session('is_sso')` bernilai `true`:
  - Ambil `id_token` dari session sebelum invalidate:
    ```php
    $idToken = $request->session()->get('sso_id_token');
    ```
  - Redirect ke `$ssoService->getLogoutUrl($idToken)` sehingga sesi SSO di Keycloak BPS otomatis bersih tanpa error atau prompt konfirmasi.

---

### Fase 6: Penambahan Service REST API Data Pegawai (Selesai Diimplementasikan)
Berdasarkan contoh `sso-example-main/php/api_pegawai.php`:
- **`getClientAccessToken()`**: Mendapatkan M2M access token dengan caching otomatis via `grant_type=client_credentials`.
- **`getPegawaiByNip($nip)`**: Mencari data pegawai via endpoint `/api/nipbaru/{nip}` atau `/api/nip/{nip}`.
- **`getPegawaiByEmail($email)`**: Mencari data pegawai via endpoint `/api/email/{email}`.
- **`getPegawaiByUsername($username)`**: Mencari data pegawai via endpoint `/api/username/{username}`.
- **`getPegawaiByUnit($kodeUnit)`**: Mencari data pegawai via endpoint `/api/unit/{kodeunitorganisasi}`.
- **Endpoint Internal HaloKIP**: `GET /users/search-pegawai?query={nip/email/username}` pada [`UserController::searchPegawai`](file:///d:/Work/A/emonev-refactor/app/Http/Controllers/Master/UserController.php).
- **Manfaat**: Admin/Super Evaluator dapat mencari dan memvalidasi detail data pegawai BPS secara otomatis saat menambah evaluator/operator cukup dengan mengetikkan NIP 18 digit atau email!

---

## 🧪 4. Matriks Pengujian (Testing Checklist)

| No | Kasus Uji | Ekspektasi Hasil |
| :---: | :--- | :--- |
| 1 | Klik tombol *"Badan Pusat Statistik"* di halaman login | Ter-redirect mulus ke halaman login Keycloak 26 (`accounts.bps.go.id`). URL tidak mengandung `/auth/`. |
| 2 | Login dengan akun SSO BPS yang belum terdaftar di tabel `users` | Ditolak kembali ke form login dengan pesan ramah: *"Akun Anda belum terdaftar di sistem eMonev KIP. Silakan hubungi Administrator."* |
| 3 | Login dengan akun SSO BPS yang sudah terdaftar | Berhasil login, data NIP/foto profil ter-update otomatis, dan diarahkan ke dashboard sesuai role masing-masing. |
| 4 | Klik tombol Logout dari navbar HaloKIP | Sesi Laravel terhapus, browser di-redirect ke Keycloak logout, dan kembali ke halaman login HaloKIP secara bersih (Single Logout). |
| 5 | Login pengguna Eksternal (Non-BPS) | Form username & password manual tetap berjalan normal tanpa terganggu perubahan SSO BPS. |

---

## 📋 5. Langkah Anda Selanjutnya
1. Pastikan Anda memiliki kredensial (`CLIENT_ID` dan `CLIENT_SECRET`) untuk server `https://accounts.bps.go.id` (realm `pegawai`).
2. Masukkan kredensial tersebut ke file [`.env`](file:///d:/Aisyah%20Kerja/01.%20IPDS/02.%20Proyek%20Emonev/emonev-refactor/.env).
3. Konfirmasikan kepada saya jika Anda sudah siap untuk mulai mengeksekusi Fase 1 & 2 di branch `feature/sso-baru` ini!
