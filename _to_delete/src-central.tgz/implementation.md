# Rencana Implementasi: Fitur Review SAQ & Pemindahan Google Drive Review SAQ

Dokumen ini menjelaskan spesifikasi arsitektur dan langkah implementasi fitur **Review SAQ**, penyesuaian visualisasi peta status kelulusan (Lolos/Gugur), penambahan filter tahun, serta relokasi **Google Drive Review SAQ** dari halaman Penilaian Akhir ke modul Kuesioner SAQ.

---

## 1. Analisis Kebutuhan & Ruang Lingkup Baru

### A. Fitur Review SAQ
Menyediakan antarmuka visualisasi rekapitulasi evaluasi SAQ (Self-Assessment Questionnaire) seluruh Kabupaten/Kota di Jawa Timur:

1. **Histogram Skor SAQ per Indikator**:
   - Visualisasi nilai/persentase SAQ per indikator berdasarkan Kabupaten/Kota yang dipilih.
   - Dropdown pencarian & pemilihan Kab/Kota.
   - Tombol "Salin Gambar" (ekspor kartu chart ke clipboard/gambar).
   - Legend predikat standar indikator.

2. **Peta Sebaran Lolos/Gugur SAQ (Mapchart Jawa Timur)**:
   - Visualisasi kelulusan SAQ Kab/Kota se-Jawa Timur berbasis KKM SAQ:
     - 🟢 **Hijau (`#388E3C` / `var(--color-hijau)`)**: **Lolos** (Nilai SAQ ≥ 80).
     - 🔴 **Merah2 (`#E82D1F` / `var(--color-merah2)`)**: **Gugur** (Nilai SAQ < 80 atau `submission.status = 8`).
     - ⚪ **Abumuda (`#D1D5D8` / `var(--color-abumuda)`)**: **Belum Dinilai** / Belum Selesai Evaluasi.
   - Interaktivitas:
     - Hover/Klik menampilkan popup informasi: Nama Kab/Kota, Nilai SAQ, dan Status (*Lolos* / *Gugur* / *Belum Dinilai*).
     - Legend peta disesuaikan: Hanya menampilkan status **Lolos (Hijau)** dan **Gugur (Merah2)**.
     - Tombol "Salin Gambar" untuk menyalin kartu peta.

3. **Filter Tahun / Periode**:
   - Disediakan filter tahun di bagian atas Tab 2 (Review SAQ) dan halaman role eksternal.
   - Pengguna dapat beralih tahun untuk meninjau data evaluasi SAQ tahun berjalan maupun tahun-tahun sebelumnya secara reaktif.

4. **Banner Google Drive Review SAQ**:
   - Dipindahkan dari halaman *Penilaian Akhir* ke bagian bawah tampilan Review SAQ ini.
   - **Evaluator & Super Evaluator**: Menampilkan tautan dan tombol/form **"Atur/Ubah Tautan"** yang menyimpan perubahan ke database `master_link.link_drive_review_saq` sesuai tahun/periode yang dipilih.
   - **Penilai Eksternal**: Hanya melihat tautan dan tombol **"Buka Folder Google Drive"** (*view-only*, tanpa opsi edit).

---

### B. Aturan Tampilan & Hak Akses per Role

| Role | Menu Sidebar | Tampilan Halaman & Fungsionalitas |
| :--- | :--- | :--- |
| **Penilai Eksternal** (`penilai_eksternal`) | Menu: **"Kuesioner SAQ"** di bawah *Monitoring Kegiatan* (selalu tampil) | **1 Halaman Khusus**:<br>• Hanya memuat tampilan **Tab 2 (Review SAQ)**.<br>• Dilengkapi **Filter Tahun**.<br>• Histogram Indikator + Peta Sebaran Lolos/Gugur.<br>• Banner Google Drive Review SAQ bersifat **view-only** (hanya buka folder). |
| **Evaluator** & **Super Evaluator** (`evaluator`, `super_evaluator`) | Menu: **"Kuesioner SAQ"** di bawah *Monitoring Kegiatan* | **1 Halaman Terpadu dengan 2 Tab** (gaya tab identik halaman Visitasi/Wawancara):<br>• **Tab 1: "Kuesioner SAQ"** (Tabel Monitoring SAQ & Modal Atur Evaluator).<br>• **Tab 2: "Review SAQ"** (Histogram, Peta Sebaran Lolos/Gugur, **Filter Tahun**, serta **Form input/ubah tautan Drive Review**). |
| **Operator** & **Verifikator** (`operator`, `verifikator`) | Tetap (sesuai eksisting) | **Tidak ada perubahan** (halaman kuesioner SAQ tidak ditambahkan tab/tampilan review). |
| **Halaman Penilaian Akhir** | Menu Penilaian Akhir | Banner Google Drive Review SAQ **dihapus** dari halaman ini. |

---

## 2. Rencana Arsitektur & Struktur File

```
├── app/
│   ├── Http/Controllers/Evaluasi/
│   │   └── SaqController.php                # Penyesuaian routing role penilai_eksternal vs evaluator
│   ├── Livewire/Evaluasi/
│   │   └── SaqReviewSection.php             # [BARU] Livewire Component: State filter tahun, data chart, peta lolos/gugur, & form drive
│   └── Services/
│       └── NavigationService.php            # Menu "Kuesioner SAQ" dipastikan selalu muncul di penilai_eksternal
├── resources/views/
│   ├── livewire/evaluasi/
│   │   ├── saq-review-section.blade.php     # [BARU] Template Blade Tab 2: Filter Tahun, Histogram, Peta Lolos/Gugur, Banner Drive
│   │   └── partials/
│   │       └── charts-section.blade.php     # Hapus @include banner-drive-review di Penilaian Akhir
│   └── pages/evaluasi/saq/
│       ├── monitoring.blade.php             # Tambah 2 Tab ("Kuesioner SAQ" & "Review SAQ") untuk Evaluator & Super Evaluator
│       └── review-eksternal.blade.php       # [BARU] Halaman khusus penilai eksternal (langsung render SaqReviewSection)
```

---

## 3. Rincian Teknis Implementasi

### Langkah 1: Komponen Livewire `SaqReviewSection`
- **File**: `app/Livewire/Evaluasi/SaqReviewSection.php` & `resources/views/livewire/evaluasi/saq-review-section.blade.php`.
- **Properties & State**:
  - `selectedTahun`: Tahun periode yang aktif/dipilih (default tahun periode aktif).
  - `availableYears`: Daftar tahun periode yang tersedia di database.
  - `periodeId`: ID periode yang bersesuaian dengan `selectedTahun`.
  - `chartKabkotKode`: Kode satker terpilih untuk histogram skor per indikator.
  - `driveReviewLink`: Tautan Google Drive Review SAQ untuk periode terpilih.
  - `isEditingDrive`: State toggle form input link drive untuk Super/Evaluator.
- **Logika Penentuan Status Lolos/Gugur Peta**:
  - Mengambil data nilai SAQ (`ques_score`) dari tabel `result` / `submission` pada periode terpilih:
    ```php
    // Threshold KKM SAQ = 80
    if ($status === 8 || ($score > 0 && $score < 80)) {
        $statusLabel = 'Gugur';
        $color = '#EA580C'; // Merah-Orange
    } elseif ($score >= 80) {
        $statusLabel = 'Lolos';
        $color = '#16A34A'; // Hijau
    } else {
        $statusLabel = 'Belum Dinilai';
        $color = '#94A3B8'; // Abu-abu
    }
    ```
  - Membangun data region Jawa Timur untuk Leaflet Map menggunakan status mayoritas / agregat wilayah dengan skema warna Lolos (Hijau) dan Gugur (Merah-Orange).
- **Logika Drive Link**:
  - Method `saveDriveReviewLink()`: Validasi URL dan simpan ke `MasterLink::updateOrCreate(['id_periode' => $this->periodeId], ['link_drive_review_saq' => $this->driveReviewLink])`.
  - Hanya dapat dieksekusi oleh role `super_evaluator`, `evaluator`, atau `admin`.

---

### Langkah 2: Template Blade Tab 2 (`saq-review-section.blade.php`)
1. **Header Row / Baris Filter**:
   - Dropdown pemilihan tahun (contoh: `2026`, `2025`, `2024`).
   - Keterangan ringkas status evaluasi SAQ pada periode terpilih.
2. **Grid Visualisasi (Desktop 50:50, Mobile Tabbed)**:
   - **Kiri**: Histogram SAQ per indikator (pilihan Kab/Kota, legend predikat indikator, tombol salin gambar).
   - **Kanan**: Peta Sebaran Lolos/Gugur Jawa Timur:
     - Inisialisasi peta Leaflet.
     - Tooltip informatif: Nama daerah, Nilai SAQ, Status Lolos/Gugur.
     - Legend sederhana:
       - 🟢 **Lolos (≥ 80)**
       - 🟠 **Gugur (< 80)**
     - Tombol salin gambar peta.
3. **Bagian Bawah**:
   - Banner Google Drive Review SAQ.
   - Jika role `super_evaluator` / `evaluator`: Dilengkapi tombol & form "Atur Tautan / Ubah Tautan".
   - Jika role `penilai_eksternal`: Hanya tombol "Buka Folder Google Drive".

---

### Langkah 3: Halaman Evaluator & Super Evaluator (2 Tab)
- **File**: `resources/views/pages/evaluasi/saq/monitoring.blade.php`.
- Menambahkan tab switcher di atas konten (mengikuti pola halaman Visitasi/Wawancara):
  - **Tab 1: "Kuesioner SAQ"**:
    - Menampilkan tabel evaluasi `<livewire:evaluasi.monitor-kuesioner-table />`.
    - Modal atur jadwal & penugasan evaluator.
  - **Tab 2: "Review SAQ"**:
    - Menampilkan `<livewire:evaluasi.saq-review-section />`.
  - Penanganan transisi tab via Alpine.js dengan event trigger resize peta (`window.myMap.invalidateSize()`) saat tab dibuka.

---

### Langkah 4: Halaman Khusus Penilai Eksternal
- **File**:
  - `resources/views/pages/evaluasi/saq/review-eksternal.blade.php` [BARU]
  - `app/Http/Controllers/Evaluasi/SaqController.php`
- Pada method `monitorKues`:
  - Jika user ber-role `penilai_eksternal`: return view `pages.evaluasi.saq.review-eksternal`.
  - View ini memuat layout aplikasi standar dengan header judul *"Review Kuesioner SAQ"*, breadcrumb *Monitoring Kegiatan > Kuesioner SAQ*, dan langsung menampilkan `<livewire:evaluasi.saq-review-section />` (tanpa tab 1 / tabel monitoring).

---

### Langkah 5: Penyesuaian Menu Sidebar (`NavigationService.php`)
- **File**: `app/Services/NavigationService.php`.
- Pada blok konfigurasi role `penilai_eksternal`:
  - Pastikan item menu **"Kuesioner SAQ"** (`/penilai-eksternal/monitor-kues`) selalu terdaftar di bawah dropdown *Monitoring Kegiatan* tanpa syarat assignment tahapan.

---

### Langkah 6: Pembersihan di Halaman Penilaian Akhir
- **File**: `resources/views/livewire/evaluasi/partials/charts-section.blade.php`.
- Hapus `@include('livewire.evaluasi.partials.banner-drive-review')` dari halaman Penilaian Akhir.
- Halaman Penilaian Akhir tetap fokus pada rekapitulasi nilai akhir tanpa banner review SAQ.

---

## 4. Checklist Eksekusi

- [x] Update `app/Services/NavigationService.php` (sidebar penilai_eksternal selalu memuat Kuesioner SAQ)
- [x] Buat Livewire Component `app/Livewire/Evaluasi/SaqReviewSection.php` (filter tahun, kalkulasi lolos/gugur, peta, histogram, form drive link)
- [x] Buat Blade View `resources/views/livewire/evaluasi/saq-review-section.blade.php` (layout 2 kolom + filter tahun + banner drive)
- [x] Buat Blade View `resources/views/pages/evaluasi/saq/review-eksternal.blade.php` (halaman khusus role eksternal)
- [x] Sesuaikan `app/Http/Controllers/Evaluasi/SaqController.php` (routing view eksternal ke halaman khusus)
- [x] Sesuaikan `resources/views/pages/evaluasi/saq/monitoring.blade.php` (2 tab: Kuesioner SAQ & Review SAQ untuk evaluator/super)
- [x] Hapus `@include('livewire.evaluasi.partials.banner-drive-review')` dari `resources/views/livewire/evaluasi/partials/charts-section.blade.php`
- [x] Verifikasi tampilan dan fungsionalitas untuk semua role sesuai panduan rules
