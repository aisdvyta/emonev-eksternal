<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\DashboardController;

Route::get('/', [LoginController::class, 'showLoginForm'])->name('login');
Route::get('/template-saq', [\App\Http\Controllers\Evaluasi\SaqController::class, 'downloadPublicTemplateSaq'])->name('public.template-saq');
Route::post('/login', [LoginController::class, 'login'])->name('login.post')->middleware('throttle:login');
Route::post('/logout', [LoginController::class, 'logout'])->name('logout');

// SSO BPS Routes
Route::get('/auth/sso', [\App\Http\Controllers\Auth\SsoController::class, 'redirectToSso'])->name('sso.login');
Route::get('/auth/sso/callback', [\App\Http\Controllers\Auth\SsoController::class, 'handleSsoCallback'])->name('sso.callback');
Route::post('/auth/sso/logout', [\App\Http\Controllers\Auth\SsoController::class, 'logoutSso'])->name('sso.logout');

// ==========================================
// UNIFIED DASHBOARD (Fase 5)
// ==========================================
Route::get('/dashboard', [DashboardController::class, 'index'])->middleware(['auth'])->name('dashboard');

// Operator Routes
Route::prefix('operator')->middleware(['auth', 'role:operator'])->group(function () {
    Route::get('/', [DashboardController::class, 'index'])->name('operator.index');

    Route::get('/kues-saq/export', [\App\Http\Controllers\Evaluasi\SaqController::class, 'exportSaq'])->name('operator.kues-saq.export');
    Route::get('/kues-saq/template', [\App\Http\Controllers\Evaluasi\SaqController::class, 'downloadTemplateSaq'])->name('operator.kues-saq.template');
    Route::post('/kues-saq/import', [\App\Http\Controllers\Evaluasi\SaqController::class, 'importAnswersSaq'])->name('operator.kues-saq.import');
    Route::get('/kues-saq/{id_periode?}', [\App\Http\Controllers\Evaluasi\SaqController::class, 'kuesSaq'])->withoutMiddleware('role:operator')->middleware('role:operator|verifikator')->name('operator.kues-saq');
    Route::post('/kues-saq/save', [\App\Http\Controllers\Evaluasi\SaqController::class, 'saveKues'])->name('operator.kues-saq.save');

    Route::get('/wawancara/export', [\App\Http\Controllers\Evaluasi\WawancaraController::class, 'exportWawancara'])->name('operator.wawancara.export');
    Route::get('/wawancara/{id_periode?}', [\App\Http\Controllers\Evaluasi\WawancaraController::class, 'wawancara'])->name('operator.wawancara');

    Route::get('/penilaian/export', [\App\Http\Controllers\Evaluasi\PenilaianController::class, 'export'])->name('operator.penilaian.export');
    Route::get('/penilaian/{id_periode?}', [\App\Http\Controllers\Evaluasi\PenilaianController::class, 'penilaian'])->name('operator.penilaian');

    Route::get('/visitasi/export', [\App\Http\Controllers\Evaluasi\VisitasiController::class, 'exportVisitasi'])->name('operator.visitasi.export');
    Route::get('/visitasi/{id_periode?}', [\App\Http\Controllers\Evaluasi\VisitasiController::class, 'visitasi'])->name('operator.visitasi');
    Route::post('/visitasi/link-bukti', [\App\Http\Controllers\Evaluasi\VisitasiController::class, 'saveLinkBuktiVisitasi'])->name('operator.visitasi.link-bukti');
    Route::get('/sk-sertifikat', [\App\Http\Controllers\Dokumen\SkSertifikatController::class, 'skSertifikat'])->name('operator.sk-sertifikat');
});

// ==========================================
// UNIFIED USER MANAGEMENT & MASTER DATA (Fase 2)
// ==========================================
Route::prefix('users')->middleware(['auth', 'role:admin|super_evaluator'])->group(function () {
    Route::get('/', [\App\Http\Controllers\Master\UserController::class, 'users'])->name('users.index');
    Route::get('/search-pegawai', [\App\Http\Controllers\Master\UserController::class, 'searchPegawai'])->name('users.search-pegawai');
    Route::post('/', [\App\Http\Controllers\Master\UserController::class, 'storeUser'])->name('users.store');
    Route::post('/import', [\App\Http\Controllers\Master\UserController::class, 'importUser'])->name('users.import');
    Route::put('/{id}', [\App\Http\Controllers\Master\UserController::class, 'updateUser'])->name('users.update');
    Route::delete('/{id}', [\App\Http\Controllers\Master\UserController::class, 'destroyUser'])->name('users.destroy');
});

Route::prefix('master')->middleware(['auth', 'role:super_evaluator|evaluator|admin'])->group(function () {
    Route::get('/users', [\App\Http\Controllers\Master\UserController::class, 'users'])->middleware('role:admin|super_evaluator')->name('master.users.index');
    Route::post('/users', [\App\Http\Controllers\Master\UserController::class, 'storeUser'])->middleware('role:admin|super_evaluator')->name('master.users.store');
    Route::post('/users/import', [\App\Http\Controllers\Master\UserController::class, 'importUser'])->middleware('role:admin|super_evaluator')->name('master.users.import');
    Route::put('/users/{id}', [\App\Http\Controllers\Master\UserController::class, 'updateUser'])->middleware('role:admin|super_evaluator')->name('master.users.update');
    Route::delete('/users/{id}', [\App\Http\Controllers\Master\UserController::class, 'destroyUser'])->middleware('role:admin|super_evaluator')->name('master.users.destroy');

    Route::get('/periode', [\App\Http\Controllers\Master\PeriodeController::class, 'managePeriode'])->name('master.periode.index');
    Route::post('/periode', [\App\Http\Controllers\Master\PeriodeController::class, 'storePeriode'])->name('master.periode.store');
    Route::put('/periode/{id}', [\App\Http\Controllers\Master\PeriodeController::class, 'updatePeriode'])->name('master.periode.update');
    Route::delete('/periode/{id}', [\App\Http\Controllers\Master\PeriodeController::class, 'deletePeriode'])->name('master.periode.delete');
    Route::get('/periode/atur-jadwal/{id?}', [\App\Http\Controllers\Master\PeriodeController::class, 'manageAturJadwal'])->name('master.periode.atur-jadwal');
    Route::post('/periode/atur-jadwal/{id}/update-stage', [\App\Http\Controllers\Master\PeriodeController::class, 'updateStageJadwal'])->name('master.periode.update-stage');

    Route::get('/pembobotan', [\App\Http\Controllers\Master\PembobotanController::class, 'managePembobotan'])->middleware('role:super_evaluator|admin')->name('master.pembobotan.index');
    Route::post('/pembobotan/save', [\App\Http\Controllers\Master\PembobotanController::class, 'storePembobotan'])->middleware('role:super_evaluator|admin')->name('master.pembobotan.save');

    Route::get('/indikator', [\App\Http\Controllers\Master\IndikatorController::class, 'manageIndikator'])->name('master.indikator.index');
    Route::post('/indikator', [\App\Http\Controllers\Master\IndikatorController::class, 'storeIndikator'])->name('master.indikator.store');
    Route::put('/indikator/{id}', [\App\Http\Controllers\Master\IndikatorController::class, 'updateIndikator'])->name('master.indikator.update');
    Route::delete('/indikator/{id}', [\App\Http\Controllers\Master\IndikatorController::class, 'deleteIndikator'])->name('master.indikator.delete');

    Route::get('/sub-indikator', [\App\Http\Controllers\Master\SubIndikatorController::class, 'manageSubIndikator'])->name('master.sub-indikator.index');
    Route::post('/sub-indikator', [\App\Http\Controllers\Master\SubIndikatorController::class, 'storeSubIndikator'])->name('master.sub-indikator.store');
    Route::put('/sub-indikator/{id}', [\App\Http\Controllers\Master\SubIndikatorController::class, 'updateSubIndikator'])->name('master.sub-indikator.update');
    Route::delete('/sub-indikator/{id}', [\App\Http\Controllers\Master\SubIndikatorController::class, 'deleteSubIndikator'])->name('master.sub-indikator.delete');

    Route::get('/kuesioner', [\App\Http\Controllers\Master\KuesionerController::class, 'manageKuesioner'])->name('master.kuesioner.index');
    Route::post('/kuesioner', [\App\Http\Controllers\Master\KuesionerController::class, 'storeKuesioner'])->name('master.kuesioner.store');
    Route::post('/kuesioner/import', [\App\Http\Controllers\Master\KuesionerController::class, 'importKuesioner'])->name('master.kuesioner.import');
    Route::put('/kuesioner/{id}', [\App\Http\Controllers\Master\KuesionerController::class, 'updateKuesioner'])->name('master.kuesioner.update');
    Route::delete('/kuesioner/{id}', [\App\Http\Controllers\Master\KuesionerController::class, 'deleteKuesioner'])->name('master.kuesioner.delete');
});

// ==========================================
// UNIFIED DOKUMEN (SK & SERTIFIKAT) (Fase 3)
// ==========================================
Route::prefix('dokumen')->middleware(['auth'])->group(function () {
    Route::get('/sk-sertifikat', [\App\Http\Controllers\Dokumen\SkSertifikatController::class, 'index'])->name('dokumen.sk-sertifikat');
    Route::get('/manage-sk/{id_periode?}', [\App\Http\Controllers\Dokumen\SkSertifikatController::class, 'manageSk'])->middleware('role:super_evaluator|evaluator')->name('dokumen.manage-sk');
    Route::post('/manage-sk/save', [\App\Http\Controllers\Dokumen\SkSertifikatController::class, 'saveSk'])->middleware('role:super_evaluator|evaluator')->name('dokumen.manage-sk.save');
    Route::post('/manage-sk/delete', [\App\Http\Controllers\Dokumen\SkSertifikatController::class, 'deleteSk'])->middleware('role:super_evaluator|evaluator')->name('dokumen.manage-sk.delete');
    Route::post('/manage-sk/upload-file', [\App\Http\Controllers\Dokumen\SkSertifikatController::class, 'saveSimpleFile'])->middleware('role:super_evaluator|evaluator')->name('dokumen.manage-sk.upload-file');
    Route::post('/manage-sk/delete-file', [\App\Http\Controllers\Dokumen\SkSertifikatController::class, 'deleteSimpleFile'])->middleware('role:super_evaluator|evaluator')->name('dokumen.manage-sk.delete-file');

    Route::get('/manage-panduan', [\App\Http\Controllers\Dokumen\SkSertifikatController::class, 'managePanduan'])->middleware('role:super_evaluator')->name('dokumen.manage-panduan');
    Route::post('/manage-panduan/save', [\App\Http\Controllers\Dokumen\SkSertifikatController::class, 'savePanduan'])->middleware('role:super_evaluator')->name('dokumen.manage-panduan.save');
});

// ==========================================
// UNIFIED EVALUASI - WAWANCARA (Fase 4.1)
// ==========================================
Route::prefix('evaluasi/wawancara')->middleware(['auth'])->group(function () {
    Route::get('/export', [\App\Http\Controllers\Evaluasi\WawancaraController::class, 'exportWawancara'])->name('evaluasi.wawancara.export');
    Route::get('/monitoring', [\App\Http\Controllers\Evaluasi\WawancaraController::class, 'monitorWawancara'])->middleware('role:evaluator|super_evaluator|penilai_eksternal|admin')->name('evaluasi.wawancara.monitoring');
    Route::post('/schedule-batch', [\App\Http\Controllers\Evaluasi\WawancaraController::class, 'saveScheduleBatch'])->middleware('role:super_evaluator|admin')->name('evaluasi.wawancara.schedule-batch');
    Route::post('/schedule/{id}', [\App\Http\Controllers\Evaluasi\WawancaraController::class, 'saveSchedule'])->middleware('role:super_evaluator|admin')->name('evaluasi.wawancara.schedule');
    Route::get('/review/{id}', [\App\Http\Controllers\Evaluasi\WawancaraController::class, 'reviewWawancara'])->middleware('role:evaluator|super_evaluator|penilai_eksternal|admin')->name('evaluasi.wawancara.review');
    Route::post('/review/{id}/save', [\App\Http\Controllers\Evaluasi\WawancaraController::class, 'saveReview'])->middleware('role:evaluator|super_evaluator|penilai_eksternal|admin')->name('evaluasi.wawancara.review.save');
    Route::get('/{id_periode?}', [\App\Http\Controllers\Evaluasi\WawancaraController::class, 'wawancara'])->name('evaluasi.wawancara.index');
});

// ==========================================
// UNIFIED EVALUASI - VISITASI (Fase 4.2)
// ==========================================
Route::prefix('evaluasi/visitasi')->middleware(['auth'])->group(function () {
    Route::get('/export', [\App\Http\Controllers\Evaluasi\VisitasiController::class, 'exportVisitasi'])->name('evaluasi.visitasi.export');
    Route::get('/monitoring', [\App\Http\Controllers\Evaluasi\VisitasiController::class, 'monitorVisitasi'])->middleware('role:evaluator|super_evaluator|penilai_eksternal|admin')->name('evaluasi.visitasi.monitoring');
    Route::post('/schedule-batch', [\App\Http\Controllers\Evaluasi\VisitasiController::class, 'saveScheduleBatch'])->middleware('role:super_evaluator|admin')->name('evaluasi.visitasi.schedule-batch');
    Route::post('/schedule/{id}', [\App\Http\Controllers\Evaluasi\VisitasiController::class, 'saveSchedule'])->middleware('role:super_evaluator|admin')->name('evaluasi.visitasi.schedule');
    Route::get('/review/{id}', [\App\Http\Controllers\Evaluasi\VisitasiController::class, 'reviewVisitasi'])->middleware('role:evaluator|super_evaluator|penilai_eksternal|admin')->name('evaluasi.visitasi.review');
    Route::post('/review/{id}/save', [\App\Http\Controllers\Evaluasi\VisitasiController::class, 'saveReview'])->middleware('role:evaluator|super_evaluator|penilai_eksternal|admin')->name('evaluasi.visitasi.review.save');
    Route::post('/link-bukti', [\App\Http\Controllers\Evaluasi\VisitasiController::class, 'saveLinkBuktiVisitasi'])->middleware('role:operator')->name('evaluasi.visitasi.link-bukti');
    Route::get('/{id_periode?}', [\App\Http\Controllers\Evaluasi\VisitasiController::class, 'visitasi'])->name('evaluasi.visitasi.index');
});

// ==========================================
// UNIFIED EVALUASI - PENILAIAN (Fase 4.3)
// ==========================================
Route::prefix('evaluasi/penilaian')->middleware(['auth'])->group(function () {
    Route::get('/export', [\App\Http\Controllers\Evaluasi\PenilaianController::class, 'export'])->name('evaluasi.penilaian.export');
    Route::get('/donut-data', [\App\Http\Controllers\Evaluasi\PenilaianController::class, 'donutData'])->name('evaluasi.penilaian.donut-data');
    Route::post('/{id}/publish', [\App\Http\Controllers\Evaluasi\PenilaianController::class, 'publish'])->middleware('role:super_evaluator|admin')->name('evaluasi.penilaian.publish');
    Route::post('/{id}/komentar', [\App\Http\Controllers\Evaluasi\PenilaianController::class, 'saveKomentar'])->middleware('role:super_evaluator|admin')->name('evaluasi.penilaian.komentar');
    Route::get('/{id_periode?}', [\App\Http\Controllers\Evaluasi\PenilaianController::class, 'index'])->name('evaluasi.penilaian.index');
});

// ==========================================
// UNIFIED EVALUASI - SAQ (Fase 4.4)
// ==========================================
Route::prefix('evaluasi/saq')->middleware(['auth'])->group(function () {
    Route::get('/export', [\App\Http\Controllers\Evaluasi\SaqController::class, 'export'])->name('evaluasi.saq.export');
    Route::get('/monitoring', [\App\Http\Controllers\Evaluasi\SaqController::class, 'monitorKues'])->middleware('role:evaluator|super_evaluator|admin')->name('evaluasi.saq.monitoring');
    Route::post('/schedule-batch', [\App\Http\Controllers\Evaluasi\SaqController::class, 'saveScheduleBatch'])->middleware('role:super_evaluator|admin')->name('evaluasi.saq.schedule-batch');
    Route::get('/review/{submission}', [\App\Http\Controllers\Evaluasi\SaqController::class, 'reviewKues'])->middleware('role:evaluator|super_evaluator|admin')->name('evaluasi.saq.review');
    Route::post('/review/save', [\App\Http\Controllers\Evaluasi\SaqController::class, 'saveReview'])->middleware('role:evaluator|super_evaluator|admin')->name('evaluasi.saq.review.save');
    Route::post('/save', [\App\Http\Controllers\Evaluasi\SaqController::class, 'saveKues'])->middleware('role:operator')->name('evaluasi.saq.save');
    Route::post('/verifikasi/draft/{id}', [\App\Http\Controllers\Evaluasi\SaqController::class, 'saveDraft'])->middleware('role:verifikator')->name('evaluasi.saq.verifikasi.draft');
    Route::post('/verifikasi/decision/{id}', [\App\Http\Controllers\Evaluasi\SaqController::class, 'processDecision'])->middleware('role:verifikator')->name('evaluasi.saq.verifikasi.decision');
    Route::get('/{id_periode?}', [\App\Http\Controllers\Evaluasi\SaqController::class, 'index'])->name('evaluasi.saq.index');
});

// Super Evaluator Routes
Route::prefix('super-evaluator')->middleware(['auth', 'role:super_evaluator'])->group(function () {
    Route::get('/', [DashboardController::class, 'index'])->name('super-evaluator.index');
    Route::get('/users', [\App\Http\Controllers\Master\UserController::class, 'users'])->name('super-evaluator.users');
    Route::post('/users', [\App\Http\Controllers\Master\UserController::class, 'storeUser'])->name('super-evaluator.users.store');
    Route::post('/users/import', [\App\Http\Controllers\Master\UserController::class, 'importUser'])->name('super-evaluator.users.import');
    Route::put('/users/{id}', [\App\Http\Controllers\Master\UserController::class, 'updateUser'])->name('super-evaluator.users.update');
    Route::delete('/users/{id}', [\App\Http\Controllers\Master\UserController::class, 'destroyUser'])->name('super-evaluator.users.destroy');

    Route::get('/monitor-kues', [\App\Http\Controllers\Evaluasi\SaqController::class, 'monitorKues'])->name('super-evaluator.monitor-kues');
    Route::get('/monitor-kues/export', [\App\Http\Controllers\Evaluasi\SaqController::class, 'exportKuesBatch'])->name('super-evaluator.monitor-kues.export');
    Route::get('/review-kues/{submission}', [\App\Http\Controllers\Evaluasi\SaqController::class, 'reviewKues'])->name('super-evaluator.review-kues');
    Route::get('/review-kues/{submission}/export', [\App\Http\Controllers\Evaluasi\SaqController::class, 'exportKues'])->name('super-evaluator.review-kues.export');
    Route::post('/review-kues/save', [\App\Http\Controllers\Evaluasi\SaqController::class, 'saveReview'])->name('super-evaluator.review-kues.save');
    Route::post('/schedule-kues-batch', [\App\Http\Controllers\Evaluasi\SaqController::class, 'saveScheduleBatch'])->name('super-evaluator.schedule-kues-batch');

    Route::get('/monitor-wawancara', [\App\Http\Controllers\Evaluasi\WawancaraController::class, 'monitorWawancara'])->name('super-evaluator.monitor-wawancara');
    Route::get('/monitor-wawancara/export', [\App\Http\Controllers\Evaluasi\WawancaraController::class, 'exportWawancara'])->name('super-evaluator.monitor-wawancara.export');
    Route::get('/review-wawancara/{id}', [\App\Http\Controllers\Evaluasi\WawancaraController::class, 'reviewWawancara'])->name('super-evaluator.review-wawancara');
    Route::post('/review-wawancara/{id}/save', [\App\Http\Controllers\Evaluasi\WawancaraController::class, 'saveReview'])->name('super-evaluator.review-wawancara.save');
    Route::post('/schedule-wawancara/{id}', [\App\Http\Controllers\Evaluasi\WawancaraController::class, 'saveSchedule'])->name('super-evaluator.schedule-wawancara');
    Route::post('/schedule-wawancara-batch', [\App\Http\Controllers\Evaluasi\WawancaraController::class, 'saveScheduleBatch'])->name('super-evaluator.schedule-wawancara-batch');

    Route::get('/monitor-visitasi', [\App\Http\Controllers\Evaluasi\VisitasiController::class, 'monitorVisitasi'])->name('super-evaluator.monitor-visitasi');
    Route::get('/monitor-visitasi/export', [\App\Http\Controllers\Evaluasi\VisitasiController::class, 'exportVisitasi'])->name('super-evaluator.monitor-visitasi.export');
    Route::get('/review-visitasi/{id}', [\App\Http\Controllers\Evaluasi\VisitasiController::class, 'reviewVisitasi'])->name('super-evaluator.review-visitasi');
    Route::post('/review-visitasi/{id}/save', [\App\Http\Controllers\Evaluasi\VisitasiController::class, 'saveReview'])->name('super-evaluator.review-visitasi.save');
    Route::post('/schedule-visitasi/{id}', [\App\Http\Controllers\Evaluasi\VisitasiController::class, 'saveSchedule'])->name('super-evaluator.schedule-visitasi');
    Route::post('/schedule-visitasi-batch', [\App\Http\Controllers\Evaluasi\VisitasiController::class, 'saveScheduleBatch'])->name('super-evaluator.schedule-visitasi-batch');

    Route::get('/manage-atur-jadwal/{id?}', [\App\Http\Controllers\Master\PeriodeController::class, 'manageAturJadwal'])->name('super-evaluator.manage-atur-jadwal');
    Route::post('/manage-atur-jadwal/{id}/update-stage', [\App\Http\Controllers\Master\PeriodeController::class, 'updateStageJadwal'])->name('super-evaluator.manage-atur-jadwal.update-stage');

    Route::get('/manage-jadwal', [\App\Http\Controllers\Master\PeriodeController::class, 'managePeriode'])->name('super-evaluator.manage-jadwal');
    Route::post('/periode', [\App\Http\Controllers\Master\PeriodeController::class, 'storePeriode'])->name('super-evaluator.periode.store');
    Route::put('/periode/{id}', [\App\Http\Controllers\Master\PeriodeController::class, 'updatePeriode'])->name('super-evaluator.periode.update');
    Route::delete('/periode/{id}', [\App\Http\Controllers\Master\PeriodeController::class, 'deletePeriode'])->name('super-evaluator.periode.delete');

    Route::get('/manage-pembobotan', [\App\Http\Controllers\Master\PembobotanController::class, 'managePembobotan'])->name('super-evaluator.manage-pembobotan');
    Route::post('/manage-pembobotan/save', [\App\Http\Controllers\Master\PembobotanController::class, 'storePembobotan'])->name('super-evaluator.manage-pembobotan.save');

    Route::get('/manage-indikator', [\App\Http\Controllers\Master\IndikatorController::class, 'manageIndikator'])->name('super-evaluator.manage-indikator');
    Route::post('/indikator', [\App\Http\Controllers\Master\IndikatorController::class, 'storeIndikator'])->name('super-evaluator.indikator.store');
    Route::put('/indikator/{id}', [\App\Http\Controllers\Master\IndikatorController::class, 'updateIndikator'])->name('super-evaluator.indikator.update');
    Route::delete('/indikator/{id}', [\App\Http\Controllers\Master\IndikatorController::class, 'deleteIndikator'])->name('super-evaluator.indikator.delete');

    Route::get('/manage-sub-indikator', [\App\Http\Controllers\Master\SubIndikatorController::class, 'manageSubIndikator'])->name('super-evaluator.manage-sub-indikator');
    Route::post('/sub-indikator', [\App\Http\Controllers\Master\SubIndikatorController::class, 'storeSubIndikator'])->name('super-evaluator.sub-indikator.store');
    Route::put('/sub-indikator/{id}', [\App\Http\Controllers\Master\SubIndikatorController::class, 'updateSubIndikator'])->name('super-evaluator.sub-indikator.update');
    Route::delete('/sub-indikator/{id}', [\App\Http\Controllers\Master\SubIndikatorController::class, 'deleteSubIndikator'])->name('super-evaluator.sub-indikator.delete');

    Route::get('/manage-kuesioner', [\App\Http\Controllers\Master\KuesionerController::class, 'manageKuesioner'])->name('super-evaluator.manage-kuesioner');
    Route::post('/manage-kuesioner/import', [\App\Http\Controllers\Master\KuesionerController::class, 'importKuesioner'])->name('super-evaluator.manage-kuesioner.import');
    Route::post('/kuesioner', [\App\Http\Controllers\Master\KuesionerController::class, 'storeKuesioner'])->name('super-evaluator.kuesioner.store');
    Route::put('/kuesioner/{id}', [\App\Http\Controllers\Master\KuesionerController::class, 'updateKuesioner'])->name('super-evaluator.kuesioner.update');
    Route::delete('/kuesioner/{id}', [\App\Http\Controllers\Master\KuesionerController::class, 'deleteKuesioner'])->name('super-evaluator.kuesioner.delete');

    Route::get('/manage-sk/{id_periode?}', [\App\Http\Controllers\Dokumen\SkSertifikatController::class, 'manageSk'])->name('super-evaluator.manage-sk');
    Route::post('/manage-sk/save', [\App\Http\Controllers\Dokumen\SkSertifikatController::class, 'saveSk'])->name('super-evaluator.manage-sk.save');
    Route::post('/manage-sk/delete', [\App\Http\Controllers\Dokumen\SkSertifikatController::class, 'deleteSk'])->name('super-evaluator.manage-sk.delete');
    Route::post('/manage-sk/upload-file', [\App\Http\Controllers\Dokumen\SkSertifikatController::class, 'saveSimpleFile'])->name('super-evaluator.manage-sk.upload-file');
    Route::post('/manage-sk/delete-file', [\App\Http\Controllers\Dokumen\SkSertifikatController::class, 'deleteSimpleFile'])->name('super-evaluator.manage-sk.delete-file');

    Route::get('/manage-panduan', [\App\Http\Controllers\Dokumen\SkSertifikatController::class, 'managePanduan'])->name('super-evaluator.manage-panduan');
    Route::post('/manage-panduan/save', [\App\Http\Controllers\Dokumen\SkSertifikatController::class, 'savePanduan'])->name('super-evaluator.manage-panduan.save');

    Route::get('/penilaian', [\App\Http\Controllers\Evaluasi\PenilaianController::class, 'index'])->name('super-evaluator.penilaian');
    Route::post('/penilaian/{id}/publish', [\App\Http\Controllers\Evaluasi\PenilaianController::class, 'publish'])->name('super-evaluator.penilaian.publish');
    Route::get('/penilaian/export', [\App\Http\Controllers\Evaluasi\PenilaianController::class, 'export'])->name('super-evaluator.penilaian.export');
    Route::get('/penilaian/donut-data', [\App\Http\Controllers\Evaluasi\PenilaianController::class, 'donutData'])->name('super-evaluator.penilaian.donut-data');
    Route::post('/penilaian/{id}/komentar', [\App\Http\Controllers\Evaluasi\PenilaianController::class, 'saveKomentar'])->name('super-evaluator.penilaian.komentar');
});

// Evaluator Routes
Route::prefix('evaluator')->middleware(['auth', 'role:evaluator|super_evaluator'])->group(function () {
    Route::get('/', [DashboardController::class, 'index'])->name('evaluator.index');

    Route::get('/monitor-kues', [\App\Http\Controllers\Evaluasi\SaqController::class, 'monitorKues'])->name('evaluator.monitor-kues');
    Route::get('/monitor-kues/export', [\App\Http\Controllers\Evaluasi\SaqController::class, 'exportKuesBatch'])->name('evaluator.monitor-kues.export');
    Route::get('/review-kues/{submission}', [\App\Http\Controllers\Evaluasi\SaqController::class, 'reviewKues'])->name('evaluator.review-kues');
    Route::get('/review-kues/{submission}/export', [\App\Http\Controllers\Evaluasi\SaqController::class, 'exportKues'])->name('evaluator.review-kues.export');
    Route::post('/review-kues/save', [\App\Http\Controllers\Evaluasi\SaqController::class, 'saveReview'])->name('evaluator.review-kues.save');

    Route::get('/monitor-wawancara', [\App\Http\Controllers\Evaluasi\WawancaraController::class, 'monitorWawancara'])->name('evaluator.monitor-wawancara');
    Route::get('/monitor-wawancara/export', [\App\Http\Controllers\Evaluasi\WawancaraController::class, 'exportWawancara'])->name('evaluator.monitor-wawancara.export');
    Route::get('/review-wawancara/{id}', [\App\Http\Controllers\Evaluasi\WawancaraController::class, 'reviewWawancara'])->name('evaluator.review-wawancara');
    Route::post('/review-wawancara/{id}/save', [\App\Http\Controllers\Evaluasi\WawancaraController::class, 'saveReview'])->name('evaluator.review-wawancara.save');

    Route::get('/monitor-visitasi', [\App\Http\Controllers\Evaluasi\VisitasiController::class, 'monitorVisitasi'])->name('evaluator.monitor-visitasi');
    Route::get('/monitor-visitasi/export', [\App\Http\Controllers\Evaluasi\VisitasiController::class, 'exportVisitasi'])->name('evaluator.monitor-visitasi.export');
    Route::post('/schedule-visitasi/{id}', [\App\Http\Controllers\Evaluasi\VisitasiController::class, 'saveSchedule'])->middleware('role:super_evaluator|admin')->name('evaluator.schedule-visitasi');
    Route::post('/schedule-visitasi-batch', [\App\Http\Controllers\Evaluasi\VisitasiController::class, 'saveScheduleBatch'])->middleware('role:super_evaluator|admin')->name('evaluator.schedule-visitasi-batch');
    Route::get('/review-visitasi/{id}', [\App\Http\Controllers\Evaluasi\VisitasiController::class, 'reviewVisitasi'])->name('evaluator.review-visitasi');
    Route::post('/review-visitasi/{id}/save', [\App\Http\Controllers\Evaluasi\VisitasiController::class, 'saveReview'])->name('evaluator.review-visitasi.save');

    Route::get('/penilaian', [\App\Http\Controllers\Evaluasi\PenilaianController::class, 'index'])->name('evaluator.penilaian');
    Route::post('/penilaian/{id}/publish', [\App\Http\Controllers\Evaluasi\PenilaianController::class, 'publish'])->middleware('role:super_evaluator|admin')->name('evaluator.penilaian.publish');
    Route::get('/penilaian/export', [\App\Http\Controllers\Evaluasi\PenilaianController::class, 'export'])->name('evaluator.penilaian.export');
    Route::get('/penilaian/donut-data', [\App\Http\Controllers\Evaluasi\PenilaianController::class, 'donutData'])->name('evaluator.penilaian.donut-data');


    Route::get('/manage-indikator', [\App\Http\Controllers\Master\IndikatorController::class, 'manageIndikator'])->name('evaluator.manage-indikator');
    Route::post('/indikator', [\App\Http\Controllers\Master\IndikatorController::class, 'storeIndikator'])->name('evaluator.indikator.store');
    Route::put('/indikator/{id}', [\App\Http\Controllers\Master\IndikatorController::class, 'updateIndikator'])->name('evaluator.indikator.update');
    Route::delete('/indikator/{id}', [\App\Http\Controllers\Master\IndikatorController::class, 'deleteIndikator'])->name('evaluator.indikator.delete');

    Route::get('/manage-sub-indikator', [\App\Http\Controllers\Master\SubIndikatorController::class, 'manageSubIndikator'])->name('evaluator.manage-sub-indikator');
    Route::post('/sub-indikator', [\App\Http\Controllers\Master\SubIndikatorController::class, 'storeSubIndikator'])->name('evaluator.sub-indikator.store');
    Route::put('/sub-indikator/{id}', [\App\Http\Controllers\Master\SubIndikatorController::class, 'updateSubIndikator'])->name('evaluator.sub-indikator.update');
    Route::delete('/sub-indikator/{id}', [\App\Http\Controllers\Master\SubIndikatorController::class, 'deleteSubIndikator'])->name('evaluator.sub-indikator.delete');

    Route::get('/manage-kuesioner', [\App\Http\Controllers\Master\KuesionerController::class, 'manageKuesioner'])->name('evaluator.manage-kuesioner');
    Route::post('/manage-kuesioner/import', [\App\Http\Controllers\Master\KuesionerController::class, 'importKuesioner'])->name('evaluator.manage-kuesioner.import');
    Route::post('/kuesioner', [\App\Http\Controllers\Master\KuesionerController::class, 'storeKuesioner'])->name('evaluator.kuesioner.store');
    Route::put('/kuesioner/{id}', [\App\Http\Controllers\Master\KuesionerController::class, 'updateKuesioner'])->name('evaluator.kuesioner.update');
    Route::delete('/kuesioner/{id}', [\App\Http\Controllers\Master\KuesionerController::class, 'deleteKuesioner'])->name('evaluator.kuesioner.delete');

    Route::get('/manage-sk/{id_periode?}', [\App\Http\Controllers\Dokumen\SkSertifikatController::class, 'manageSk'])->name('evaluator.manage-sk');
    Route::post('/manage-sk/save', [\App\Http\Controllers\Dokumen\SkSertifikatController::class, 'saveSk'])->name('evaluator.manage-sk.save');
    Route::post('/manage-sk/delete', [\App\Http\Controllers\Dokumen\SkSertifikatController::class, 'deleteSk'])->name('evaluator.manage-sk.delete');
    Route::post('/manage-sk/upload-file', [\App\Http\Controllers\Dokumen\SkSertifikatController::class, 'saveSimpleFile'])->name('evaluator.manage-sk.upload-file');
    Route::post('/manage-sk/delete-file', [\App\Http\Controllers\Dokumen\SkSertifikatController::class, 'deleteSimpleFile'])->name('evaluator.manage-sk.delete-file');
});

// Verifikator Routes (Kasubag Kabkot)
Route::prefix('verifikator')->middleware(['auth', 'role:verifikator'])->group(function () {
    Route::get('/', [DashboardController::class, 'index'])->name('verifikator.index');
    Route::get('/monitoring-saq/export', [\App\Http\Controllers\Evaluasi\SaqController::class, 'exportSaq'])->name('verifikator.monitoring-saq.export');
    Route::get('/kues-saq/{id_periode?}', [\App\Http\Controllers\Evaluasi\SaqController::class, 'verifikasiSaq'])->name('verifikator.kues-saq');
    Route::get('/verifikasi-saq/{submission?}', [\App\Http\Controllers\Evaluasi\SaqController::class, 'verifikasiSaq'])->name('verifikator.verifikasi-saq');
    Route::post('/verifikasi-saq/draft/{id}', [\App\Http\Controllers\Evaluasi\SaqController::class, 'saveDraft'])->name('verifikator.verifikasi-saq.draft');
    Route::post('/verifikasi-saq/decision/{id}', [\App\Http\Controllers\Evaluasi\SaqController::class, 'processDecision'])->name('verifikator.verifikasi-saq.decision');
    Route::get('/monitoring-visitasi/export', [\App\Http\Controllers\Evaluasi\VisitasiController::class, 'exportVisitasi'])->name('verifikator.monitoring-visitasi.export');
    Route::get('/monitoring-visitasi/{id_periode?}', [\App\Http\Controllers\Evaluasi\VisitasiController::class, 'monitoringVisitasi'])->name('verifikator.monitoring-visitasi');
    Route::get('/monitoring-wawancara/export', [\App\Http\Controllers\Evaluasi\WawancaraController::class, 'exportWawancara'])->name('verifikator.monitoring-wawancara.export');
    Route::get('/monitoring-wawancara/{id_periode?}', [\App\Http\Controllers\Evaluasi\WawancaraController::class, 'monitoringWawancara'])->name('verifikator.monitoring-wawancara');
    Route::get('/penilaian/{id_periode?}', [\App\Http\Controllers\Evaluasi\PenilaianController::class, 'penilaian'])->name('verifikator.penilaian');
    Route::get('/sk-sertifikat', [\App\Http\Controllers\Dokumen\SkSertifikatController::class, 'skSertifikat'])->name('verifikator.sk-sertifikat');
});

// Kabag Routes — DIHAPUS (role kabag dimigrasikan ke super_evaluator)
// User yang sebelumnya ber-role kabag sekarang menggunakan halaman /super-evaluator/hasil-akhir

// Admin Routes
Route::prefix('admin')->middleware(['auth', 'role:admin'])->group(function () {
    Route::get('/', [DashboardController::class, 'index'])->name('admin.index');

    Route::get('/users', [\App\Http\Controllers\Master\UserController::class, 'users'])->name('admin.users');
    Route::post('/users', [\App\Http\Controllers\Master\UserController::class, 'storeUser'])->name('admin.users.store');
    Route::post('/users/import', [\App\Http\Controllers\Master\UserController::class, 'importUser'])->name('admin.users.import');

    Route::put('/users/{id}', [\App\Http\Controllers\Master\UserController::class, 'updateUser'])->name('admin.users.update');
    Route::delete('/users/{id}', [\App\Http\Controllers\Master\UserController::class, 'destroyUser'])->name('admin.users.destroy');
});

// Penilai Eksternal Routes
Route::prefix('penilai-eksternal')->middleware(['auth', 'role:penilai_eksternal'])->group(function () {
    Route::get('/', [DashboardController::class, 'index'])->name('penilai-eksternal.index');

    Route::get('/monitor-kues', [\App\Http\Controllers\Evaluasi\SaqController::class, 'monitorKues'])->name('penilai-eksternal.monitor-kues');
    Route::get('/monitor-kues/export', [\App\Http\Controllers\Evaluasi\SaqController::class, 'exportKuesBatch'])->name('penilai-eksternal.monitor-kues.export');
    Route::get('/review-kues/{submission}', [\App\Http\Controllers\Evaluasi\SaqController::class, 'reviewKues'])->name('penilai-eksternal.review-kues');
    Route::get('/review-kues/{submission}/export', [\App\Http\Controllers\Evaluasi\SaqController::class, 'exportKues'])->name('penilai-eksternal.review-kues.export');
    Route::post('/review-kues/save', [\App\Http\Controllers\Evaluasi\SaqController::class, 'saveReview'])->name('penilai-eksternal.review-kues.save');

    Route::get('/monitor-visitasi', [\App\Http\Controllers\Evaluasi\VisitasiController::class, 'monitorVisitasi'])->name('penilai-eksternal.monitor-visitasi');
    Route::get('/monitor-visitasi/export', [\App\Http\Controllers\Evaluasi\VisitasiController::class, 'exportVisitasi'])->name('penilai-eksternal.monitor-visitasi.export');
    Route::get('/review-visitasi/{id}', [\App\Http\Controllers\Evaluasi\VisitasiController::class, 'reviewVisitasi'])->name('penilai-eksternal.review-visitasi');
    Route::post('/review-visitasi/{id}/save', [\App\Http\Controllers\Evaluasi\VisitasiController::class, 'saveReview'])->name('penilai-eksternal.review-visitasi.save');

    Route::get('/monitor-wawancara', [\App\Http\Controllers\Evaluasi\WawancaraController::class, 'monitorWawancara'])->name('penilai-eksternal.monitor-wawancara');
    Route::get('/monitor-wawancara/export', [\App\Http\Controllers\Evaluasi\WawancaraController::class, 'exportWawancara'])->name('penilai-eksternal.monitor-wawancara.export');
    Route::get('/review-wawancara/{id}', [\App\Http\Controllers\Evaluasi\WawancaraController::class, 'reviewWawancara'])->name('penilai-eksternal.review-wawancara');
    Route::post('/review-wawancara/{id}/save', [\App\Http\Controllers\Evaluasi\WawancaraController::class, 'saveReview'])->name('penilai-eksternal.review-wawancara.save');

    Route::get('/penilaian', [\App\Http\Controllers\Evaluasi\PenilaianController::class, 'index'])->name('penilai-eksternal.penilaian');
    Route::get('/penilaian/export', [\App\Http\Controllers\Evaluasi\PenilaianController::class, 'export'])->name('penilai-eksternal.penilaian.export');
    Route::get('/penilaian/donut-data', [\App\Http\Controllers\Evaluasi\PenilaianController::class, 'donutData'])->name('penilai-eksternal.penilaian.donut-data');
});

// Secure SK and Certificate Download Routes & Profile Routes
Route::middleware(['auth'])->group(function () {
    Route::get('/sertifikat/download/{uuid}', [\App\Http\Controllers\Dokumen\DokumenDownloadController::class, 'download'])->name('sertifikat.download');
    Route::get('/sk/download/{uuid}', [\App\Http\Controllers\Dokumen\DokumenDownloadController::class, 'downloadSk'])->name('sk.download');

    // Profile Routes (Semua Role)
    Route::get('/profil', [\App\Http\Controllers\ProfileController::class, 'show'])->name('profile.show');
    Route::put('/profil', [\App\Http\Controllers\ProfileController::class, 'update'])->name('profile.update');
    Route::put('/profil/password', [\App\Http\Controllers\ProfileController::class, 'updatePassword'])->name('profile.password');
});

