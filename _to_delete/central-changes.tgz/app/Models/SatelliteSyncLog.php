<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SatelliteSyncLog extends Model
{
    protected $table = 'satellite_sync_logs';
    public $timestamps = false;

    protected $fillable = [
        'direction', 'status', 'sync_id',
        'rows_sent', 'rows_received', 'rows_applied', 'rows_rejected', 'rows_failed',
        'message', 'details', 'started_at', 'finished_at',
    ];

    protected $casts = [
        'details' => 'array',
        'started_at' => 'datetime',
        'finished_at' => 'datetime',
    ];
}
