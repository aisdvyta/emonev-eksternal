<?php

namespace App\Services\Satellite;

use Illuminate\Http\Client\ConnectionException;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;

/**
 * Klien HTTP ke API sinkronisasi satelit (/api/v1). Setiap request ditandatangani HMAC-SHA256:
 *   canonical = METODE \n REQUEST_URI \n timestamp \n nonce \n sha256(body)
 * Kontrak lengkap: emonev-eksternal/docs/API-SINKRONISASI.md
 */
class SatelliteClient
{
    public function __construct(
        protected ?string $baseUrl = null,
        protected ?string $secret = null,
        protected ?int $timeout = null,
        protected ?int $retries = null,
    ) {
        $this->baseUrl = rtrim((string) ($this->baseUrl ?? config('satellite.url')), '/');
        $this->secret = (string) ($this->secret ?? config('satellite.secret'));
        $this->timeout ??= (int) config('satellite.timeout', 60);
        $this->retries ??= (int) config('satellite.retries', 2);
    }

    public function isConfigured(): bool
    {
        return $this->baseUrl !== '' && $this->secret !== '';
    }

    public function ping(): array
    {
        return $this->request('GET', '/ping');
    }

    public function snapshot(array $payload): array
    {
        return $this->request('POST', '/sync/snapshot', $payload);
    }

    public function scores(): array
    {
        return $this->request('GET', '/sync/scores');
    }

    /**
     * @param  array<int, array{type: string, parent_id: mixed, id_user: int, revision: int}>  $items
     */
    public function ack(array $items): array
    {
        return $this->request('POST', '/sync/ack', ['items' => array_values($items)]);
    }

    /** Tanda tangan v1 untuk satu request (dipublikasikan agar bisa diuji). */
    public function sign(string $method, string $uri, string $timestamp, string $nonce, string $body): string
    {
        $canonical = implode("\n", [strtoupper($method), $uri, $timestamp, $nonce, hash('sha256', $body)]);

        return 'v1=' . hash_hmac('sha256', $canonical, $this->secret);
    }

    protected function request(string $method, string $endpoint, ?array $json = null): array
    {
        if (! $this->isConfigured()) {
            throw new SatelliteException('SATELLITE_URL / SATELLITE_SECRET belum diisi.');
        }

        $url = $this->baseUrl . '/api/v1' . $endpoint;
        $uri = (string) parse_url($url, PHP_URL_PATH);
        $body = $json === null ? '' : json_encode($json, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);

        $attempts = max(1, $this->retries + 1);
        $last = null;

        for ($i = 1; $i <= $attempts; $i++) {
            // Tiap percobaan memakai timestamp + nonce baru (nonce yang sama ditolak sebagai replay).
            $timestamp = (string) time();
            $nonce = Str::random(32);

            $pending = Http::withHeaders([
                'X-Sync-Timestamp' => $timestamp,
                'X-Sync-Nonce' => $nonce,
                'X-Sync-Signature' => $this->sign($method, $uri, $timestamp, $nonce, $body),
            ])->acceptJson()->timeout($this->timeout);

            if ($json !== null) {
                $pending = $pending->withBody($body, 'application/json');
            }

            try {
                $response = $pending->send(strtoupper($method), $url);
            } catch (ConnectionException $e) {
                $last = new SatelliteException('Tidak bisa terhubung ke satelit: ' . $e->getMessage(), 0, $e);
                continue;
            }

            if ($response->serverError()) {
                $last = new SatelliteException("Satelit membalas HTTP {$response->status()} pada {$endpoint}.");
                continue;
            }

            if (! $response->successful()) {
                $err = $response->json('error') ?? $response->json('message') ?? ('HTTP ' . $response->status());
                throw new SatelliteException("Satelit menolak {$endpoint}: {$err}");
            }

            $data = $response->json();
            if (! is_array($data)) {
                throw new SatelliteException("Balasan satelit pada {$endpoint} bukan JSON.");
            }

            return $data;
        }

        throw $last ?? new SatelliteException("Gagal memanggil {$endpoint}.");
    }
}
