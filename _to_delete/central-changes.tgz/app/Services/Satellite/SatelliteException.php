<?php

namespace App\Services\Satellite;

use RuntimeException;

class SatelliteException extends RuntimeException
{
}
