<?php

namespace App\Services\Satellite;

use App\Models\SatelliteSyncLog;
use App\Models\User;
use App\Services\EvaluationResult;
use App\Services\EvaluationService;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Str;
use Throwable;

/**
 * Satu siklus sinkronisasi pusat ⇄ satelit:
 *   push : kirim penugasan penilai eksternal (snapshot)
 *   pull : ambil nilai yang diisi penilai, validasi ulang di pusat, simpan lewat EvaluationService, lalu ack
 *
 * Pusat adalah sumber kebenaran: semua aturan (tahap, tenggat, penugasan, rata-rata, finalisasi) dijalankan
 * ulang di sini; satelit hanya mengumpulkan nilai.
 */
class SatelliteSyncService
{
    public function __construct(
        protected SatelliteClient $client,
        protected SatellitePayloadBuilder $builder,
        protected EvaluationService $evaluationService,
    ) {
    }

    /** @return array{ok: bool, message: string, counts?: array} */
    public function push(bool $withPasswords = false): array
    {
        $log = SatelliteSyncLog::create([
            'direction' => 'push', 'status' => 'failed', 'started_at' => now(),
            'sync_id' => now()->utc()->format('Ymd\THis\Z') . '-' . Str::lower(Str::random(4)),
        ]);

        try {
            $this->client->ping();

            $payload = $this->builder->build($withPasswords);
            $chunkSize = max(1, (int) config('satellite.answers_chunk', 3000));
            $sent = 0;

            // Request 1: semua tabel kecuali answer; mode full agar tabel penugasan di-prune di satelit.
            $first = $this->client->snapshot([
                'sync_id' => $log->sync_id . '-0',
                'mode' => 'full',
                'data' => $payload['data'],
                'prune' => $payload['prune'],
            ]);
            $this->assertOk($first, 'snapshot');
            $sent += array_sum(array_map('count', $payload['data']));

            // Request berikutnya: answer per potongan (delta, tanpa prune).
            foreach (array_chunk($payload['answers'], $chunkSize) as $i => $chunk) {
                $res = $this->client->snapshot([
                    'sync_id' => $log->sync_id . '-a' . ($i + 1),
                    'mode' => 'delta',
                    'data' => ['answer' => $chunk],
                ]);
                $this->assertOk($res, 'snapshot answer');
                $sent += count($chunk);
            }

            $log->update([
                'status' => 'ok', 'rows_sent' => $sent, 'finished_at' => now(),
                'message' => 'Snapshot terkirim.', 'details' => ['counts' => $payload['counts'], 'with_passwords' => $withPasswords],
            ]);

            return ['ok' => true, 'message' => "Snapshot terkirim ({$sent} baris).", 'counts' => $payload['counts']];
        } catch (Throwable $e) {
            $log->update(['status' => 'failed', 'finished_at' => now(), 'message' => Str::limit($e->getMessage(), 1000)]);

            return ['ok' => false, 'message' => $e->getMessage()];
        }
    }

    /** @return array{ok: bool, message: string, applied?: int, rejected?: int, failed?: int} */
    public function pull(): array
    {
        $log = SatelliteSyncLog::create(['direction' => 'pull', 'status' => 'failed', 'started_at' => now()]);

        $received = $applied = $rejected = $failed = 0;
        $details = [];

        try {
            $maxPages = max(1, (int) config('satellite.max_pull_pages', 50));

            for ($page = 0; $page < $maxPages; $page++) {
                $response = $this->client->scores();
                $this->assertOk($response, 'scores');

                $items = (array) ($response['items'] ?? []);
                if ($items === []) {
                    break;
                }

                $acks = [];
                foreach ($items as $item) {
                    $received++;
                    $ref = $this->describe($item);

                    try {
                        $result = $this->applyScore((array) $item);
                    } catch (Throwable $e) {
                        // Kegagalan sementara (mis. DB): jangan di-ack supaya ditarik lagi di siklus berikutnya.
                        $failed++;
                        $details[] = $ref + ['status' => 'failed', 'reason' => Str::limit($e->getMessage(), 300)];
                        report($e);
                        continue;
                    }

                    if ($result->ok) {
                        $applied++;
                    } else {
                        // Penolakan bersifat tetap (terkunci, tenggat lewat, tidak ditugaskan, data tidak valid).
                        // Tetap di-ack agar satelit berhenti mengirim ulang dan tidak menyumbat antrean.
                        $rejected++;
                        $details[] = $ref + ['status' => 'rejected', 'reason' => $result->message];
                    }

                    $acks[] = [
                        'type' => $item['type'],
                        'parent_id' => $item['parent_id'],
                        'id_user' => (int) $item['id_user'],
                        'revision' => (int) $item['revision'],
                    ];
                }

                if ($acks !== []) {
                    $this->assertOk($this->client->ack($acks), 'ack');
                }

                if (! ($response['has_more'] ?? false) || $acks === []) {
                    break;
                }
            }

            $status = $failed > 0 ? 'partial' : 'ok';
            $message = "Diterima {$received}, tersimpan {$applied}, ditolak {$rejected}, gagal {$failed}.";
            $log->update([
                'status' => $status, 'rows_received' => $received, 'rows_applied' => $applied,
                'rows_rejected' => $rejected, 'rows_failed' => $failed, 'finished_at' => now(),
                'message' => $message, 'details' => $details ?: null,
            ]);

            return ['ok' => $failed === 0, 'message' => $message, 'applied' => $applied, 'rejected' => $rejected, 'failed' => $failed];
        } catch (Throwable $e) {
            $log->update([
                'status' => 'failed', 'rows_received' => $received, 'rows_applied' => $applied,
                'rows_rejected' => $rejected, 'rows_failed' => $failed, 'finished_at' => now(),
                'message' => Str::limit($e->getMessage(), 1000), 'details' => $details ?: null,
            ]);

            return ['ok' => false, 'message' => $e->getMessage()];
        }
    }

    /**
     * Validasi ulang satu nilai dari satelit lalu simpan lewat EvaluationService.
     *
     * @param  array<string, mixed>  $item
     */
    public function applyScore(array $item): EvaluationResult
    {
        $type = $item['type'] ?? null;
        $parentId = $item['parent_id'] ?? null;
        $userId = $item['id_user'] ?? null;

        if (! in_array($type, ['visitasi', 'interview'], true) || $parentId === null || ! is_numeric($userId)) {
            return EvaluationResult::rejected('Format nilai dari satelit tidak valid.');
        }

        $user = User::role(SatellitePayloadBuilder::EXTERNAL_ROLE)->find((int) $userId);
        if (! $user) {
            return EvaluationResult::rejected('Pengguna bukan penilai eksternal aktif.');
        }

        $score = $item['score'] ?? null;
        if ($score !== null && (! is_numeric($score) || $score < 0 || $score > 100)) {
            return EvaluationResult::rejected('Nilai harus berupa angka 0-100.');
        }
        $score = $score === null ? null : (float) $score;

        $note = isset($item['catatan']) ? (string) $item['catatan'] : null;
        $isDraft = (bool) ($item['is_draft'] ?? true);
        $submit = ! $isDraft;

        try {
            if ($type === 'visitasi') {
                // Visitasi: nilai dan catatan selalu wajib (sama seperti form di pusat).
                if ($score === null || $note === null || trim($note) === '') {
                    return EvaluationResult::rejected('Nilai dan catatan visitasi wajib diisi.');
                }

                return $this->evaluationService->saveVisitasiScore((string) $parentId, (int) $userId, $score, $note, $isDraft, $submit);
            }

            if (! is_numeric($parentId)) {
                return EvaluationResult::rejected('ID wawancara tidak valid.');
            }

            return $this->evaluationService->saveInterviewScore((int) $parentId, (int) $userId, $score, $note, $isDraft, $submit);
        } catch (ModelNotFoundException) {
            return EvaluationResult::rejected('Data penilaian tidak ditemukan di pusat.');
        }
    }

    /** @param  array<string, mixed>  $response */
    private function assertOk(array $response, string $what): void
    {
        if (($response['ok'] ?? false) !== true) {
            throw new SatelliteException("Satelit membalas gagal pada {$what}.");
        }
    }

    private function describe(mixed $item): array
    {
        $item = (array) $item;

        return [
            'type' => $item['type'] ?? null,
            'parent_id' => $item['parent_id'] ?? null,
            'id_user' => $item['id_user'] ?? null,
            'revision' => $item['revision'] ?? null,
        ];
    }
}
