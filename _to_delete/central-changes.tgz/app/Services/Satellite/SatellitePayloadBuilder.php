<?php

namespace App\Services\Satellite;

use App\Models\User;
use Illuminate\Support\Facades\DB;

/**
 * Menyusun snapshot data yang dikirim ke satelit: HANYA penugasan penilai eksternal dan data yang
 * dibutuhkan untuk menilai/melihatnya. Tidak pernah mengirim nilai/catatan evaluator lain,
 * skor jawaban SAQ, atau akun internal.
 */
class SatellitePayloadBuilder
{
    public const EXTERNAL_ROLE = 'penilai_eksternal';

    /** Tabel penugasan: dikirim lengkap dan di-prune di satelit agar penugasan yang dicabut hilang. */
    public const PRUNE_TABLES = ['submission_evaluators', 'visitasi_evaluators', 'interview_evaluators'];

    /**
     * @return array{data: array<string, array>, answers: array, prune: array<int, string>, counts: array<string, int>}
     */
    public function build(bool $withPasswords = false): array
    {
        $users = User::withTrashed()->role(self::EXTERNAL_ROLE)->get();

        $usersPayload = [];
        $activeIds = [];
        foreach ($users as $u) {
            $active = ! $u->trashed();
            $row = [
                'id_user' => (int) $u->id_user,
                'name' => $u->name,
                'nama_user' => $u->nama_user,
                'email' => $u->email,
                'is_active' => $active,
            ];
            // Hash kata sandi hanya dikirim bila diminta eksplisit (akun baru / reset), agar kata sandi
            // yang diganti penilai di satelit tidak tertimpa pada siklus biasa.
            if ($withPasswords && is_string($u->password) && str_starts_with($u->password, '$2y$')) {
                $row['password_hash'] = $u->password;
            }
            $usersPayload[] = $row;
            if ($active) {
                $activeIds[] = (int) $u->id_user;
            }
        }

        $subEval = $activeIds ? DB::table('submission_evaluators')->whereIn('id_user', $activeIds)->get(['id_submission', 'id_user']) : collect();
        $visitEval = $activeIds ? DB::table('visitasi_evaluators')->whereIn('id_user', $activeIds)->get(['id_visit', 'id_user', 'score', 'catatan', 'is_draft']) : collect();
        $interviewEval = $activeIds ? DB::table('interview_evaluators')->whereIn('id_user', $activeIds)->get(['id_interview', 'id_user', 'score', 'catatan', 'is_draft']) : collect();

        $visitIds = $visitEval->pluck('id_visit')->unique()->values()->all();
        $interviewIds = $interviewEval->pluck('id_interview')->unique()->values()->all();
        $assignedSubIds = $subEval->pluck('id_submission')->unique()->values()->all();

        $visitasi = $visitIds ? DB::table('visitasi')->whereIn('id_visit', $visitIds)
            ->get(['id_visit', 'id_result', 'visit_mode', 'link_meet_visitasi', 'visit_at', 'link_buktidukung', 'visit_score']) : collect();
        $interview = $interviewIds ? DB::table('interview')->whereIn('id_interview', $interviewIds)
            ->get(['id_interview', 'id_result', 'link_meet_interview', 'interview_at', 'interview_score']) : collect();

        $assignedSubs = $assignedSubIds ? DB::table('submissions')->whereIn('id_submission', $assignedSubIds)->get(['id_submission', 'id_result']) : collect();

        $resultIds = collect()
            ->merge($assignedSubs->pluck('id_result'))
            ->merge($visitasi->pluck('id_result'))
            ->merge($interview->pluck('id_result'))
            ->filter()->unique()->values()->all();

        $results = $resultIds ? DB::table('result')->whereIn('id_result', $resultIds)->get(['id_result', 'kode_satker', 'id_periode']) : collect();

        $submissions = ($resultIds || $assignedSubIds)
            ? DB::table('submissions')
                ->where(function ($q) use ($resultIds, $assignedSubIds) {
                    if ($resultIds) {
                        $q->whereIn('id_result', $resultIds);
                    }
                    if ($assignedSubIds) {
                        $q->orWhereIn('id_submission', $assignedSubIds);
                    }
                })
                ->get(['id_submission', 'id_result', 'status'])
            : collect();

        $periodIds = $results->pluck('id_periode')->filter()->unique()->values()->all();
        $periods = $periodIds ? DB::table('periods')->whereIn('id_periode', $periodIds)->get([
            'id_periode', 'periode_start', 'periode_end', 'saq_start', 'saq_end', 'eval_start', 'eval_end',
            'visit_start', 'visit_end', 'interview_start', 'interview_end', 'result_start', 'result_end',
        ]) : collect();

        $satkerCodes = $results->pluck('kode_satker')->filter()->unique()->values()->all();
        $satkers = $satkerCodes ? DB::table('master_satker')->whereIn('kode_satker', $satkerCodes)->get(['kode_satker', 'nama_satker']) : collect();

        $answers = $assignedSubIds
            ? DB::table('answer')->whereIn('id_submission', $assignedSubIds)
                ->get(['id_answer', 'id_submission', 'id_question', 'id_indicators', 'answer', 'link_ppid', 'link_drive'])
                ->map(function ($a) {
                    $a = (array) $a;
                    $a['answer'] = $a['answer'] === null ? null : (bool) $a['answer'];

                    return $a;
                })->all()
            : [];

        $data = [
            'users' => $usersPayload,
            'periods' => $this->rows($periods),
            'master_satker' => $this->rows($satkers),
            'master_indikator' => $this->rows(DB::table('master_indikator')->get(['id_indicators', 'nama_indikator', 'deskripsi_indikator'])),
            'master_sub_indikator' => $this->rows(DB::table('master_sub_indikator')->get(['id_sub_indicators', 'id_indicators', 'nama_sub_indikator'])),
            'master_pertanyaan' => $this->rows(DB::table('master_pertanyaan')->get([
                'id_master_pertanyaan', 'order_no', 'id_sub_indicators', 'id_indicators', 'ques_text', 'ques_description',
                'doc_requirement', 'link_drive', 'link_ppid', 'bobot_pertanyaan',
            ])),
            'result' => $this->rows($results),
            'submissions' => $this->rows($submissions),
            'submission_evaluators' => $this->rows($subEval),
            'visitasi' => $visitasi->map(function ($v) {
                $row = (array) $v;
                $row['is_final'] = $row['visit_score'] !== null;
                unset($row['visit_score']);

                return $row;
            })->values()->all(),
            'interview' => $interview->map(function ($i) {
                $row = (array) $i;
                $row['is_final'] = $row['interview_score'] !== null;
                unset($row['interview_score']);

                return $row;
            })->values()->all(),
            'visitasi_evaluators' => $visitEval->map(fn ($r) => $this->evaluatorRow((array) $r))->values()->all(),
            'interview_evaluators' => $interviewEval->map(fn ($r) => $this->evaluatorRow((array) $r))->values()->all(),
        ];

        $counts = array_map('count', $data);
        $counts['answer'] = count($answers);

        return [
            'data' => $data,
            'answers' => $answers,
            'prune' => self::PRUNE_TABLES,
            'counts' => $counts,
        ];
    }

    /** @param  \Illuminate\Support\Collection<int, object>  $rows */
    private function rows($rows): array
    {
        return $rows->map(fn ($r) => (array) $r)->values()->all();
    }

    private function evaluatorRow(array $r): array
    {
        $r['score'] = $r['score'] === null ? null : (float) $r['score'];
        $r['is_draft'] = (bool) $r['is_draft'];

        return $r;
    }
}
