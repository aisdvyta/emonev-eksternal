<?php

namespace App\Services;

use App\Models\Interview;
use App\Models\InterviewEvaluator;
use App\Models\Submission;
use App\Models\Visitasi;
use App\Models\VisitasiEvaluator;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

/**
 * Satu-satunya tempat aturan simpan-nilai tahap Visitasi & Wawancara:
 * cek tahap/tenggat, simpan nilai per penilai, hitung rata-rata, finalisasi, dan syncResult.
 *
 * Dipakai oleh VisitasiController, WawancaraController, dan SatelliteSyncService
 * (nilai dari portal satelit penilai eksternal) agar logika finalisasi tidak ada dua versi.
 */
class EvaluationService
{
    /** Batas kolom visitasi.visit_note (string 255). */
    private const VISIT_NOTE_MAX = 255;

    public function __construct(protected PenilaianService $penilaianService)
    {
    }

    // ------------------------------------------------------------------
    // Pengecekan tahap / tenggat
    // ------------------------------------------------------------------

    /**
     * Alasan Visitasi tidak boleh dinilai/diubah sekarang, atau null jika boleh.
     * Urutan pengecekan dan teks pesan identik dengan VisitasiController::saveReview versi lama.
     */
    public function visitasiLockReason(Visitasi $visitasi): ?string
    {
        $visitasi->loadMissing(['result.period', 'result.submission']);
        $submission = $visitasi->submission;

        if (! $submission || $submission->status < 5 || $submission->status == 8) {
            return 'Submission tidak dalam tahap visitasi.';
        }
        if ($submission->status >= 7) {
            return 'Tahapan penilaian akhir untuk submission ini telah selesai dan tidak dapat diubah lagi.';
        }

        if ($visitasi->visit_score !== null) {
            return 'Penilaian visitasi ini telah difinalisasi dan tidak dapat diubah lagi.';
        }

        $period = $visitasi->period;
        $visitStart = $period?->visit_start ? Carbon::parse($period->visit_start)->startOfDay() : null;
        if ($visitStart && now()->startOfDay()->lt($visitStart)) {
            return 'Tahapan visitasi belum dimulai. Penilaian baru dapat dilakukan mulai tanggal ' . $visitStart->translatedFormat('d M Y') . '.';
        }

        $visitEnd = $period?->visit_end ? Carbon::parse($period->visit_end)->endOfDay() : null;
        if ($visitEnd && now()->greaterThan($visitEnd)) {
            return 'Batas waktu pengisian/pengeditan nilai visitasi periode ini telah berakhir pada tanggal ' . $visitEnd->translatedFormat('d M Y') . '.';
        }

        $visitMode = $visitasi->visit_mode ?? 'offline';
        if ($visitMode !== 'online_upload') {
            $visitDate = $visitasi->visit_at ? Carbon::parse($visitasi->visit_at)->startOfDay() : null;
            if (! $visitDate || now()->startOfDay()->lt($visitDate)) {
                return 'Penilaian visitasi hanya dapat dilakukan pada atau setelah tanggal kunjungan yang dijadwalkan.';
            }
        }

        return null;
    }

    /**
     * Alasan Wawancara tidak boleh dinilai/diubah sekarang, atau null jika boleh.
     * Urutan pengecekan dan teks pesan identik dengan WawancaraController::saveReview versi lama.
     */
    public function interviewLockReason(Interview $interview): ?string
    {
        $interview->loadMissing(['result.period', 'result.submission']);
        $submission = $interview->submission;

        if (! $submission || $submission->status < 5 || $submission->status == 8) {
            return 'Submission tidak dalam tahap wawancara.';
        }

        if ($submission->status >= 7) {
            return 'Tahapan penilaian akhir untuk submission ini telah selesai dan tidak dapat diubah lagi.';
        }

        if ($interview->interview_score !== null) {
            return 'Penilaian wawancara ini telah difinalisasi dan tidak dapat diubah lagi.';
        }

        $period = $interview->period;
        $interviewStart = $period?->interview_start ? Carbon::parse($period->interview_start)->startOfDay() : null;
        if ($interviewStart && now()->startOfDay()->lt($interviewStart)) {
            return 'Tahapan wawancara belum dimulai. Penilaian baru dapat dilakukan mulai tanggal ' . $interviewStart->translatedFormat('d M Y') . '.';
        }

        $interviewEnd = $period?->interview_end ? Carbon::parse($period->interview_end)->endOfDay() : null;
        if ($interviewEnd && now()->greaterThan($interviewEnd)) {
            return 'Batas waktu pengisian/pengeditan nilai wawancara periode ini telah berakhir pada tanggal ' . $interviewEnd->translatedFormat('d M Y') . '.';
        }

        $interviewDate = $interview->interview_at ? Carbon::parse($interview->interview_at)->startOfDay() : null;
        if (! $interviewDate || now()->startOfDay()->lt($interviewDate)) {
            return 'Penilaian hanya dapat dilakukan pada atau setelah jadwal wawancara.';
        }

        return null;
    }

    // ------------------------------------------------------------------
    // Visitasi
    // ------------------------------------------------------------------

    /**
     * Simpan nilai satu penilai pada Visitasi (draft atau submit) dan finalisasi bila semua penilai sudah submit.
     *
     * @param  bool  $isDraft  nilai disimpan sebagai draft (action = draft)
     * @param  bool  $submit   penilai menekan kirim (action = submit) → boleh memicu finalisasi
     */
    public function saveVisitasiScore(string $visitId, int $userId, float $score, ?string $note, bool $isDraft, bool $submit): EvaluationResult
    {
        return DB::transaction(function () use ($visitId, $userId, $score, $note, $isDraft, $submit) {
            $visitasi = Visitasi::with(['result.period', 'result.submission'])->lockForUpdate()->findOrFail($visitId);

            if ($reason = $this->visitasiLockReason($visitasi)) {
                return EvaluationResult::rejected($reason);
            }

            $assigned = VisitasiEvaluator::where('id_visit', $visitasi->id_visit)->where('id_user', $userId)->exists();
            if (! $assigned) {
                return EvaluationResult::rejected('Anda tidak ditugaskan sebagai verifikator untuk visitasi ini.');
            }

            VisitasiEvaluator::updateOrCreate(
                ['id_visit' => $visitasi->id_visit, 'id_user' => $userId],
                ['score' => $score, 'catatan' => $note, 'is_draft' => $isDraft]
            );

            $rows = VisitasiEvaluator::where('id_visit', $visitasi->id_visit)->get();
            $submitted = $rows->filter(fn ($ev) => $ev->score !== null && ! $ev->is_draft);

            if ($submit) {
                if ($submitted->count() < $rows->count()) {
                    $visitasi->visit_score = null;
                    $visitasi->visit_note = null;
                    $visitasi->save();

                    return EvaluationResult::ok('Penilaian Anda berhasil disubmit. Menunggu penilaian dari evaluator lain.');
                }

                $avg = round($submitted->pluck('score')->average(), 2);

                $visitasi->visit_score = $avg;
                $visitasi->visit_note = mb_substr($rows->pluck('catatan')->filter()->implode('; '), 0, self::VISIT_NOTE_MAX);
                $visitasi->save();

                $visitasi->result->update(['visit_score' => $avg]);
                $this->penilaianService->syncResult($visitasi->submission);

                return EvaluationResult::ok('Hasil visitasi berhasil difinalisasi. Rata-rata nilai: ' . $avg, true, $avg);
            }

            $visitasi->visit_score = null;
            $visitasi->visit_note = null;
            $visitasi->save();

            return EvaluationResult::ok('Draft hasil visitasi berhasil disimpan.');
        });
    }

    // ------------------------------------------------------------------
    // Wawancara
    // ------------------------------------------------------------------

    /**
     * Simpan nilai satu penilai pada Wawancara (jalur non-form, mis. dari satelit).
     * Aturan sama dengan jalur form: nilai & catatan wajib hanya saat submit (bukan draft).
     */
    public function saveInterviewScore(int $interviewId, int $userId, ?float $score, ?string $note, bool $isDraft, bool $submit): EvaluationResult
    {
        return DB::transaction(function () use ($interviewId, $userId, $score, $note, $isDraft, $submit) {
            $interview = Interview::with(['result.period', 'result.submission'])->lockForUpdate()->findOrFail($interviewId);

            if ($reason = $this->interviewLockReason($interview)) {
                return EvaluationResult::rejected($reason);
            }

            $assigned = InterviewEvaluator::where('id_interview', $interview->id_interview)->where('id_user', $userId)->exists();
            if (! $assigned) {
                return EvaluationResult::rejected('Anda tidak ditugaskan sebagai pewawancara untuk satker ini.');
            }

            $isDraft = $isDraft || $score === null;

            if (! $isDraft) {
                if ($score < 0 || $score > 100) {
                    return EvaluationResult::rejected('Nilai wawancara harus berupa angka 0-100.');
                }
                if ($note === null || trim($note) === '') {
                    return EvaluationResult::rejected('Catatan wawancara wajib diisi sebelum mengirim penilaian.');
                }
            }

            InterviewEvaluator::updateOrCreate(
                ['id_interview' => $interview->id_interview, 'id_user' => $userId],
                ['score' => $score, 'catatan' => $note === null ? null : mb_substr($note, 0, 5000), 'is_draft' => $isDraft]
            );

            $data = InterviewEvaluator::where('id_interview', $interview->id_interview)->get()
                ->map(fn ($ev) => ['id_user' => $ev->id_user, 'score' => $ev->score, 'note' => $ev->catatan, 'is_draft' => (bool) $ev->is_draft])
                ->all();

            return $this->finalizeInterview($interview, $interview->submission, $data, $submit);
        });
    }

    /**
     * Hitung rata-rata & finalisasi Wawancara dari daftar nilai penilai.
     * Dipanggil di dalam transaksi pemanggil, setelah nilai penilai tersimpan.
     *
     * @param  array<int, array{score?: mixed, is_draft?: mixed}>  $data  seluruh penilai wawancara (termasuk yang belum menilai)
     * @param  bool  $finalizeRequested  true bila pengguna menekan kirim (atau super evaluator menyimpan nilai eksternal)
     */
    public function finalizeInterview(Interview $interview, Submission $submission, array $data, bool $finalizeRequested): EvaluationResult
    {
        $submitted = collect($data)->filter(fn ($ev) => isset($ev['score']) && ! ($ev['is_draft'] ?? false))->pluck('score');
        $totalAssigned = count($data);

        if ($finalizeRequested) {
            if ($submitted->count() < $totalAssigned) {
                $interview->interview_score = null;
                $interview->save();

                return EvaluationResult::ok('Penilaian berhasil disubmit. Menunggu pewawancara lain selesai.');
            }

            $avg = round($submitted->average(), 2);
            $interview->interview_score = $avg;
            $interview->save();

            $interview->result->update(['interview_score' => $avg]);

            if ($submission->status == 5) {
                $submission->update(['status' => 6]);
            }

            $this->penilaianService->syncResult($submission);

            return EvaluationResult::ok('Wawancara berhasil dinilai. Seluruh pewawancara telah mengisi nilai. Rata-rata: ' . $avg, true, $avg);
        }

        $interview->interview_score = null;
        $interview->save();

        return EvaluationResult::ok('Draft penilaian wawancara berhasil disimpan.');
    }
}
