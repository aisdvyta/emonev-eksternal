<?php

namespace App\Console\Commands;

use App\Services\Satellite\SatelliteSyncService;
use Illuminate\Console\Command;

class SatellitePull extends Command
{
    protected $signature = 'satellite:pull';
    protected $description = 'Ambil nilai penilai eksternal dari portal satelit, simpan di pusat, lalu ack';

    public function handle(SatelliteSyncService $sync): int
    {
        $res = $sync->pull();
        $res['ok'] ? $this->info($res['message']) : $this->error($res['message']);

        return $res['ok'] ? self::SUCCESS : self::FAILURE;
    }
}
