<?php

namespace App\Console\Commands;

use App\Services\Satellite\SatelliteSyncService;
use Illuminate\Console\Command;

class SatellitePush extends Command
{
    protected $signature = 'satellite:push {--with-passwords : Sertakan hash kata sandi akun eksternal (pakai hanya setelah akun dibuat/direset)}';
    protected $description = 'Kirim penugasan penilai eksternal ke portal satelit';

    public function handle(SatelliteSyncService $sync): int
    {
        $res = $sync->push((bool) $this->option('with-passwords'));
        $res['ok'] ? $this->info($res['message']) : $this->error($res['message']);

        return $res['ok'] ? self::SUCCESS : self::FAILURE;
    }
}
