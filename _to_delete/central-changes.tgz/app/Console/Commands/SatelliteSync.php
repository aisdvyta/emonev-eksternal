<?php

namespace App\Console\Commands;

use App\Services\Satellite\SatelliteSyncService;
use Illuminate\Console\Command;

class SatelliteSync extends Command
{
    protected $signature = 'satellite:sync {--with-passwords : Sertakan hash kata sandi akun eksternal pada push}';
    protected $description = 'Satu siklus sinkronisasi dengan portal satelit: push penugasan, lalu pull nilai';

    public function handle(SatelliteSyncService $sync): int
    {
        if (! config('satellite.enabled')) {
            $this->warn('Sinkronisasi satelit nonaktif (SATELLITE_ENABLED=false).');

            return self::SUCCESS;
        }

        $push = $sync->push((bool) $this->option('with-passwords'));
        $push['ok'] ? $this->info('push: ' . $push['message']) : $this->error('push: ' . $push['message']);

        // Pull tetap dicoba walau push gagal: nilai yang sudah diisi penilai jangan tertahan.
        $pull = $sync->pull();
        $pull['ok'] ? $this->info('pull: ' . $pull['message']) : $this->error('pull: ' . $pull['message']);

        return ($push['ok'] && $pull['ok']) ? self::SUCCESS : self::FAILURE;
    }
}
