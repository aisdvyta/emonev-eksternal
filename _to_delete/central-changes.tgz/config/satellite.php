<?php

/*
| Sinkronisasi dengan portal satelit penilai eksternal (emonev-eksternal, di internet).
| Pusat selalu yang memulai koneksi; satelit tidak pernah memanggil pusat.
| Default: NONAKTIF. Tidak ada yang berubah sampai SATELLITE_ENABLED=true dan URL + SECRET diisi.
*/
return [
    'enabled' => (bool) env('SATELLITE_ENABLED', false),

    // Mis. https://halokip.my.id (tanpa /api/v1)
    'url' => env('SATELLITE_URL'),

    // Rahasia HMAC. Harus sama dengan SYNC_SECRET di satelit (acak, minimal 32 byte).
    'secret' => env('SATELLITE_SECRET'),

    'timeout' => (int) env('SATELLITE_TIMEOUT', 60),
    'retries' => (int) env('SATELLITE_RETRIES', 2),

    // Jadwal otomatis (menit) bila enabled.
    'schedule_minutes' => (int) env('SATELLITE_SCHEDULE_MINUTES', 10),

    // Jumlah baris `answer` per request snapshot (satelit membatasi 20.000 baris per tabel per request).
    'answers_chunk' => (int) env('SATELLITE_ANSWERS_CHUNK', 3000),

    // Batas halaman tarik nilai per satu siklus.
    'max_pull_pages' => (int) env('SATELLITE_MAX_PULL_PAGES', 50),
];
