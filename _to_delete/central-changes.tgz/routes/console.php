<?php

use Illuminate\Foundation\Inspiring;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Schedule;

Artisan::command('inspire', function () {
    $this->comment(Inspiring::quote());
})->purpose('Display an inspiring quote');


// Sinkronisasi portal satelit penilai eksternal (aktif hanya jika SATELLITE_ENABLED=true).
if (config('satellite.enabled')) {
    Schedule::command('satellite:sync')
        ->cron('*/' . max(1, (int) config('satellite.schedule_minutes', 10)) . ' * * * *')
        ->withoutOverlapping(30);
}
