<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('satellite_sync_logs')) {
            return;
        }

        Schema::create('satellite_sync_logs', function (Blueprint $table) {
            $table->id();
            $table->string('direction', 10);          // push | pull
            $table->string('status', 10);             // ok | partial | failed
            $table->string('sync_id', 64)->nullable();
            $table->unsignedInteger('rows_sent')->default(0);
            $table->unsignedInteger('rows_received')->default(0);
            $table->unsignedInteger('rows_applied')->default(0);
            $table->unsignedInteger('rows_rejected')->default(0);
            $table->unsignedInteger('rows_failed')->default(0);
            $table->text('message')->nullable();
            $table->json('details')->nullable();
            $table->dateTime('started_at')->nullable();
            $table->dateTime('finished_at')->nullable();

            $table->index(['direction', 'started_at']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('satellite_sync_logs');
    }
};
