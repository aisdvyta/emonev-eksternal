<?php

namespace Tests\Feature\Satellite;

use App\Models\Answer;
use App\Models\Interview;
use App\Models\Result;
use App\Models\SatelliteSyncLog;
use App\Models\Submission;
use App\Models\User;
use App\Models\Visitasi;
use App\Services\Satellite\SatelliteClient;
use App\Services\Satellite\SatellitePayloadBuilder;
use App\Services\Satellite\SatelliteSyncService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\Client\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Tests\Concerns\SeedsEvaluationStage;
use Tests\TestCase;

class SatelliteSyncTest extends TestCase
{
    use RefreshDatabase;
    use SeedsEvaluationStage;

    private const SECRET = 'rahasia-uji-satelit-0123456789abcdef';

    protected function setUp(): void
    {
        parent::setUp();
        config([
            'satellite.enabled' => true,
            'satellite.url' => 'https://satelit.test',
            'satellite.secret' => self::SECRET,
            'satellite.retries' => 0,
        ]);
    }

    private function score(string $type, $parent, int $userId, $score, ?string $note, bool $draft = false, int $rev = 1): array
    {
        return ['type' => $type, 'parent_id' => $parent, 'id_user' => $userId, 'score' => $score,
            'catatan' => $note, 'is_draft' => $draft, 'revision' => $rev, 'saved_at' => now()->toIso8601String()];
    }

    private function sync(): SatelliteSyncService
    {
        return app(SatelliteSyncService::class);
    }

    // ---------------------------------------------------------------- tanda tangan

    public function test_requests_are_signed_per_contract(): void
    {
        Http::fake(['satelit.test/*' => Http::response(['ok' => true, 'items' => []])]);

        app(SatelliteClient::class)->scores();

        Http::assertSent(function (Request $r) {
            $ts = $r->header('X-Sync-Timestamp')[0] ?? '';
            $nonce = $r->header('X-Sync-Nonce')[0] ?? '';
            $sig = $r->header('X-Sync-Signature')[0] ?? '';
            $canonical = implode("\n", ['GET', '/api/v1/sync/scores', $ts, $nonce, hash('sha256', '')]);

            return $r->method() === 'GET'
                && $r->url() === 'https://satelit.test/api/v1/sync/scores'
                && strlen($nonce) >= 16
                && abs(time() - (int) $ts) < 5
                && hash_equals('v1=' . hash_hmac('sha256', $canonical, self::SECRET), $sig);
        });
    }

    public function test_post_signature_covers_body_hash(): void
    {
        Http::fake(['satelit.test/*' => Http::response(['ok' => true, 'acked' => 1])]);

        app(SatelliteClient::class)->ack([['type' => 'visitasi', 'parent_id' => 'x', 'id_user' => 1, 'revision' => 2]]);

        Http::assertSent(function (Request $r) {
            $canonical = implode("\n", ['POST', '/api/v1/sync/ack', $r->header('X-Sync-Timestamp')[0], $r->header('X-Sync-Nonce')[0], hash('sha256', $r->body())]);

            return hash_equals('v1=' . hash_hmac('sha256', $canonical, self::SECRET), $r->header('X-Sync-Signature')[0])
                && str_contains($r->body(), '"revision":2');
        });
    }

    public function test_client_refuses_when_not_configured(): void
    {
        config(['satellite.url' => null]);
        Http::fake();

        $this->expectException(\App\Services\Satellite\SatelliteException::class);
        (new SatelliteClient())->ping();
    }

    // ---------------------------------------------------------------- payload

    public function test_payload_contains_only_external_assignments_and_never_other_scores(): void
    {
        $this->seedStageBase();
        $ext = $this->makeUser('penilai_eksternal', 'ext1');
        $internal = $this->makeUser('evaluator', 'ev1');
        $visit = $this->makeVisitasi([$ext, $internal]);
        $visit->evaluators()->where('id_user', $internal->id_user)->update(['score' => 99, 'catatan' => 'RAHASIA', 'is_draft' => false]);
        $visit->evaluators()->where('id_user', $ext->id_user)->update(['score' => 70, 'catatan' => 'punya ext', 'is_draft' => true]);
        $interview = $this->makeInterview([$ext]);
        $this->submission->evaluators()->attach($ext->id_user);
        $this->submission->evaluators()->attach($internal->id_user);

        $payload = app(SatellitePayloadBuilder::class)->build();
        $json = json_encode($payload);

        $this->assertStringNotContainsString('RAHASIA', $json);
        $this->assertSame([$ext->id_user], array_column($payload['data']['users'], 'id_user'));
        $this->assertSame([$ext->id_user], array_column($payload['data']['visitasi_evaluators'], 'id_user'));
        $this->assertSame([$ext->id_user], array_column($payload['data']['submission_evaluators'], 'id_user'));
        $this->assertSame(70.0, $payload['data']['visitasi_evaluators'][0]['score']);
        $this->assertTrue($payload['data']['visitasi_evaluators'][0]['is_draft']);
        $this->assertFalse($payload['data']['visitasi'][0]['is_final']);
        $this->assertSame(SatellitePayloadBuilder::PRUNE_TABLES, $payload['prune']);
        $this->assertSame($this->period->id_periode, $payload['data']['periods'][0]['id_periode']);
        $this->assertSame('3578', $payload['data']['master_satker'][0]['kode_satker']);
        $this->assertSame($this->submission->id_submission, $payload['data']['submissions'][0]['id_submission']);
        $this->assertSame($interview->id_interview, $payload['data']['interview'][0]['id_interview']);
    }

    public function test_payload_marks_finalized_stage_and_never_includes_answer_scores(): void
    {
        $this->seedStageBase();
        $ext = $this->makeUser('penilai_eksternal', 'ext1');
        $visit = $this->makeVisitasi([$ext]);
        $visit->forceFill(['visit_score' => 80])->save();
        $this->submission->evaluators()->attach($ext->id_user);

        DB::table('master_indikator')->insert(['id_indicators' => 1, 'nama_indikator' => 'Ind']);
        DB::table('master_pertanyaan')->insert(['id_master_pertanyaan' => 1, 'id_indicators' => 1, 'ques_text' => 'Q?']);
        Answer::create(['id_submission' => $this->submission->id_submission, 'id_question' => 1, 'id_indicators' => 1, 'answer' => true]);
        DB::table('answer')->update(['answer_score' => 5, 'evaluator_note' => 'CATATAN-EVALUATOR', 'verifikator_note' => 'CATATAN-VERIF']);

        $payload = app(SatellitePayloadBuilder::class)->build();
        $json = json_encode($payload);

        $this->assertTrue($payload['data']['visitasi'][0]['is_final']);
        $this->assertCount(1, $payload['answers']);
        $this->assertTrue($payload['answers'][0]['answer']);
        $this->assertStringNotContainsString('answer_score', $json);
        $this->assertStringNotContainsString('CATATAN-EVALUATOR', $json);
        $this->assertStringNotContainsString('CATATAN-VERIF', $json);
        $this->assertStringNotContainsString('visit_score', $json);
    }

    public function test_password_hash_only_when_requested_and_trashed_user_is_inactive(): void
    {
        $this->seedStageBase();
        $ext = $this->makeUser('penilai_eksternal', 'ext1');
        $gone = $this->makeUser('penilai_eksternal', 'ext2');
        $gone->delete();

        $plain = app(SatellitePayloadBuilder::class)->build();
        $withPw = app(SatellitePayloadBuilder::class)->build(true);

        $this->assertArrayNotHasKey('password_hash', $plain['data']['users'][0]);
        $byId = collect($withPw['data']['users'])->keyBy('id_user');
        $this->assertStringStartsWith('$2y$', $byId[$ext->id_user]['password_hash']);
        $this->assertFalse($byId[$gone->id_user]['is_active']);
        $this->assertTrue($byId[$ext->id_user]['is_active']);
    }

    public function test_non_external_users_are_never_exported(): void
    {
        $this->seedStageBase();
        $this->makeUser('evaluator', 'ev1');
        $this->makeUser('super_evaluator', 'sev');

        $this->assertSame([], app(SatellitePayloadBuilder::class)->build()['data']['users']);
    }

    // ---------------------------------------------------------------- push

    public function test_push_sends_full_snapshot_then_answer_chunks_and_logs(): void
    {
        $this->seedStageBase();
        config(['satellite.answers_chunk' => 2]);
        $ext = $this->makeUser('penilai_eksternal', 'ext1');
        $this->submission->evaluators()->attach($ext->id_user);
        DB::table('master_indikator')->insert(['id_indicators' => 1, 'nama_indikator' => 'Ind']);
        for ($q = 1; $q <= 5; $q++) {
            DB::table('master_pertanyaan')->insert(['id_master_pertanyaan' => $q, 'id_indicators' => 1, 'ques_text' => "Q$q"]);
            Answer::create(['id_submission' => $this->submission->id_submission, 'id_question' => $q, 'id_indicators' => 1, 'answer' => true]);
        }
        Http::fake(['satelit.test/*' => Http::response(['ok' => true])]);

        $res = $this->sync()->push();

        $this->assertTrue($res['ok'], $res['message']);
        $snapshots = Http::recorded(fn (Request $r) => str_ends_with($r->url(), '/sync/snapshot'))->values();
        $this->assertCount(1 + 3, $snapshots); // 1 full + 3 potongan answer (2+2+1)
        $first = $snapshots[0][0]->data();
        $this->assertSame('full', $first['mode']);
        $this->assertSame(SatellitePayloadBuilder::PRUNE_TABLES, $first['prune']);
        $this->assertArrayNotHasKey('answer', $first['data']);
        $this->assertSame('delta', $snapshots[1][0]->data()['mode']);
        $this->assertCount(2, $snapshots[1][0]->data()['data']['answer']);
        $this->assertSame('ok', SatelliteSyncLog::first()->status);
    }

    public function test_push_failure_is_logged_and_does_not_throw(): void
    {
        $this->seedStageBase();
        Http::fake(['satelit.test/*' => Http::response(['ok' => false, 'error' => 'bad_signature'], 401)]);

        $res = $this->sync()->push();

        $this->assertFalse($res['ok']);
        $log = SatelliteSyncLog::first();
        $this->assertSame('failed', $log->status);
        $this->assertNotEmpty($log->message);
    }

    // ---------------------------------------------------------------- pull

    public function test_pull_saves_final_visitasi_score_via_evaluation_service_and_acks(): void
    {
        $this->seedStageBase();
        $ext = $this->makeUser('penilai_eksternal', 'ext1');
        $visit = $this->makeVisitasi([$ext]);

        Http::fake([
            'satelit.test/api/v1/sync/scores' => Http::response(['ok' => true, 'has_more' => false, 'items' => [
                $this->score('visitasi', $visit->id_visit, $ext->id_user, 91.5, 'dari satelit', false, 3),
            ]]),
            'satelit.test/api/v1/sync/ack' => Http::response(['ok' => true, 'acked' => 1]),
        ]);

        $res = $this->sync()->pull();

        $this->assertTrue($res['ok'], $res['message']);
        $this->assertSame(1, $res['applied']);
        $this->assertEquals(91.5, $visit->fresh()->visit_score);
        $this->assertEquals(91.5, Result::find($this->result->id_result)->visit_score);
        Http::assertSent(fn (Request $r) => str_ends_with($r->url(), '/sync/ack')
            && $r->data()['items'][0]['revision'] === 3
            && $r->data()['items'][0]['parent_id'] === $visit->id_visit);
    }

    public function test_pull_interview_final_moves_status_to_6(): void
    {
        $this->seedStageBase();
        $ext = $this->makeUser('penilai_eksternal', 'ext1');
        $interview = $this->makeInterview([$ext]);

        Http::fake([
            'satelit.test/api/v1/sync/scores' => Http::response(['ok' => true, 'has_more' => false, 'items' => [
                $this->score('interview', $interview->id_interview, $ext->id_user, 77, 'ok'),
            ]]),
            'satelit.test/api/v1/sync/ack' => Http::response(['ok' => true]),
        ]);

        $this->assertTrue($this->sync()->pull()['ok']);
        $this->assertEquals(77, $interview->fresh()->interview_score);
        $this->assertEquals(6, Submission::find($this->submission->id_submission)->status);
    }

    public function test_pull_draft_is_stored_but_not_finalized(): void
    {
        $this->seedStageBase();
        $ext = $this->makeUser('penilai_eksternal', 'ext1');
        $interview = $this->makeInterview([$ext]);

        Http::fake([
            'satelit.test/api/v1/sync/scores' => Http::response(['ok' => true, 'items' => [
                $this->score('interview', $interview->id_interview, $ext->id_user, null, null, true),
            ]]),
            'satelit.test/api/v1/sync/ack' => Http::response(['ok' => true]),
        ]);

        $this->assertTrue($this->sync()->pull()['ok']);
        $this->assertNull($interview->fresh()->interview_score);
        $this->assertEquals(1, DB::table('interview_evaluators')->where('id_user', $ext->id_user)->value('is_draft'));
        $this->assertEquals(5, Submission::find($this->submission->id_submission)->status);
    }

    public function test_pull_rejections_are_revalidated_logged_and_still_acked(): void
    {
        $this->seedStageBase();
        $ext = $this->makeUser('penilai_eksternal', 'ext1');
        $other = $this->makeUser('penilai_eksternal', 'ext2');
        $internal = $this->makeUser('evaluator', 'ev1');
        $lockedVisit = $this->makeVisitasi([$ext]);
        $lockedVisit->forceFill(['visit_score' => 60])->save();
        $assignedToOther = $this->makeInterview([$other]);

        Http::fake([
            'satelit.test/api/v1/sync/scores' => Http::response(['ok' => true, 'has_more' => false, 'items' => [
                $this->score('visitasi', $lockedVisit->id_visit, $ext->id_user, 10, 'x'),               // sudah final
                $this->score('interview', $assignedToOther->id_interview, $ext->id_user, 50, 'x'),     // tidak ditugaskan
                $this->score('interview', $assignedToOther->id_interview, $internal->id_user, 50, 'x'),// bukan penilai eksternal
                $this->score('visitasi', $lockedVisit->id_visit, $ext->id_user, 150, 'x'),             // di luar 0-100
                $this->score('visitasi', 'tidak-ada', $ext->id_user, 50, 'x'),                         // data tidak ada
                $this->score('visitasi', $lockedVisit->id_visit, $ext->id_user, 50, ''),               // catatan kosong
            ]]),
            'satelit.test/api/v1/sync/ack' => Http::response(['ok' => true]),
        ]);

        $res = $this->sync()->pull();

        $this->assertSame(0, $res['applied']);
        $this->assertSame(6, $res['rejected']);
        $this->assertEquals(60, $lockedVisit->fresh()->visit_score);
        $this->assertNull(DB::table('interview_evaluators')->where('id_user', $ext->id_user)->first());
        $this->assertCount(6, SatelliteSyncLog::first()->details);
        Http::assertSent(fn (Request $r) => str_ends_with($r->url(), '/sync/ack') && count($r->data()['items']) === 6);
    }

    public function test_pull_follows_has_more_and_stops_when_nothing_to_ack(): void
    {
        $this->seedStageBase();
        $ext = $this->makeUser('penilai_eksternal', 'ext1');
        $visit = $this->makeVisitasi([$ext]);

        Http::fake([
            'satelit.test/api/v1/sync/scores' => Http::sequence()
                ->push(['ok' => true, 'has_more' => true, 'items' => [$this->score('visitasi', $visit->id_visit, $ext->id_user, 80, 'a', true)]])
                ->push(['ok' => true, 'has_more' => false, 'items' => []]),
            'satelit.test/api/v1/sync/ack' => Http::response(['ok' => true]),
        ]);

        $this->assertTrue($this->sync()->pull()['ok']);
        $this->assertCount(2, Http::recorded(fn (Request $r) => str_ends_with($r->url(), '/sync/scores')));
    }

    public function test_pull_does_not_ack_when_ack_target_unreachable_is_reported(): void
    {
        $this->seedStageBase();
        Http::fake(['satelit.test/*' => Http::response(['ok' => false], 500)]);

        $res = $this->sync()->pull();

        $this->assertFalse($res['ok']);
        $this->assertSame('failed', SatelliteSyncLog::first()->status);
    }

    // ---------------------------------------------------------------- command

    public function test_sync_command_is_a_noop_when_disabled(): void
    {
        config(['satellite.enabled' => false]);
        Http::fake();

        $this->artisan('satellite:sync')->assertExitCode(0);

        Http::assertNothingSent();
        $this->assertSame(0, SatelliteSyncLog::count());
    }
}
