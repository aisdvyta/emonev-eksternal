<?php

namespace Tests\Feature\Evaluasi;

use App\Helpers\SecureId;
use App\Models\Result;
use App\Models\Submission;
use App\Models\Visitasi;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\Concerns\SeedsEvaluationStage;
use Tests\TestCase;

/**
 * Tes karakterisasi VisitasiController::saveReview (simpan nilai, tenggat, rata-rata, finalisasi).
 */
class VisitasiReviewSaveTest extends TestCase
{
    use RefreshDatabase;
    use SeedsEvaluationStage;

    private function submitReview(Visitasi $visit, $user, array $data)
    {
        $routeName = $user->hasRole('evaluator') ? 'evaluator.review-visitasi.save' : 'penilai-eksternal.review-visitasi.save';
        $url = route($routeName, SecureId::encrypt($visit->id_visit));

        return $this->actingAs($user)->post($url, $data);
    }

    public function test_draft_is_saved_but_not_finalized(): void
    {
        $this->seedStageBase();
        $ext = $this->makeUser('penilai_eksternal', 'ext1');
        $visit = $this->makeVisitasi([$ext]);

        $res = $this->submitReview($visit, $ext, ['nilai_visitasi' => 70, 'catatan_visitasi' => 'catatan draft', 'action' => 'draft']);

        $res->assertSessionHas('success');
        $row = $this->evaluatorRow('visitasi_evaluators', 'id_visit', $visit->id_visit, $ext->id_user);
        $this->assertEquals(70, $row->score);
        $this->assertSame('catatan draft', $row->catatan);
        $this->assertEquals(1, $row->is_draft);
        $this->assertNull($visit->fresh()->visit_score);
    }

    public function test_single_evaluator_submit_finalizes_and_updates_result(): void
    {
        $this->seedStageBase();
        $ext = $this->makeUser('penilai_eksternal', 'ext1');
        $visit = $this->makeVisitasi([$ext]);

        $res = $this->submitReview($visit, $ext, ['nilai_visitasi' => 82.5, 'catatan_visitasi' => 'bagus', 'action' => 'submit']);

        $res->assertSessionHas('success');
        $visit = $visit->fresh();
        $this->assertEquals(82.5, $visit->visit_score);
        $this->assertSame('bagus', $visit->visit_note);
        $this->assertEquals(82.5, Result::find($this->result->id_result)->visit_score);
        $this->assertEquals(0, $this->evaluatorRow('visitasi_evaluators', 'id_visit', $visit->id_visit, $ext->id_user)->is_draft);
    }

    public function test_two_evaluators_finalize_only_after_both_submit_with_average(): void
    {
        $this->seedStageBase();
        $a = $this->makeUser('penilai_eksternal', 'ext1');
        $b = $this->makeUser('evaluator', 'ev1');
        $visit = $this->makeVisitasi([$a, $b]);

        $this->submitReview($visit, $a, ['nilai_visitasi' => 80, 'catatan_visitasi' => 'A', 'action' => 'submit'])
            ->assertSessionHas('success');
        $this->assertNull($visit->fresh()->visit_score);

        $this->submitReview($visit, $b, ['nilai_visitasi' => 90.55, 'catatan_visitasi' => 'B', 'action' => 'submit'])
            ->assertSessionHas('success');

        $visit = $visit->fresh();
        $this->assertEquals(85.28, round($visit->visit_score, 2));
        $this->assertStringContainsString('A', $visit->visit_note);
        $this->assertStringContainsString('B', $visit->visit_note);
        $this->assertEquals(85.28, round(Result::find($this->result->id_result)->visit_score, 2));
    }

    public function test_rejected_when_not_assigned(): void
    {
        $this->seedStageBase();
        $ext = $this->makeUser('penilai_eksternal', 'ext1');
        $other = $this->makeUser('penilai_eksternal', 'ext2');
        $visit = $this->makeVisitasi([$other]);

        $this->submitReview($visit, $ext, ['nilai_visitasi' => 70, 'catatan_visitasi' => 'x', 'action' => 'submit'])
            ->assertSessionHas('error');

        $this->assertNull($this->evaluatorRow('visitasi_evaluators', 'id_visit', $visit->id_visit, $ext->id_user));
    }

    #[\PHPUnit\Framework\Attributes\DataProvider('notVisitStageProvider')]
    public function test_rejected_when_submission_not_in_visit_stage(int $status): void
    {
        $this->seedStageBase($status);
        $ext = $this->makeUser('penilai_eksternal', 'ext1');
        $visit = $this->makeVisitasi([$ext]);

        $this->submitReview($visit, $ext, ['nilai_visitasi' => 70, 'catatan_visitasi' => 'x', 'action' => 'draft'])
            ->assertSessionHas('error');
        $this->assertNull($this->evaluatorRow('visitasi_evaluators', 'id_visit', $visit->id_visit, $ext->id_user)->score);
    }

    public static function notVisitStageProvider(): array
    {
        return ['status 4' => [4], 'status 7 selesai' => [7], 'status 8 gugur' => [8]];
    }

    public function test_rejected_when_already_finalized(): void
    {
        $this->seedStageBase();
        $ext = $this->makeUser('penilai_eksternal', 'ext1');
        $visit = $this->makeVisitasi([$ext]);
        $visit->forceFill(['visit_score' => 77])->save();

        $this->submitReview($visit, $ext, ['nilai_visitasi' => 10, 'catatan_visitasi' => 'x', 'action' => 'submit'])
            ->assertSessionHas('error');
        $this->assertEquals(77, $visit->fresh()->visit_score);
    }

    public function test_rejected_outside_stage_window(): void
    {
        $today = now()->startOfDay();

        $this->seedStageBase(5, ['visit_start' => $today->copy()->addDays(2)->toDateString(), 'visit_end' => $today->copy()->addDays(9)->toDateString()]);
        $ext = $this->makeUser('penilai_eksternal', 'ext1');
        $visit = $this->makeVisitasi([$ext]);
        $this->submitReview($visit, $ext, ['nilai_visitasi' => 70, 'catatan_visitasi' => 'x', 'action' => 'draft'])
            ->assertSessionHas('error');
        $this->assertNull($this->evaluatorRow('visitasi_evaluators', 'id_visit', $visit->id_visit, $ext->id_user)->score);

        $this->period->update(['visit_start' => $today->copy()->subDays(9)->toDateString(), 'visit_end' => $today->copy()->subDay()->toDateString()]);
        $this->submitReview($visit, $ext, ['nilai_visitasi' => 70, 'catatan_visitasi' => 'x', 'action' => 'draft'])
            ->assertSessionHas('error');
        $this->assertNull($this->evaluatorRow('visitasi_evaluators', 'id_visit', $visit->id_visit, $ext->id_user)->score);
    }

    public function test_offline_visit_requires_visit_date_reached_but_online_upload_does_not(): void
    {
        $this->seedStageBase();
        $ext = $this->makeUser('penilai_eksternal', 'ext1');

        $offline = $this->makeVisitasi([$ext], ['visit_mode' => 'offline', 'visit_at' => now()->addDays(3)->toDateString()]);
        $this->submitReview($offline, $ext, ['nilai_visitasi' => 70, 'catatan_visitasi' => 'x', 'action' => 'draft'])
            ->assertSessionHas('error');
        $this->assertNull($this->evaluatorRow('visitasi_evaluators', 'id_visit', $offline->id_visit, $ext->id_user)->score);

        $offline->forceFill(['visit_at' => now()->subDay()->toDateString()])->save();
        $this->submitReview($offline, $ext, ['nilai_visitasi' => 70, 'catatan_visitasi' => 'x', 'action' => 'draft'])
            ->assertSessionHas('success');
        $this->assertEquals(70, $this->evaluatorRow('visitasi_evaluators', 'id_visit', $offline->id_visit, $ext->id_user)->score);
    }

    public function test_validation_requires_score_and_note(): void
    {
        $this->seedStageBase();
        $ext = $this->makeUser('penilai_eksternal', 'ext1');
        $visit = $this->makeVisitasi([$ext]);

        $this->submitReview($visit, $ext, ['catatan_visitasi' => 'x', 'action' => 'draft'])->assertSessionHasErrors('nilai_visitasi');
        $this->submitReview($visit, $ext, ['nilai_visitasi' => 101, 'catatan_visitasi' => 'x', 'action' => 'draft'])->assertSessionHasErrors('nilai_visitasi');
        $this->submitReview($visit, $ext, ['nilai_visitasi' => 50, 'action' => 'draft'])->assertSessionHasErrors('catatan_visitasi');
    }
}
