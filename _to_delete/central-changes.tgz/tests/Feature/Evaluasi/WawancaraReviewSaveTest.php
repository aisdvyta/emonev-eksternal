<?php

namespace Tests\Feature\Evaluasi;

use App\Models\Interview;
use App\Models\Result;
use App\Models\Submission;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\Concerns\SeedsEvaluationStage;
use Tests\TestCase;

/**
 * Tes karakterisasi WawancaraController::saveReview (simpan nilai, tenggat, rata-rata, finalisasi, status 5 → 6).
 */
class WawancaraReviewSaveTest extends TestCase
{
    use RefreshDatabase;
    use SeedsEvaluationStage;

    private function submitReview(Interview $interview, $user, array $data)
    {
        $routeName = $user->hasRole('evaluator') ? 'evaluator.review-wawancara.save' : 'penilai-eksternal.review-wawancara.save';

        return $this->actingAs($user)->post(route($routeName, $interview->id_interview), $data);
    }

    private function externalPayload($user, $score, ?string $note, string $action): array
    {
        return [
            'action' => $action,
            'external_evaluators' => [[
                'id_user' => $user->id_user,
                'name' => 'Penilai Luar',
                'instansi' => 'Instansi X',
                'score' => $score,
                'note' => $note,
            ]],
        ];
    }

    public function test_internal_draft_is_saved_without_finalizing(): void
    {
        $this->seedStageBase();
        $ev = $this->makeUser('evaluator', 'ev1');
        $interview = $this->makeInterview([$ev]);

        $this->submitReview($interview, $ev, ['score' => 70, 'note' => 'draft', 'action' => 'draft'])
            ->assertSessionHas('success');

        $row = $this->evaluatorRow('interview_evaluators', 'id_interview', $interview->id_interview, $ev->id_user);
        $this->assertEquals(70, $row->score);
        $this->assertEquals(1, $row->is_draft);
        $this->assertNull($interview->fresh()->interview_score);
        $this->assertEquals(5, Submission::find($this->submission->id_submission)->status);
    }

    public function test_internal_single_submit_finalizes_and_moves_status_to_6(): void
    {
        $this->seedStageBase();
        $ev = $this->makeUser('evaluator', 'ev1');
        $interview = $this->makeInterview([$ev]);

        $this->submitReview($interview, $ev, ['score' => 88.5, 'note' => 'mantap', 'action' => 'submit'])
            ->assertSessionHas('success');

        $this->assertEquals(88.5, $interview->fresh()->interview_score);
        $this->assertEquals(88.5, Result::find($this->result->id_result)->interview_score);
        $this->assertEquals(6, Submission::find($this->submission->id_submission)->status);
    }

    public function test_two_evaluators_finalize_with_average_after_both_submit(): void
    {
        $this->seedStageBase();
        $a = $this->makeUser('evaluator', 'ev1');
        $b = $this->makeUser('penilai_eksternal', 'ext1');
        $interview = $this->makeInterview([$a, $b]);

        $this->submitReview($interview, $a, ['score' => 80, 'note' => 'A', 'action' => 'submit'])
            ->assertSessionHas('success');
        $this->assertNull($interview->fresh()->interview_score);
        $this->assertEquals(5, Submission::find($this->submission->id_submission)->status);

        $this->submitReview($interview, $b, $this->externalPayload($b, 91, 'B', 'submit'))
            ->assertSessionHas('success');

        $this->assertEquals(85.5, $interview->fresh()->interview_score);
        $this->assertEquals(85.5, Result::find($this->result->id_result)->interview_score);
        $this->assertEquals(6, Submission::find($this->submission->id_submission)->status);
    }

    public function test_external_submit_requires_score_and_note(): void
    {
        $this->seedStageBase();
        $ext = $this->makeUser('penilai_eksternal', 'ext1');
        $interview = $this->makeInterview([$ext]);

        $this->submitReview($interview, $ext, $this->externalPayload($ext, '', 'x', 'submit'))->assertSessionHas('error');
        $this->submitReview($interview, $ext, $this->externalPayload($ext, 80, '', 'submit'))->assertSessionHas('error');
        $this->assertNull($interview->fresh()->interview_score);

        // draft tidak mewajibkan nilai
        $this->submitReview($interview, $ext, $this->externalPayload($ext, '', '', 'draft'))->assertSessionHas('success');
    }

    public function test_internal_submit_validates_score_and_note(): void
    {
        $this->seedStageBase();
        $ev = $this->makeUser('evaluator', 'ev1');
        $interview = $this->makeInterview([$ev]);

        $this->submitReview($interview, $ev, ['note' => 'x', 'action' => 'submit'])->assertSessionHasErrors('score');
        $this->submitReview($interview, $ev, ['score' => 50, 'action' => 'submit'])->assertSessionHasErrors('note');
        $this->submitReview($interview, $ev, ['score' => 120, 'note' => 'x', 'action' => 'submit'])->assertSessionHasErrors('score');
    }

    public function test_rejected_when_not_assigned(): void
    {
        $this->seedStageBase();
        $ev = $this->makeUser('evaluator', 'ev1');
        $other = $this->makeUser('evaluator', 'ev2');
        $interview = $this->makeInterview([$other]);

        $this->submitReview($interview, $ev, ['score' => 70, 'note' => 'x', 'action' => 'submit'])->assertSessionHas('error');
        $this->assertNull($this->evaluatorRow('interview_evaluators', 'id_interview', $interview->id_interview, $ev->id_user));
    }

    /**
     * @return array<string, array{0:int}>
     */
    public static function notInterviewStageProvider(): array
    {
        return ['status 4' => [4], 'status 7 selesai' => [7], 'status 8 gugur' => [8]];
    }

    #[\PHPUnit\Framework\Attributes\DataProvider('notInterviewStageProvider')]
    public function test_rejected_when_submission_not_in_interview_stage(int $status): void
    {
        $this->seedStageBase($status);
        $ev = $this->makeUser('evaluator', 'ev1');
        $interview = $this->makeInterview([$ev]);

        $this->submitReview($interview, $ev, ['score' => 70, 'note' => 'x', 'action' => 'draft'])->assertSessionHas('error');
        $this->assertNull($this->evaluatorRow('interview_evaluators', 'id_interview', $interview->id_interview, $ev->id_user)->score);
    }

    public function test_rejected_when_already_finalized(): void
    {
        $this->seedStageBase();
        $ev = $this->makeUser('evaluator', 'ev1');
        $interview = $this->makeInterview([$ev]);
        $interview->forceFill(['interview_score' => 70])->save();

        $this->submitReview($interview, $ev, ['score' => 10, 'note' => 'x', 'action' => 'submit'])->assertSessionHas('error');
        $this->assertEquals(70, $interview->fresh()->interview_score);
    }

    public function test_rejected_before_schedule_and_outside_window(): void
    {
        $this->seedStageBase();
        $ev = $this->makeUser('evaluator', 'ev1');
        $interview = $this->makeInterview([$ev], ['interview_at' => now()->addDays(2)->toDateString()]);

        $this->submitReview($interview, $ev, ['score' => 70, 'note' => 'x', 'action' => 'draft'])->assertSessionHas('error');
        $this->assertNull($this->evaluatorRow('interview_evaluators', 'id_interview', $interview->id_interview, $ev->id_user)->score);

        $interview->forceFill(['interview_at' => now()->subDay()->toDateString()])->save();
        $this->period->update(['interview_end' => now()->subDay()->toDateString()]);
        $this->submitReview($interview, $ev, ['score' => 70, 'note' => 'x', 'action' => 'draft'])->assertSessionHas('error');

        $this->period->update(['interview_start' => now()->addDays(3)->toDateString(), 'interview_end' => now()->addDays(9)->toDateString()]);
        $this->submitReview($interview, $ev, ['score' => 70, 'note' => 'x', 'action' => 'draft'])->assertSessionHas('error');
        $this->assertNull($this->evaluatorRow('interview_evaluators', 'id_interview', $interview->id_interview, $ev->id_user)->score);
    }
}
