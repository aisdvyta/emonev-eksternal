<?php

namespace Tests\Concerns;

use App\Models\Interview;
use App\Models\MasterSatker;
use App\Models\Period;
use App\Models\Result;
use App\Models\Submission;
use App\Models\User;
use App\Models\Visitasi;
use Database\Seeders\RoleSeeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

/**
 * Helper pembuat data tahap visitasi / wawancara untuk tes penilaian.
 */
trait SeedsEvaluationStage
{
    protected Period $period;
    protected Result $result;
    protected Submission $submission;

    protected function seedStageBase(int $status = 5, array $periodOverride = []): void
    {
        $this->seed(RoleSeeder::class);

        MasterSatker::query()->insertOrIgnore([
            ['kode_satker' => '3500', 'nama_satker' => 'BPS Provinsi Jawa Timur'],
            ['kode_satker' => '3578', 'nama_satker' => 'BPS Kota Surabaya'],
        ]);

        $today = now()->startOfDay();
        $this->period = Period::create(array_merge([
            'periode_start' => $today->copy()->subDays(60)->toDateString(),
            'periode_end' => $today->copy()->addDays(60)->toDateString(),
            'saq_start' => $today->copy()->subDays(50)->toDateString(),
            'saq_end' => $today->copy()->subDays(40)->toDateString(),
            'eval_start' => $today->copy()->subDays(39)->toDateString(),
            'eval_end' => $today->copy()->subDays(30)->toDateString(),
            'visit_start' => $today->copy()->subDays(10)->toDateString(),
            'visit_end' => $today->copy()->addDays(10)->toDateString(),
            'interview_start' => $today->copy()->subDays(10)->toDateString(),
            'interview_end' => $today->copy()->addDays(10)->toDateString(),
            'result_start' => $today->copy()->addDays(11)->toDateString(),
            'result_end' => $today->copy()->addDays(20)->toDateString(),
        ], $periodOverride));

        $this->result = Result::create([
            'kode_satker' => '3578',
            'id_periode' => $this->period->id_periode,
        ]);

        $this->submission = Submission::create([
            'id_result' => $this->result->id_result,
            'status' => $status,
        ]);
    }

    protected function makeUser(string $role, string $name): User
    {
        $user = User::create([
            'nama_user' => $name,
            'email' => $name.'@test.local',
            'password' => Hash::make('password123'),
            'kode_satker' => '3500',
        ]);
        $user->assignRole($role);

        return $user;
    }

    /**
     * @param  array<int, User>  $evaluators
     */
    protected function makeVisitasi(array $evaluators, array $attrs = []): Visitasi
    {
        $visit = Visitasi::create(array_merge([
            'id_result' => $this->result->id_result,
            'visit_mode' => 'online_upload',
        ], $attrs));

        foreach ($evaluators as $user) {
            $visit->evaluators()->create(['id_user' => $user->id_user]);
        }

        return $visit->fresh();
    }

    /**
     * @param  array<int, User>  $evaluators
     */
    protected function makeInterview(array $evaluators, array $attrs = []): Interview
    {
        $interview = Interview::create(array_merge([
            'id_result' => $this->result->id_result,
            'interview_at' => now()->subDay()->toDateString(),
        ], $attrs));

        foreach ($evaluators as $user) {
            $interview->evaluators()->create(['id_user' => $user->id_user]);
        }

        return $interview->fresh();
    }

    protected function evaluatorRow(string $table, string $keyCol, $key, int $userId): ?object
    {
        return DB::table($table)->where($keyCol, $key)->where('id_user', $userId)->first();
    }
}
